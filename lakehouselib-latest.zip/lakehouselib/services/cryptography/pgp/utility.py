import logging
import boto3
import json
import base64

from pgpy import PGPKey
from pgpy import PGPMessage

from lakehouselib.services.aws.s3.utility import is_s3_file

from lakehouselib.misc.file.utility import read_file_from_local, write_file_to_local
from lakehouselib.services.aws.s3.utility import read_file_from_s3, upload_object_to_s3
from lakehouselib.services.aws.ssm.utility import get_secret


logger = logging.getLogger(__name__)

PUBLIC_ID_KEY = "public_key"


class Utility:

    def __init__(self, aws_region="ap-southeast-2"):
        self.aws_region = aws_region

    def encrypt(self, source_file_path: str, secret_id: str, target_file_path: str):
        """Encrypt csv file using pgp encryption, if a file has already existed in target path, it will be overwritten.
           whether read/write file from s3 or local depends on path passed.

                Parameters
                    ----------
                    source_file_path : str
                        full path of file required encryption
                    secret_id : str
                        secret_id for storing public key in secret manager
                    target_file_path :
                        full path of encrypted file

                """
        try:
            pubkey = self.__read_public_key_from_ssm(secret_id)

            if is_s3_file(source_file_path):
                source_data = read_file_from_s3(source_file_path).decode()
            else:
                source_data = read_file_from_local(source_file_path)

            encrypted_data = pubkey.encrypt(PGPMessage.new(source_data))

            if is_s3_file(target_file_path):
                upload_object_to_s3(target_file_path, str(encrypted_data))
            else:
                write_file_to_local(target_file_path, str(encrypted_data))

        except Exception as exp:
            logger.error(exp)
            raise exp

    def __read_public_key_from_ssm(self, secret_id: str):
        aws_client_secretsmanager = boto3.client(service_name='secretsmanager', region_name=self.aws_region)
        secret = get_secret(logger, aws_client_secretsmanager, secret_id)
        public_key = json.loads(secret).get(PUBLIC_ID_KEY)

        key, _ = PGPKey.from_blob(base64.b64decode(public_key))
        return key
