
"""
Class to contain common methods for working with job-args run-time arguments for jobs.
"""


class Arguments:
    """A class to handle job-submit arguments such as getting values
    """

    def get_job_args_value(key, logger, **job_args):
        """A method to get the value of an argument

        Parameters
        ----------
        key : str
            the key used to lookup a value

        logger : util.system.logging class Log4j
            The referenced log4j object obtained from `main.py`

        job_args : dict
            Arguments passes through as obtained from the --job-args argument

        Returns
        -------
        return_value : str
            The value of the argument sought based on the input key
        """
        return_value = None
        error_message = None

        if not job_args:
            error_message = "No `--job-args` passed"
        else:
            if job_args.get(key) is None:
                error_message = "Value not found for key `{}` in `--job-args`".format(key)
            else:
                return_value = job_args.get(key)

        if error_message:
            logger.error(error_message)
            raise Exception(error_message)

        return return_value
