import logging
import smtplib

import boto3
import json

from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication
from email import encoders
from io import BytesIO
from pathlib import Path

from lakehouselib.services.aws.s3.utility import is_s3_file, read_file_from_s3
from lakehouselib.services.aws.ssm.utility import get_secret
from lakehouselib.misc.file.utility import read_file_from_local

logger = logging.getLogger(__name__)

SMTP_SERVER = "smtp_server"
LOGIN = "login"
PASSWORD = "password"
PORT = "port"


class Utility:
    def __init__(self, secret_id: str, aws_region="ap-southeast-2", use_ssl=False, use_password_auth=False):
        """Sending emaili services
            secret_id : str
            storing email smtp server and port
            this is an example
            {
                "smtp_server":"smtp.sportsbet.com.au",
                "port":"25"
            }
            aws_region: str
            use_ssl: bool whether given smtp server use ssl default to False
            use_password_auth: whether given smtp server need password to access default to False.
         """
        try:
            self.secret_id = secret_id
            self.aws_region = aws_region

            smtp_server, port, login, password = self.__read_smtp_connection_from_ssm()

            if use_ssl:
                self.smtp_server = smtplib.SMTP_SSL(smtp_server, port)
            else:
                self.smtp_server = smtplib.SMTP(smtp_server, port)

            self.use_password_auth = use_password_auth
            self.login = login
            self.password = password

        except Exception as e:
            logger.error(f"Error occured when connecting to email server  {smtp_server}")
            logger.error(e)
            raise e

    def send(self,
             send_from: str,
             send_to: str,
             content: str,
             subject: str = "",
             attachments_path=[],
             cc: str = None,
             bcc: str = None):

        """send email function, attachment could from s3 or local depends on path.

                    Parameters
                        ----------
                        send_from : str
                            send from email address
                        send_to : str
                            send to email address
                        content : str
                            content of email
                        subject : str
                            email subject
                        attachments_path : array of str
                            list of attachments path e.g ['test1.txt', 'test2,txt']
                        cc :
                            list of email cc e.g. [1@email.com, 2@email.com]
                        bcc :
                            list of email bcc e.g. [1@email.com, 2@email.com]
        """

        try:
            if self.use_password_auth:
                self.smtp_server.login(self.login, self.password)
            msg = self.__construct_email_message(send_from, send_to, content, subject, attachments_path, cc, bcc)

            self.smtp_server.send_message(msg)

            self.smtp_server.close()
        except Exception as e:
            logger.error(
                f"Error occured when trying to send email to {send_to + cc + bcc}")
            logger.error(e)
            raise e

    def __read_smtp_connection_from_ssm(self):
        aws_client_secretsmanager = boto3.client(service_name='secretsmanager', region_name=self.aws_region)

        secret = get_secret(logger, aws_client_secretsmanager, self.secret_id)

        secret_json = json.loads(secret)

        smtp_server = secret_json.get(SMTP_SERVER)
        port = secret_json.get(PORT)
        login = secret_json.get(LOGIN, None)
        password = secret_json.get(PASSWORD, None)

        return smtp_server, port, login, password

    def __construct_email_message(self,
                                  send_from: str,
                                  send_to: str,
                                  content: str,
                                  subject: str = "",
                                  attachments_path=[],
                                  cc: str = None,
                                  bcc: str = None):

        message = MIMEMultipart()

        message['Subject'] = subject
        message['To'] = send_to
        message['From'] = send_from
        message["CC"] = cc
        message["BCC"] = bcc
        message.attach(MIMEText(content))

        self.__add_attachments(message, attachments_path)

        return message

    def __add_attachments(self, message, attachments_path: str):
        if attachments_path is not None and attachments_path != "":
            for attachment_path in attachments_path:
                if is_s3_file(attachment_path):
                    attachment_content = read_file_from_s3(attachment_path).decode()
                else:
                    attachment_content = read_file_from_local(attachment_path)

                part = MIMEApplication(attachment_content)
                part.add_header('Content-Disposition', "attachment; filename=" + Path(attachment_path).name)
                message.attach(part)
