from boto3.dynamodb.conditions import Key
import json
import boto3
import os
from botocore.config import Config
from operator import itemgetter
from datetime import datetime, timedelta
import sys

# eot-related stuff
from lakehouselib.services.aws.s3.utility import *
from lakehouselib.services.aws.sessionmanager.utility import *
from lakehouselib.statehandlers.eotfile.generator.utility import *
from lakehouselib.services.aws.ssm.utility import get_secret

import pyodbc as po
import pandas as pd
import sqlalchemy as sa
from sqlalchemy import create_engine
import urllib

DEFAULT_SECRET_ID="/app/datalake-batch/datalake-batch-secrets-mds-ConnectionInfo"   
REGION_NAME="ap-southeast-2"
ODBC_DRIVER_VERSION_NO="18"

logger = logging.getLogger(__name__)

class MSSql:
    """
    """

    def __init__(self, secret_id=None, region_name=None, db=None, db_schema=None, db_table=None):
        """
        """

        if secret_id:
            self.secret_id = secret_id
        else:
            self.secret_id = DEFAULT_SECRET_ID

        if region_name:
            self.region_name = region_name
        else:
            self.region_name = REGION_NAME

        self.mssql_settings = self.get_mssql_secret()
        self.set_odbc_driver_version()

        self.db=db
        self.db_schema=db_schema
        self.db_table=db_table

    def set_db(self, db):
        """
        """

        self.db=db

    def set_db_schema(self, db_schema):
        """
        """

        self.db_schema=db_schema

    def set_db_table(self, db_table):
        """
        """

        self.db_table=db_table

    def set_odbc_driver_version(self, version_no=None):
        """
        """

        if version_no:
            self.odbc_driver_version = version_no
        else:
            self.odbc_driver_version = ODBC_DRIVER_VERSION_NO

    def get_mssql_connection_string(self, db_name):
        """
        """

        return 'DRIVER={ODBC Driver ' + self.odbc_driver_version  + ' for SQL Server};SERVER=' + self.mssql_settings['db_server'] + ';DATABASE=' + db_name + ';UID=' + self.mssql_settings['db_username'] + ';PWD=' + self.mssql_settings['db_password'] +';TrustServerCertificate=yes;'

    def get_mssql_secret(self, aws_client_secretsmanager=None):
        """
        """

        try:
            # Get DB credentials from Secrets Manager
            if aws_client_secretsmanager is None:
                aws_client_secretsmanager = boto3.client(service_name='secretsmanager', region_name=self.region_name)
                
            secret = get_secret(logger, aws_client_secretsmanager, secret_id=self.secret_id)
            secret = json.loads(secret)

            # Set Variables
            db_username = secret.get('db_username')
            db_password = secret.get('db_password')
            db_url = secret.get('db_url')
            driver_name = secret.get('driver_name')
            db_server = secret.get('server_name')

            mssql_settings = {
                'db_username': db_username,
                'db_password': db_password,
                'db_url': db_url,
                'driver_name': driver_name,
                'db_server': db_server
            }

            return mssql_settings

        except Exception as exp:
            logger.error (exp)
            raise exp

    def write_data_to_mssql_via_odbc(self, df_pd, if_exists='append', chunksize=100, method='multi', index=False):
        """
        """

        try:
            destination_table=self.db_table
            destination_schema=self.db_schema

            quoted = urllib.parse.quote_plus(self.get_mssql_connection_string(self.db))
            engine = create_engine('mssql+pyodbc:///?odbc_connect={}'.format(quoted))

            df_pd.to_sql(destination_table, schema=destination_schema, con=engine, chunksize=chunksize, method=method, index=index, if_exists=if_exists)

            return 0

        except Exception as exp:
            logger.error(f"'Writing data to '{self.db}.{self.db_schema}.{self.db_table}' failed!\n\tCheck if {self.db}.{self.db_schema}.{self.db_table} exists\t\tMake sure column names are same between dataframe columns and sql table columns")
            logger.error (exp)
            raise exp

    def read_data_from_mssql_via_odbc(self, sql_statement):
        """
        """

        try:
            cnxn = po.connect(self.get_mssql_connection_string(self.db))
            data = pd.read_sql(sql_statement, cnxn)

            del cnxn

            return 0, data

        except Exception as exp:
            logger.error(f"'Reading data using {sql_statement}' from '{self.db}' failed!\n\tCheck if there is any syntax error and make sure '{self.db}' exists")
            logger.error (exp)
            raise exp

    def execute_mssql_statement_via_odbc(self, sql_statement):
        """
        """

        try:
            cnxn = po.connect(self.get_mssql_connection_string(self.db))
            cursor = cnxn.cursor()

            # Execute Stored Procedure With Parameters
            cursor.execute(sql_statement)
            cnxn.commit()        

            cursor.close()
            del cursor

            # Close the database connection
            cnxn.close()

            return 0

        except Exception as exp:
            logger.error(f"'{sql_statement}' executed on '{self.db}' failed!\n\tCheck if there is any syntax error and make sure '{self.db}' exists")
            logger.error(exp)
            raise exp
