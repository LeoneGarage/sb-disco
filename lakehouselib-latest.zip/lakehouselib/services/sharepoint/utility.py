from boto3.dynamodb.conditions import Key
import json
import boto3
from boto3.session import Session

import os
from botocore.config import Config
from operator import itemgetter
from datetime import datetime, timedelta
import sys

from lakehouselib.services.aws.s3.utility import *
from lakehouselib.services.aws.sessionmanager.utility import *
from lakehouselib.statehandlers.eotfile.generator.utility import *

from lakehouselib.services.aws.ssm.utility import get_secret

from lakehouselib.misc.string.utility import strip_char_from_string

from office365.runtime.auth.authentication_context import AuthenticationContext
from office365.sharepoint.client_context import ClientContext
from office365.sharepoint.files.file import File

import os
import tempfile

from os import listdir
from os.path import isfile, join

DEFAULT_LARGE_FILE_SIZE=1024*1024*50
DEFAULT_SECRET_ID="/app/datalake-batch/datalake-batch-secrets-sharepoint-ConnectionInfo"   

logger = logging.getLogger(__name__)

class MSSharepoint:
    """Share point Class
    """

    def __init__(self, secret_id=None, sharepoint_library=None, sharepoint_folder=None):
        """Initialise share point object
        """

        if secret_id:
            self.app_settings = self.get_sharepoint_secret(secret_id)
        else:
            self.app_settings = self.get_sharepoint_secret()

        self.ctx = self.sharepoint_auth()
        self.set_sharepoint_library(sharepoint_library)
        self.set_sharepoint_folder(sharepoint_folder)
        self.set_sharepoint_target_folder()

    def get_sharepoint_site_relative_url(self, sharepoint_site_url):
        """Get relative url for sharepoint site

        Parameters
            ----------
            sharepoint_site_url : str
                full path of sharepoint url 

            Returns
            -------
            str : 
                relative url 
        """

        return '/' + strip_char_from_string(sharepoint_site_url, '/').split('/')[-2] + '/' + strip_char_from_string(sharepoint_site_url, '/').split('/')[-1]

    def get_sharepoint_secret(self, sharepoint_secrets=DEFAULT_SECRET_ID, aws_client_secretsmanager=None):
        """Retrieve sharepoint connection credentials - site url, client id, client secret

            Parameters
            ----------
            sharepoint_secrets : str
                sharepoint secrets id

            Returns
            -------
            app_settings : dict
                {
                    'url': sharepoint_url,
                    'client_id': client_id,
                    'client_secret': client_secret
                    'relative_site_url': relative_site_url
                }
        """

        try:
            # Get DB credentials from Secrets Manager
            if aws_client_secretsmanager is None:
                aws_client_secretsmanager = boto3.client(service_name='secretsmanager', region_name="ap-southeast-2")
            secret = get_secret(logger, aws_client_secretsmanager, secret_id=sharepoint_secrets)
            secret = json.loads(secret)

            # Set Variables
            client_id = secret.get('client_id')
            client_secret = secret.get('client_secret')
            url = secret.get('sharepoint_url')

            app_settings = {
                'url': url,
                'client_id': client_id,
                'client_secret': client_secret,
            }

            relative_site_url=self.get_sharepoint_site_relative_url(url)

            app_settings['relative_site_url'] = relative_site_url

            return app_settings

        except Exception as exp:
            logger.error(f"Fail to get aws sercret for sharepoint access. Check if secret_id '{sharepoint_secrets}' exists in AWS Secret Manager")
            logger.error(exp)
            raise exp

    def sharepoint_auth(self):
        """Retrieve sharepoint connection credentials - site url, client id, client secret

            Parameters
            ----------

            Returns
            -------
            ctx : ClientContext
                context for Sharepoint Objects
        """

        try:
            context_auth = AuthenticationContext(self.app_settings['url'])
            context_auth.acquire_token_for_app(client_id=self.app_settings['client_id'], client_secret=self.app_settings['client_secret'])
            ctx = ClientContext(self.app_settings['url'], context_auth)

            return ctx

        except Exception as exp:
            logger.error(f"Fail to acquire token to access sharepoint. Check if client_id and client secret are correct")
            logger.error (exp)
            raise exp        

    def set_sharepoint_library(self, sharepoint_library):
        """Set sharepoint library
        """

        self.sharepoint_library = sharepoint_library

    def set_sharepoint_folder(self, sharepoint_folder):
        """Set sharepoint folder 
        """

        self.sharepoint_folder = sharepoint_folder

    def set_sharepoint_target_folder(self, sharepoint_library=None, sharepoint_folder=None):
        """Set sharepoint target folder

            Parameters
            ----------
            sharepoint_library : str
                share point document library name

            sharepoint_folder : str
                share point folder under a document library

            Returns
            -------
            target_folder : share point folder object

        """

        try:

            if sharepoint_library is None: 
                sharepoint_library = self.sharepoint_library

            if sharepoint_folder is None:
                sharepoint_folder = self.sharepoint_folder

            if sharepoint_folder:

                sharepoint_library = strip_char_from_string(sharepoint_library, '/')
                sharepoint_folder = strip_char_from_string(sharepoint_folder, '/')
                self.target_folder = self.ctx.web.ensure_folder_path(sharepoint_library + '/' + sharepoint_folder).execute_query()

            else:
                sharepoint_library = strip_char_from_string(sharepoint_library, '/')
                self.target_folder = self.ctx.web.ensure_folder_path(sharepoint_library).execute_query()

        except Exception as exp:
            logger.error(f"Fail to retrive sharepoint target folder. Check if sharepoint library is valid and check if the token is still valid or expired")
            logger.error (exp)
            raise exp

    def delete_file_from_sharepoint(self, sharepoint_library, file_path):
        """Delete a file from sharepoint site

            Parameters
            ----------
            sharepoint_library : str
                share point document library name

            file_path : str
                share point file path

            Returns
            -------
            0: if success

        """

        try:

            if self.app_settings: 

                relative_file_url = self.app_settings['relative_site_url'] + '/'  + strip_char_from_string(sharepoint_library, '/') + '/' + strip_char_from_string(file_path, '/')

                file = self.ctx.web.get_file_by_server_relative_url(relative_file_url)
                file.delete_object().execute_query()    

                logger.info("File has been deleted from {0}".format(relative_file_url))

                return 0

            else:
                return -1


        except Exception as exp:
            logger.error(f"Fail to delete a file on sharepoint. Check if '/{sharepoint_library}/{file_path}' exists on the site.")
            logger.error (exp)
            raise exp

    def upload_small_file_to_sharepoint(self, file_path):
        """Upload a file to sharepoint target folder

            Parameters
            ----------
            file_path : str
                path of the file

            Returns
            -------
            0: if success

        """
        try:

            if is_s3_file(file_path):

                file_content = read_file_from_s3(file_path)

            else:

                with open(file_path, 'rb') as content_file:
                    file_content = content_file.read()

            filename_only = file_path.split('/')[-1]

            if self.sharepoint_folder: 
                sharepoint_file_path = self.sharepoint_library + '/' + self.sharepoint_folder + '/' + filename_only
            else:
                sharepoint_file_path = self.sharepoint_library + '/' + filename_only

            logger.info(f"sharepoint_file_path -> {sharepoint_file_path}")

            target_file = self.target_folder.upload_file(sharepoint_file_path, file_content).execute_query()

            logger.info("File has been uploaded to url: {0}".format(target_file.serverRelativeUrl))

            return 0

        except Exception as exp:
            logger.error(f"Fail to upload '{file_path}' to {sharepoint_file_path}.")
            logger.error(f"\tCheckj if '{file_path}' exists on the source.")
            logger.error(f"\tCheckj if '{sharepoint_file_path}' is a valid sharepoint location.")
            logger.error(f"\tCheckj if share point library '{self.sharepoint_library}' exists on the site.")
            logger.error (exp)
            raise exp

    def upload_large_file_to_sharepoint(self, file_path, size_chunk=DEFAULT_LARGE_FILE_SIZE):
        """WIP
            Upload a larget file to sharepoint target folder

            Parameters
            ----------
            file_path : str
                path of the file

            size_chunk: int
                chunk size for uploading a large file

            Returns
            -------
            0: if success

        """
        try:

            def print_upload_progress(offset):
                file_size = os.path.getsize(file_path)       
                print("Uploaded '{0}' bytes from '{1}'...[{2}%]".format(offset, file_size, round(offset / file_size * 100, 2)))

            if is_s3_file(file_path):

                self.upload_small_file_to_sharepoint(file_path)

            else:

                # with open(file_path, 'rb') as file_content:
                #     uploaded_file = target_folder.files.create_upload_session(file_content, size_chunk, print_upload_progress).execute_query()

                uploaded_file = self.target_folder.files.create_upload_session(file_path, size_chunk, print_upload_progress).execute_query()            

                print('File {0} has been uploaded successfully'.format(uploaded_file.serverRelativeUrl))                

            return 0

        except Exception as exp:
            logger.error(f"Fail to upload large file '{file_path}' to '/{self.sharepoint_library}/{self.sharepoint_folder}'.")
            logger.error(f"\tNote that large file upload from S3 to Sharepoint has Not been implemented yet.")
            logger.error (exp)
            raise exp        

    def upload_file_to_sharepoint(self, file_path, size_chunk=DEFAULT_LARGE_FILE_SIZE):
        """Upload a file to sharepoint target folder. Auto decide whether a file is large or small based on size_chunk

            Parameters
            ----------
            file_path : str
                path of the file

            size_chunk: int
                max size for a small file

            Returns
            -------
            0: if success

        """

        try:

            if is_s3_file(file_path):

                bucket, key = get_bucket_key_from_s3_path(file_path)
                file_size=check_existing_s3_file_size(bucket, key)

            else:

                file_size = os.path.getsize(file_path)

            if file_size > size_chunk:
                self.upload_large_file_to_sharepoint(file_path, size_chunk)
            else:
                self.upload_small_file_to_sharepoint(file_path)

            return 0

        except Exception as exp:
            logger.error(f"Fail to upload file '{file_path}' to sharepoint.")
            logger.error(f"\tCheck if file '{file_path}' exists")
            logger.error (exp)
            raise exp

    def upload_folder_to_sharepoint(self, source_folder, s3_start_folder=None, size_chunk=DEFAULT_LARGE_FILE_SIZE, s3_client=None):
        """Upload all files under a folder to sharepoint target folder. Auto decide whether a file is large or small based on size_chunk

            Parameters
            ----------
            source_folder : str
                local path of the folder

            s3_start_folder: str
                starting folder of S3 to be created on sharepoint

            size_chunk: int
                max size for a small file

            Returns
            -------
            0: if success

        """

        try:

            if is_s3_file(source_folder):

                bucket, prefix = get_bucket_key_from_s3_path(source_folder)
                page_iterator = list_s3_objects_based_on_bucket_prefix(bucket, prefix)

                for page in page_iterator:

                    logger.info("getting n files from S3")
                    files = page.get("Contents")

                    for file in files:

                        logger.info(f"file_name: {file['Key']} | size: {file['Size']}")

                        file_key = file['Key']
                        file_path = f's3://{bucket}/{file_key}'

                        logger.info(f">>>>> **** file_path: {file_path}")

                        if file_path[-1] == "/":
                            continue

                        origin_sharepoint_folder = self.sharepoint_folder
                        if self.sharepoint_folder:

                            sharepoint_sub_folder = self.sharepoint_folder + '/' + file_key[file_key.find(s3_start_folder):].replace(file_key.split('/')[-1], '')
                        else:
                            sharepoint_sub_folder = file_key[file_key.find(s3_start_folder):].replace(file_key.split('/')[-1], '')

                        logger.info(f">>>>> **** sharepoint_sub_folder: {sharepoint_sub_folder}")

                        self.set_sharepoint_target_folder(self.sharepoint_library, sharepoint_sub_folder)
                        self.set_sharepoint_folder(sharepoint_sub_folder)                        
                        self.upload_file_to_sharepoint(file_path)
                        self.set_sharepoint_folder(origin_sharepoint_folder)

                self.set_sharepoint_target_folder()
            else:

                for f in listdir(source_folder):
                    
                    f = join(source_folder, f)

                    if isfile(f):
                        logger.info(f"File -> {f}")
                        self.upload_file_to_sharepoint(f, size_chunk)

            return 0

        except Exception as exp:
            logger.error(f"Fail to upload a folder '{source_folder}' to sharepoint.")
            logger.error(f"\tCheck if sharepoint library '{self.sharepoint_library}' exists")
            logger.error (exp)
            raise exp

    def download_file_from_sharepoint(self, sharepoint_library, sharepoint_file_path):

        """download a file from sharepoint site

            Parameters
            ----------
            sharepoint_library : str
                share point document library name

            sharepoint_file_path : str
                share point file path

            Returns
            -------
            0: if success
            download_path: local file path of the downloaded file
        """

        try:

            if self.app_settings: 

                relative_site_url=self.app_settings['relative_site_url']

                sharepoint_file_path=strip_char_from_string(sharepoint_file_path, '/')
                file_url = f"{relative_site_url}/{sharepoint_library}/{sharepoint_file_path}"
                download_path = os.path.join(tempfile.mkdtemp(), os.path.basename(file_url))
                with open(download_path, "wb") as local_file:
                    file = self.ctx.web.get_file_by_server_relative_path(file_url).download(local_file).execute_query()
                logger.info("[Ok] file has been downloaded into: {0}".format(download_path))

                return 0, download_path

            else:
                return -1, None

        except Exception as exp:
            logger.error(f"Fail to download file '/{sharepoint_library}/{sharepoint_file_path}' from sharepoint.")
            logger.error(f"\tCheck if file '/{sharepoint_library}/{sharepoint_file_path}' exists on sharepoint.")
            logger.error (exp)
            raise exp

    def list_sharepoint_files(self, sharepoint_library, sharepoint_folder=None):
        """List files on sharepoint site based on the specified library and folder

        Parameters
            ----------
            sharepoint_library : str
                share point document library name

            sharepoint_file_path : str
                share point file path

            Returns
            -------
            file_list: list
                list of file info
                    'sharepoint_library'
                    'sharepoint_file_path'
        """

        try:

            file_list = []
            relative_site_url=self.app_settings['relative_site_url']

            def enum_folder(parent_folder, fn):
                """Recursively list files under parent_folder
                """
                parent_folder.expand(["Files", "Folders"]).get().execute_query()
                for file in parent_folder.files:  # type: File
                    fn(file)
                for folder in parent_folder.folders:  # type: Folder
                    enum_folder(folder, fn)

            def add_file_to_list(f):
                """Add file info - sharepoint_library, sharepoint_file_path to 'file_list'
                """

                server_relative_url = f.properties['ServerRelativeUrl']

                sharepoint_library = server_relative_url.replace(relative_site_url, "").split('/')[1]
                sharepoint_file_path = strip_char_from_string(server_relative_url.replace(relative_site_url, "").replace(sharepoint_library, ""), "/")

                file_obj = {
                    'sharepoint_library' : sharepoint_library,
                    'sharepoint_file_path' : sharepoint_file_path
                    }

                file_list.append(file_obj)

            if sharepoint_folder:
                target_folder_url = strip_char_from_string(sharepoint_library, '/') + '/' + strip_char_from_string(sharepoint_folder, '/')
            else:
                target_folder_url = strip_char_from_string(sharepoint_library, '/')

            root_folder = self.ctx.web.get_folder_by_server_relative_path(target_folder_url)    
            enum_folder(root_folder, add_file_to_list)

            return file_list

        except Exception as exp:
            logger.error(f"Fail to list files under '/{sharepoint_library}/{sharepoint_folder}' from sharepoint.")
            logger.error(f"\tCheck if folder '/{sharepoint_library}/{sharepoint_folder}' on sharepoint exists.")
            logger.error (exp)
            raise exp    

