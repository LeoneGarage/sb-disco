import boto3 
from botocore.config import Config
from lakehouselib.services.aws.sessionmanager.utility import *


def get_resource(resource_type, region_name='ap-southeast-2', role_arn=None):
    """
    Gets a boto3 client for the given resource type.  Defaults to region to ap-southeast-2
    :param resource_type: boto3 resource type to create
    :param region_name: region to create the client in
    :return: boto3 client
    """
    config = Config(retries={'max_attempts': 10})

    try:
        credentials = get_credentials(role_arn)
        session = boto3.Session(
            aws_access_key_id=credentials['AccessKeyId'],
            aws_secret_access_key=credentials['SecretAccessKey'],
            aws_session_token=credentials['SessionToken']
        )
        return session.resource(resource_type, region_name=region_name, config=config)
    except Exception as exc:
        raise (exc)
