import awswrangler as wr


from lakehouselib.services.aws.sessionmanager.utility import *


client_session = create_aws_session()


def generate_athena_ddl(df_sample, target_schema, target_table, target_partition_col, target_s3_bucket, file_retention, log_retention, client_session):
    """
    
    :param df_sample: sample dataframe used to extract table columns
    :param target_schema: schema/database where the table will be created
    :param target_table: table name
    :param target_partition_col: the partition column name
    :param target_s3_bucket: s3 bucket name
    :param file_retention: values in days for delta file retention
    :param log_retention: values in days for delta log retention
    :return: Table DDL creation used to create Glue Catalog Table Entry
    """
    # Get Sample partition used to infer table definition
    sample_partition = df_sample.limit(1).collect()[0][str(target_partition_col[0])]
    s3path = 's3://{}/{}/{}/{}={}/'.format(target_s3_bucket, target_schema, target_table, str(target_partition_col[0]), str(sample_partition))
    print(s3path)
    print('Get cols')
    columns_types, partitions_types = wr.s3.read_parquet_metadata(path=s3path, dataset=True, 
                                                                  boto3_session=client_session)

    col_def = ""
    part_def = ""
    for k, v in columns_types:
        if k == target_partition_col[0]:
            part_def = f"`{k}` {v}"
        elif 'long' in v:
            col_def += f"`{k}` bigint,\n"
        elif 'integer' in v:
            col_def += f"`{k}` int,\n"
        else:
            col_def += f"`{k}` {v},\n"

    col_def = col_def.rstrip(',\n')

    tbl_header = """
    CREATE EXTERNAL TABLE IF NOT EXISTS s_{}.{} (
    """.format(target_schema, target_table)
    tbl_footer = """
    )
            PARTITIONED BY ({})
            ROW FORMAT SERDE 'org.apache.hadoop.hive.ql.io.parquet.serde.ParquetHiveSerDe'
            STORED AS INPUTFORMAT 'org.apache.hadoop.hive.ql.io.SymlinkTextInputFormat'
            OUTPUTFORMAT 'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat'
            LOCATION 's3://{}/{}/{}/_symlink_format_manifest/'
    """.format(part_def, target_s3_bucket, target_schema, target_table, file_retention, log_retention)

    return tbl_header + col_def + tbl_footer



def generate_athena_ddl_unpartitioned(df_sample, target_schema, target_table, target_s3_bucket, file_retention, log_retention, client_session):
    """
    
    :param df_sample: sample dataframe used to extract table columns
    :param target_schema: schema/database where the table will be created
    :param target_table: table name
    :param target_s3_bucket: s3 bucket name
    :param file_retention: values in days for delta file retention
    :param log_retention: values in days for delta log retention
    :return: Table DDL creation used to create Glue Catalog Table Entry
    """
    s3path = 's3://{}/{}/{}/'.format(target_s3_bucket, target_schema, target_table)
    print(s3path)
    columns_types, partitions_types = wr.s3.read_parquet_metadata(path=s3path, path_suffix=[".snappy.parquet"], dataset=True, 
                                                                  boto3_session=client_session)

    col_def = ""

    for k, v in columns_types:
        if 'long' in v:
            col_def += f"`{k}` bigint,\n"
        elif 'integer' in v:
            col_def += f"`{k}` int,\n"
        else:
            col_def += f"`{k}` {v},\n"

    col_def = col_def.rstrip(',\n')

    tbl_header = """
    CREATE EXTERNAL TABLE IF NOT EXISTS s_{}.{} (
    """.format(target_schema, target_table)
    tbl_footer = """
    )
            ROW FORMAT SERDE 'org.apache.hadoop.hive.ql.io.parquet.serde.ParquetHiveSerDe'
            STORED AS INPUTFORMAT 'org.apache.hadoop.hive.ql.io.SymlinkTextInputFormat'
            OUTPUTFORMAT 'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat'
            LOCATION 's3://{}/{}/{}/_symlink_format_manifest/'
    """.format( target_s3_bucket, target_schema, target_table, file_retention, log_retention)

    return tbl_header + col_def + tbl_footer
