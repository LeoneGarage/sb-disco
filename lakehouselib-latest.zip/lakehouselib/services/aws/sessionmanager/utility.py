import boto3 
import os
from botocore.config import Config

import logging
logging.basicConfig()
logger = logging.getLogger(__name__)

def create_aws_session(region_name='ap-southeast-2', profile_name=None):
    """
    :param region_name: aws region name - default to ap-southeast-2
    :param profile_name: is the local profile set thru saml2aws
    :return: aws session
    """
    if profile_name is None:
        try:
            session = boto3.session.Session(region_name=region_name)
            return session
        except Exception as exc:
            raise (exc)
    else:
        try:
            session = boto3.session.Session(profile_name=profile_name, region_name=region_name)
            return session
        except Exception as exc:
            raise (exc)

def get_credentials(role_arn=None):
    """
    Gets the credentials via an STS client call for a given role_arn
    :return: credentials dictionary from boto3 sts response object
    """
    try:

        if role_arn is None:
            role_arn = os.getenv("deltalake_assume_role_arn")
        role_session_name = 'mysession'
        session = boto3.session.Session()
        sts_connection = session.client('sts')
        response = sts_connection.assume_role(RoleArn=role_arn, RoleSessionName=role_session_name, DurationSeconds=3600)
        credentials = response['Credentials']
        return credentials
    except Exception as exc:
        raise exc


def create_session_sts(logger, roleArn, roleSessionName, resource, boto3_type='resource'):
    """
    :param logger: logger object 
    :param roleArn: role arn to be used/assumed
    :param roleSessionName: session name
    :param resource: aws resource to create resource for
    :param boto3_type:  object type resource or client 
    :return: resource / client object
    """
    sts_client = boto3.client('sts')
    # Call the assume_role method of the STSConnection object and pass the role
    # ARN and a role session name.
    assumed_role_object = sts_client.assume_role(
        RoleArn=roleArn,  # add as param
        RoleSessionName=roleSessionName  # add as param
    )
    # From the response that contains the assumed role, get the temporary
    # credentials that can be used to make subsequent API calls
    credentials = assumed_role_object['Credentials']
    # Use the temporary credentials that AssumeRole returns to make a
    # connection to Amazon S3
    if boto3_type == 'resource':
        try:
            resource = boto3.resource(
                resource,
                aws_access_key_id=credentials['AccessKeyId'],
                aws_secret_access_key=credentials['SecretAccessKey'],
                aws_session_token=credentials['SessionToken'],
                region_name="ap-southeast-2"
            )
            return resource
        except Exception as exc:
            logger.error(exc)
            logger.error("Error in `create_session_sts`")
            raise exc
    elif boto3_type == 'client':
        try:
            client = boto3.client(
                resource,
                aws_access_key_id=credentials['AccessKeyId'],
                aws_secret_access_key=credentials['SecretAccessKey'],
                aws_session_token=credentials['SessionToken'],
                region_name="ap-southeast-2"
            )
            return client
        except Exception as exc:
            logger.error(exc)
            logger.error("Error in `create_session_sts`")
            raise exc