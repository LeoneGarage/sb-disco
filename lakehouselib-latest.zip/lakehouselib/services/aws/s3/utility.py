from botocore.exceptions import ClientError
import boto3
from urllib.parse import urlparse
from datetime import datetime

from boto3.session import Session
from boto3.s3.transfer import TransferConfig
from botocore.config import Config

import logging
logging.basicConfig()
logger = logging.getLogger(__name__) 


def get_log_file(s3bucket, logPath, client_session):
    """
    :param s3bucket: s3bucket name where the delta table resides
    :param logPath: s3 path to _delta_log folder
    :param client_session:  - instance of boto3 aws session
    """
    try:
        s3 = client_session.client('s3')
        data = s3.get_object(Bucket=s3bucket, Key=logPath)
        return data['Body'].read().decode()
    except ClientError as e:
        print("Unexpected error: %s" % e)

def put_eot_file(delta_table_path, eot_content, client_session, batchId=None):
    """
    The eot_* files will reside at the root of the bucket in the eot/ folder
    :param delta_table_path: s3bucket path where the delta table resides
    :param client:  - instance of boto3 aws session
    eot_content: json eot content
    """
    if batchId is None:
        batchId = str(int(datetime.utcnow().timestamp() * 1000))
    try:
        s3 = client_session.resource('s3')
        o = urlparse(delta_table_path, allow_fragments=False)
        s3bucket = o.hostname
        database_name = o.path.split('/')[1]
        table_name = o.path.split('/')[2]
        eot_path = 'eot/' + database_name + '.' + table_name + '/' + database_name + '.' + table_name + '_' + batchId + '.eot'
        print(eot_path)
        s3.Object(s3bucket, eot_path).put(Body=str(eot_content).replace("'", '"'), ACL='bucket-owner-full-control')
    except ClientError as e:
        print("Unexpected error: %s" % e)


def empty_s3_folder(s3_session, s3_bucket_name, s3_folder):
    '''
    Will empty a folder from a bucket, it requires a tuple (s3_session, s3_bucket_name, s3_folder)
    :param s3_bucket_name: bucket which contains the prefix to delete
    :param s3_folder: prefix within the bucket to be deleted
    :return: nothing
    '''
    try:
        s3_bucket = s3_session.Bucket(s3_bucket_name)
    except Exception as exc:
        print(exc)
        raise exc
    try:
        s3_bucket.objects.filter(Prefix=s3_folder).delete()
    except Exception as exc:
        print(exc)
        raise exc


def get_s3_keys(client, source_s3_bucket, source_folder):
    '''
    :param client: s3 client object 
    :param source_s3_bucket: s3 bucket name
    :param source_folder: s3 folder prefix
    :return: 
    '''
    paginator = client.get_paginator('list_objects_v2')
    pages = paginator.paginate(Bucket=source_s3_bucket, Prefix=source_folder.lower())

    lst = []
    try:
        for page in pages:
            for obj in page['Contents']:
                if obj['Key'].endswith('.parquet'):
                    lst.append(obj['Key'])
    except Exception as e:
        print('Error while listing ' + source_s3_bucket + ' - ' + source_folder)
        logger.error("Error in `get_s3_keys`")
        logger.error(e)
    return lst


def copy_s3_object(s3_session, src_bucket, src_prefix, dest_bucket, dest_prefix, s3_key):
    '''
    :param s3_session: s3 client object 
    :param src_bucket: source s3 bucket name
    :param src_prefix: source prefix folder
    :param dest_bucket: destination s3 bucket
    :param dest_prefix: destination prefix folder
    :param s3_key: s3 key 
    :return: nothing
    '''
    dest_key = dest_prefix + '/' + s3_key.replace(src_prefix.lower(), '')
    try:
        s3_session.copy_object(Bucket=dest_bucket, Key=dest_key, CopySource={'Bucket': src_bucket, 'Key': s3_key})
    except Exception as e:
        print('Error in copy_s3_object for ' + dest_bucket + ' - ' + dest_key)
        logger.error("Error in `get_s3_keys`")
        logger.error(e)


def is_s3_file(file_path):
    """Check if a file is on S3 or Local

        Parameters
        ----------
        file_path : str

        Returns
        -------
        True : File is on S3
        False: File is Not on S3
    """

    if "s3://" in file_path:
        return True
    else:
        return False

def get_bucket_key_from_s3_path(file_path):
    """Get bucket name and file key of the S3 object
    """

    try:

        bucket = file_path.replace("s3://", "").split('/')[0]
        key = file_path.replace("s3://","").replace(f"{bucket}/","")

        return bucket, key

    except Exception as exp:
        logger.error (exp)
        raise exp                 

def read_file_from_s3(file_path, s3=None):
    """Read S3 body content to memory

        Parameters
        ----------
        file_path : str
            s3;s URI

        Returns
        -------
        file_content: body of S3 object
    """

    try:

        if s3 is None:
            s3 = Session().resource('s3')

        bucket, key = get_bucket_key_from_s3_path(file_path)
        obj = s3.Object(bucket, key)
        file_content = obj.get()['Body'].read()

        return file_content

    except Exception as exp:
        logger.error (exp)
        raise exp           


def upload_object_to_s3(path, content,  s3=None):
    """upload string to a s3 bucket and stored as a file. the file name and extension is defined in path.

        Parameters
        ----------
        path : str
            target s3;s URI with s3 bucket name and file name with extension.

        content: str
           content to upload to s3 bucket
    """

    try:

        if s3 is None:
            s3 = Session().resource('s3')

        bucket, key = get_bucket_key_from_s3_path(path)
        obj = s3.Object(bucket, key)
        obj.put(Body=content)

    except Exception as exp:
        logger.error (exp)
        raise exp

def check_existing_s3_file_size(bucket, key, client=None):
    """Return the S3 file's size if it exist, else None

        Parameters
        ----------
        bucket : str
            bucket name

        key : str
            file key

        Returns
        -------
        size of the S3 object (int)
    """

    if client is None:
        client = boto3.client('s3')

    response = client.list_objects_v2(
        Bucket=bucket,
        Prefix=key,
    )
    for obj in response.get('Contents', []):
        if obj['Key'] == key:
            return obj['Size']


def rename_s3_file(from_bucket, from_key, to_bucket, to_key, s3=None):
    """
    """

    try:

        if s3 is None:
            s3 = boto3.resource('s3')

        s3.Object(to_bucket, to_key).copy_from(CopySource=f"{from_bucket}/{from_key}")
        s3.Object(from_bucket, from_key).delete()    

        return 0

    except Exception as exp:
        logger.error (exp)
        raise exp           

def delete_s3_file(bucket, key, s3=None):
    """
    """

    try:

        if s3 is None:
            s3 = boto3.resource('s3')
        s3.Object(bucket, key).delete()    

        return 0

    except Exception as exp:
        logger.error (exp)
        raise exp           


def list_s3_keys_from_s3_bucket_prefix(bucket, prefix, maxkeys=100, s3=None):
    """
    """

    if s3 is None:
        s3 = boto3.client("s3")

    response = s3.list_objects_v2(Bucket=bucket,Prefix =prefix, MaxKeys=maxkeys)

    s3_key_list = []

    for obj in response['Contents']:
        s3_key_list.append(obj['Key'])

    return s3_key_list

def list_s3_objects_based_on_bucket_prefix(bucket, prefix, s3_client=None):
    """
    """

    try:

        if s3_client is None:
            s3_client = boto3.client("s3")

        paginator = s3_client.get_paginator("list_objects_v2")
        
        operation_parameters = {'Bucket': bucket, 'Prefix': prefix}

        page_iterator = paginator.paginate(**operation_parameters)            

        return page_iterator

    except Exception as exp:
        logger.error (exp)
        raise exp           

def check_existing_s3_folder_size(bucket, key, client=None):
    """Return the S3 folder's size if it exists, else None

        Parameters
        ----------
        bucket : str
            bucket name

        key : str
            file key

        Returns
        -------
        size of the S3 object (int)
    """
    if client is None:
        client = boto3.client('s3')
    response = client.list_objects_v2(
        Bucket=bucket,
        Prefix=key,
    )
    total_size = 0
    for obj in response.get('Contents', []):
        if key in obj['Key']:
            total_size = total_size + obj['Size']
    return total_size

def rename_s3_file_copy(from_bucket, from_key, to_bucket, to_key, s3=None):
    """
    """

    try:

        if s3 is None:
            s3 = boto3.resource('s3')
        
        # set 25 MB chunks
        part_size = 1024 * 1024 * 25

        # set file threshold to 25 MB
        file_threshold = 1024 * 1024 * 25

        # set the transfer threshold and chunk size
        transfer_config = TransferConfig(
            multipart_threshold=file_threshold,
            multipart_chunksize=part_size,
            use_threads=True,
            max_concurrency=20
        )
        
        copy_source = {
            'Bucket': from_bucket,
            'Key': from_key
            }

        bucket = s3.Bucket(to_bucket)
        bucket.copy(copy_source, to_key,
                    Config=transfer_config)
        #s3.Object(to_bucket, to_key).copy_from(CopySource=f"{from_bucket}/{from_key}")
        s3.Object(from_bucket, from_key).delete()    

        return 0

    except Exception as exp:
        logger.error (exp)
        raise exp