import base64

from botocore.exceptions import ClientError


def get_ssm_config_value(logger, client, param):
    """Get information about a single parameter from AWS SSM Parameter Store by specifying the parameter name

    Parameters
    -----------
    logger : util.system.logging class Log4j
        The referenced log4j object obtained from `main.py`
    client : boto3.session.client
        the named boto client created to access the service
    param : str
        the parameter name to get the value for

    Returns
    -------
    return : str
        The value of the sought from SSM parameter store
    """
    try:
        parameter = client.get_parameter(Name=param)["Parameter"]["Value"]
    except Exception as exp:
        logger.error(exp)
        error_msg = "Parameter `{}` does not exist".format(param)
        logger.error(error_msg)
        raise Exception(error_msg) from exp
    return parameter


def get_secret(logger, client, secret_id):
    """Retrieves the contents of the encrypted fields SecretString or SecretBinary from the specified version of a secret, whichever contains content.

    Parameters
    -----------
    logger : util.system.logging class Log4j
        The referenced log4j object obtained from `main.py`
    client : boto3.session.client
        the named boto client created to access the service
    secret_id : str
        the name of the secret to get the value for

    Returns
    -------
    return : str
        The value of the sought from SSM
    """
    try:
        get_secret_value_response = client.get_secret_value(SecretId=secret_id)
    except ClientError as e:
        if e.response['Error']['Code'] == 'ResourceNotFoundException':
            logger.error("The requested secret `%s` was not found", secret_id)
        elif e.response['Error']['Code'] == 'InvalidRequestException':
            logger.error("The request was invalid due to: %s", e)
        elif e.response['Error']['Code'] == 'InvalidParameterException':
            logger.error("The request had invalid params: %s", e)
        elif e.response['Error']['Code'] == 'DecryptionFailure':
            logger.error("The requested secret can't be decrypted using the provided KMS key: %s", e)
        elif e.response['Error']['Code'] == 'InternalServiceError':
            logger.error("An error occurred on service side: %s", e)
        raise e
    else:
        # Decrypts secret using the associated KMS CMK.
        # Depending on whether the secret is a string or binary, one of these fields will be populated.
        if 'SecretString' in get_secret_value_response:
            return get_secret_value_response['SecretString']
        else:
            return base64.b64decode(get_secret_value_response['SecretBinary'])
