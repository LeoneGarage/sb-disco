def read_file_from_local(file_path: str, mode='r'):
    with open(file_path, mode) as file:
        data = file.read()
        return data


def write_file_to_local(file_path: str, content: str):
    with open(file_path, 'w') as file:
        file.write(content)
