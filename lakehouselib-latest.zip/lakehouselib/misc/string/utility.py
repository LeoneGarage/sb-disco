import logging
logger = logging.getLogger(__name__)

def strip_char_from_string(str, char='/'):
    """Strip char from the head and tail of a string

        Parameters
        ----------
        str : str

        char : char
            char to be stripped

        Returns
        -------
        return_value : str
            
    """

    try:
        if str[-1] == char:
            str = str[0:-1]

        if str[0] == char:
            str = str[1:]

        return str

    except Exception as exp:
        logger.error (exp)
        raise exp
