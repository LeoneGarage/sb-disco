import json
import requests
from logging import Logger


def generate_urlencoded(payload_config: dict) -> str:
    """Used to create a urlencoded API payload

    Args:
        payload_config (dict): Contains API parameters

    Returns:
        str: Payload formatted as a string
    """
    payload = ""

    for key in payload_config:
        payload += key + "=" + payload_config[key] + "&"

    return payload[:-1]


def get_auth_token(
        logger: Logger,
        base_url: str,
        auth_path: str,
        auth_details: str,
        payload_config: dict) -> dict:
    """Retrieve API authorization token

    Args:
        logger (Logger): To display code logs
        base_url (str): API base URL
        auth_path (str): API authentication endpoint
        auth_details (str): Header content type that will determine payload
        payload_config (dict): Authorization information (account, pass, id, secret)

    Returns:
        dict: Request response.text with token information
    """
    # Authentication full URL & headers
    url = ("{0}/{1}").format(base_url.rstrip('/'), auth_path)
    headers = {'accept': "application/json", 'content-type': auth_details}

    # Authentication payload
    auth_payload = None

    if auth_details == "application/x-www-form-urlencoded":
        auth_payload = generate_urlencoded(payload_config)
    elif auth_details == "application/json":
        auth_payload = json.dumps(payload_config)
    else:
        logger.error(f"Payload type {auth_details} not recognized")

    # Call API
    try:
        response = {}
        response = requests.post(url, data=auth_payload, headers=headers)
        response = response.json()
    except Exception as e:
        logger.error(f"Error {e}")

    return response


def execute_request(
        logger: Logger,
        url: str,
        headers: dict,
        body,
        verb="get",
        max_tries=2) -> dict:
    """Used to perform an API request

    Args:
        logger (Logger): To display code logs
        url (str): Entire URL (base url + endpoint)
        headers (dict): Contains authorization token
        body (_type_): Contains query to perform on endpoint
        verb (str, optional): Type of request. Defaults to "get".

    Returns:
        dict: All fields in request response.text
    """
    response = None
    logger.info(
        f"Execute request...\n"
        f"URL: {url}\n"
        f"Body: {body}\n"
    )

    for retry_attempt in range(1, max_tries + 1):
        try:
            if verb == "get":
                response = requests.get(url, params=body, headers=headers)
            elif verb == "post":
                response = requests.post(url, data=body, headers=headers)
            else:
                logger.info("API Request verb not available")

            if response is not None and response.status_code == 200:
                return json.loads(response.text)
            else:
                logger.warn(f"Retry {retry_attempt} of {max_tries} failed. Response: {json.loads(response.text)}")
        except Exception as e:
            logger.error(f"Retry {retry_attempt} of {max_tries} failed. Error: {e}")
            continue

    return None
