import logging
import boto3
import json
import paramiko
import base64
from io import StringIO

from lakehouselib.services.aws.s3.utility import is_s3_file, read_file_from_s3
from lakehouselib.services.aws.ssm.utility import get_secret
from lakehouselib.misc.file.utility import read_file_from_local

logger = logging.getLogger(__name__)

HOSTNAME = "hostname"
USERNAME = "username"
PASSWORD = "password"
PORT = "port"

logger = logging.getLogger(__name__)


class Utility:

    def __init__(self, sftp_connection_secret_id: str,
                 aws_region="ap-southeast-2",
                 private_key_secret_id: str = None,
                 key_auth: bool = False):
        """Encrypt file to a given sftp server, current support Password-based authentication,
           Public key-based authentication with RSA key.
                sftp_connection_secret_id : str
                sftp_connection_secret_id for storing user information in secret manager,
                password is password for the username for Password-based authentication,
                when using public key-based authentication password is passphrase for private key:
                this is an example
                    { hostname: test.server
                      username: test_username
                      password: password123
                      port:	22
                    }
                aws_region: str
                private_key_secret_id : str
                sftp_connection_secret_id  for storing private key if using public key-based auth, the key need
                to be base64 encoded
                key_auth: set to true if using public key-based auth
                """
        self.sftp_connection_secret_id = sftp_connection_secret_id
        self.private_key_secret_id = private_key_secret_id
        self.aws_region = aws_region
        self.key_auth = key_auth

    def fetch_and_upload(self, source_file_path: str, target_file_path: str):
        """whether read file from s3 or local depends on path passed.

                 Parameters
                     ----------
                     source_file_path : str
                         full path of file require uploading
                     target_file_path :
                         full target path storing file in sftp

                 """
        try:

            if is_s3_file(source_file_path):
                source_data = read_file_from_s3(source_file_path).decode()
            else:
                source_data = read_file_from_local(source_file_path)

            self.__upload_file_to_sftp(target_file_path, source_data)

        except Exception as exp:
            logger.error(exp)
            raise exp

    def __upload_file_to_sftp(self, file_path: str, content: str):
        hostname, username, password, port = self.__read_sftp_connection_from_ssm()

        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        private_key = None

        if self.key_auth:
            key = self.__read_key_from_ssm()
            private_key = paramiko.RSAKey.from_private_key(StringIO(base64.b64decode(key).decode()), password=password)

        ssh.connect(hostname=hostname,
                    port=port,
                    username=username,
                    password=password,
                    pkey=private_key)

        sftp = ssh.open_sftp()
        sftp.putfo(StringIO(str(content)), file_path)
        sftp.close()

    def __read_sftp_connection_from_ssm(self):
        aws_client_secretsmanager = boto3.client(service_name='secretsmanager', region_name=self.aws_region)

        secret = get_secret(logger, aws_client_secretsmanager, self.sftp_connection_secret_id)

        secret_json = json.loads(secret)
        hostname = secret_json.get(HOSTNAME)
        username = secret_json.get(USERNAME)
        port = secret_json.get(PORT)
        password = secret_json.get(PASSWORD, None)

        return hostname, username, password, port

    def __read_key_from_ssm(self):
        aws_client_secretsmanager = boto3.client(service_name='secretsmanager', region_name=self.aws_region)

        key = get_secret(logger, aws_client_secretsmanager, self.private_key_secret_id)

        return key
