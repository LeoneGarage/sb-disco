import traceback

from lakehouselib.system.exception.handler import LakehouseError


def read_from_kafka(spark, job_vars):
    """Setups up and configures a Spark Structured Streaming dataframe connected to Kafka

    Parameters
    ----------
    spark : org.apache.spark
        The SparkSession object constructed created from `main.py`

    job_vars: util.config.stream.jobconfiguration class JobVariables
        All the required job variables to be used through out the job (JobVariables() -> job_vars)

    Returns
    -------
    df : org.apache.spark.sql.DataFrame
        A Spark Structured Streaming enabled and configured DataFrame for Kafka
    """
    try:
        df = (
            spark.readStream.format("kafka")
                .option("kafka.bootstrap.servers", job_vars.kafka_broker_endpoint)
                .option("kafka.group.id", f'{job_vars.job_name}-{job_vars.kafka_topic}')
                .option("kafka.security.protocol", "SSL")
                .option("kafka.ssl.truststore.location", job_vars.kafka_ssl_truststore_location)
                .option("kafka.ssl.truststore.password", job_vars.truststore_password)
                .option("kafka.ssl.keystore.location", job_vars.kafka_ssl_keystore_location)
                .option("kafka.ssl.keystore.password", job_vars.keystore_password)
                .option("subscribe", job_vars.topic)
                .option("startingOffsets", job_vars.startingOffsets)
                .option("maxOffsetsPerTrigger", job_vars.maxoffsetpertrigger)
                .option("failOnDataLoss", job_vars.failondataloss)
                .load()
        )
        return df
    except LakehouseError:
        err_msg = "Can't read from kafka topic`{}`".format(job_vars.topic)
        raise LakehouseError(trace_err=traceback.format_exc(), err_nbr='1.3', err_msg=err_msg, job_vars=job_vars)
