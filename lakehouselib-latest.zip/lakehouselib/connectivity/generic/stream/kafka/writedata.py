"""
Python script to write data to kafka
"""


import traceback

from lakehouselib.system.exception.handler import LakehouseError


def write_batch_to_kafka(job_vars, df_batch):
    """Writes a spark dataframe  to Kafka

    Parameters
    ----------

    job_vars: A dictionary of all the required job variables to be used through out the job

    df_batch: A dataframe having key and value as columns, where key is the  primary (unique)
           key that can be used to perform de-duplication when reading
           and value is the  data to be written to kafka

    Returns
    -------
    None
    """
    try:
        df_batch\
            .selectExpr("CAST(key AS STRING)", "CAST(value AS STRING)") \
            .write \
            .format("kafka") \
            .option("kafka.bootstrap.servers", job_vars["kafka_brokers"]) \
            .option("kafka.security.protocol", "SSL").option("ssl.truststore.type", "JKS") \
            .option("kafka.ssl.truststore.location", job_vars["truststore_location"]) \
            .option("kafka.ssl.truststore.password", job_vars["store_pass"]) \
            .option("kafka.ssl.keystore.location", job_vars["keystore_location"]) \
            .option("kafka.ssl.keystore.password", job_vars["store_pass"]) \
            .option("topic", job_vars["topic"]) \
            .save()
    except LakehouseError:
        err_msg = f'Cannot write to kafka topic {job_vars["topic"]}'
        raise LakehouseError(trace_err=traceback.format_exc(),
                             err_nbr='1.3', err_msg=err_msg, job_vars=job_vars)
