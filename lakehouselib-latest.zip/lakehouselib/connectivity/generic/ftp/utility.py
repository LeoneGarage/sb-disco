import boto3
import logging
import json
import ftplib
from io import BytesIO

from lakehouselib.services.aws.s3.utility import is_s3_file, read_file_from_s3
from lakehouselib.services.aws.ssm.utility import get_secret
from lakehouselib.misc.file.utility import read_file_from_local

HOSTNAME = "hostname"
USERNAME = "username"
PASSWORD = "password"

logger = logging.getLogger(__name__)


class Utility:

    def __init__(self, secret_id: str, aws_region="ap-southeast-2"):
        self.aws_region = aws_region
        self.secret_id = secret_id

    def fetch_and_upload(self, source_file_path: str, target_file_path: str):
        try:
            if is_s3_file(source_file_path):
                source_data = read_file_from_s3(source_file_path)
            else:
                source_data = read_file_from_local(source_file_path, mode='rb')

            self.__upload_file_to_ftp(target_file_path, source_data)

        except Exception as exp:
            logger.error(exp)
            raise exp

    def __read_ftp_connection_from_ssm(self):
        aws_client_secretsmanager = boto3.client(service_name='secretsmanager', region_name=self.aws_region)

        secret = get_secret(logger, aws_client_secretsmanager, self.secret_id)

        secret_json = json.loads(secret)
        hostname = secret_json.get(HOSTNAME)
        username = secret_json.get(USERNAME)
        password = secret_json.get(PASSWORD)

        return hostname, username, password

    def __upload_file_to_ftp(self, target_file_path: str, source_data: bytes):
        hostname, username, password = self.__read_ftp_connection_from_ssm()

        ftp_server = ftplib.FTP(hostname, username, password)
        ftp_server.storbinary(f"STOR {target_file_path}", BytesIO(source_data))
        ftp_server.quit()
        