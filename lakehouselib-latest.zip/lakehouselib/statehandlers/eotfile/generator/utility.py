from botocore.exceptions import ClientError
import json
from urllib.parse import urlparse
import time
from datetime import datetime, timedelta
from lakehouselib.services.aws.sessionmanager.utility import *
from lakehouselib.services.aws.s3.utility import *
from lakehouselib.framework.lakehouse.dynamodb.utility import *

import pytz
from dateutil.relativedelta import relativedelta
import sys


client_session = create_aws_session()



def generate_delta_file_eot(delta_table_path, client, DeltaTable, spark):
    """
    :param delta_table_path: eg: s3://s3bucket/path_to_table/
    :param client:  - instance of boto3 aws session
    :param DeltaTable: - instance of DeltaTable object
    :param spark: - instance of spark object
    :return: eot_content
    """
    o = urlparse(delta_table_path, allow_fragments=False)
    s3bucket = o.hostname
    table_path = o.path
    deltaTable = DeltaTable.forPath(spark, delta_table_path)
    lastOperationDF = deltaTable.history(1)
    deltaLog = lastOperationDF.toJSON().collect()
    log = json.loads(deltaLog[0])
    version = str(log['version'])
    version_len = len(version)
    default_log = '00000000000000000000'  ## Default max length
    log_file = default_log[:-version_len] + version
    prefix = table_path + '/_delta_log/'
    logPath = prefix + log_file + '.json'
    contents = get_log_file(s3bucket, logPath, client_session)
    eot_content = {}
    file_list = []
    for line in contents.splitlines():
        line = json.loads(line)
        if 'commitInfo' in line:
            eot_content['process_dttm'] = str(line['commitInfo']['timestamp'])
            eot_content['process_tz'] = 'UTC'
            eot_content['numFiles'] = line['commitInfo']['operationMetrics']['numFiles']
            eot_content['numOutputBytes'] = line['commitInfo']['operationMetrics']['numOutputBytes']
            eot_content['numOutputRows'] = line['commitInfo']['operationMetrics']['numOutputRows']
        elif 'protocol' in line:
            print('protocol')
        elif 'metaData' in line:
            eot_content['data_format_type'] = line['metaData']['format']['provider']
            # eot_content['schema'] = json.dumps(line['metaData']['schemaString']) # not all will have schema - if parquet - schema is present but requires type treatment
            if len(line['metaData']['partitionColumns']) > 0:
                partitionColumns = []
                for part in line['metaData']['partitionColumns']:
                    partitionColumns.append(part)
                eot_content['partitionColumns'] = partitionColumns
        elif 'add' in line:
            file_list.append(table_path + line['add']['path'])
    eot_content['file_list'] = file_list
    return eot_content




def generate_delta_batch_eot(delta_table_path, client_session, DeltaTable, spark, jobArgs):
        """
        :param delta_table_path: delta table s3 path
        :param client_session:  - instance of boto3 aws session
        :param DeltaTable: - instance of DeltaTable object
        :param spark: - instance of spark object
        :param jobArgs: - dict containing the job required arguments
        [batch_id, dataDeliveryName, producer_type, custodian, custodian_contact, jobRunId]
        :return: eot_content
        """
        numTargetRowsInserted = 0
        numTargetRowsUpdated = 0
        numOutputRows = 0
        numTargetRowsDeleted =0

        valid_delta_operations = ['WRITE', 'MERGE']
        num_versions = 100
        o = urlparse(delta_table_path, allow_fragments=False)
        s3bucket = o.hostname
        table_path = o.path
        schema_name = table_path.split('/')[1]
        table_name = table_path.split('/')[2]
        deltaTable = DeltaTable.forPath(spark, delta_table_path)
        lastOperationDF = deltaTable.history(num_versions)
        lastOperationDF = lastOperationDF.filter(lastOperationDF['operation'].isin(valid_delta_operations)).orderBy(
            lastOperationDF['version'].desc()).limit(1)
        deltaLog = lastOperationDF.toJSON().collect()
        print(deltaLog)
        log = json.loads(deltaLog[0])
        version = str(log['version'])
        version_len = len(version)
        default_log = '00000000000000000000'  ## Default max length
        log_file = default_log[:-version_len] + version
        logPath = table_path[1:] + '/_delta_log/' + log_file + '.json'
        contents = get_log_file(s3bucket, logPath, client_session)
        for line in contents.splitlines():
            if 'commitInfo' in line:
                if json.loads(line)['commitInfo']['operation'] == 'WRITE':
                    numTargetRowsInserted = int(json.loads(line)['commitInfo']['operationMetrics']['numOutputRows'])
                    print("Inserted :" + str(numTargetRowsInserted))
                    eot_content = {}
                    part_values = []
                    part_name = []
                    for line in contents.splitlines():
                        if '"add"' in line:
                            dict_line = json.loads(line)['add']
                            for k, v in enumerate(dict_line['partitionValues']):
                                part_value = dict_line['partitionValues'][v]
                                if part_value is not None:
                                    part_name.append(v)
                                    part_values.append(part_value)
                    # Keep unique values
                    if len(part_name) == 0:
                        part_name = set(['1'])
                        part_values = set(['1'])
                    else:
                        part_name = set(part_name)
                        part_values = set(part_values)
                    # If partition column name does not come from delta log add the lakehouse entry
                    if list(part_name)[0] == '1':
                        part_name.remove('1')
                        part_name.add(jobArgs.get('partition_column', '1'))
                    batchId = jobArgs['batch_id']
                    dataDeliveryName = jobArgs['dataDeliveryName']
                    producer_type = jobArgs['producer_type']
                    s3_bucket = s3bucket
                    num_partitions = len(part_values)
                    data_producer = jobArgs['data_producer']
                    custodian = jobArgs['custodian']
                    custodian_contact = jobArgs['custodian_contact']
                    jobRunId = jobArgs['jobRunId']
                    delivery_eot_file = schema_name + '.' + table_name + '_' + str(batchId) + '.eot'
                    delivery_eot_file_path = 'eot/' + schema_name + '.' + table_name + '/' + delivery_eot_file

                    eot_content = {
                        "process_dttm": str(datetime.fromtimestamp(time.time()).strftime("%Y-%m-%d %H:%M:%S")),
                        "data_delivery_name": dataDeliveryName,
                        "delivery_eot_file": delivery_eot_file,
                        "delivery_eot_file_path": delivery_eot_file_path,
                        "bucket_name": s3_bucket,
                        "batch": {
                            "batchId": batchId,
                            "delta_table_path": delta_table_path,
                            "partitionIds": {
                                list(part_name)[0]: list(part_values)
                            }
                        },
                        "process_tz": 'UTC',
                        "s3_bucket": s3_bucket,
                        'num_partitions': num_partitions,
                        "data_producer": data_producer,
                        "custodian": custodian,
                        "custodian_contact": custodian_contact,
                        "producer_type": producer_type,
                        "producer_job_id": jobRunId
                    }
                    try:
                        if numTargetRowsInserted > 0:
                            print("Run Put")
                            put_eot_file(delta_table_path, eot_content, client_session, batchId)
                        elif numTargetRowsInserted == 0:
                            print(" No EOT file will be create because no rows were inserted or updated")
                    except ClientError as e:
                        print("Unexpected error: %s" % e)
                elif json.loads(line)['commitInfo']['operation'] == 'MERGE':
                    numTargetRowsDeleted = int(json.loads(line)['commitInfo']['operationMetrics']['numTargetRowsDeleted'])
                    numTargetRowsInserted = int(json.loads(line)['commitInfo']['operationMetrics']['numTargetRowsInserted'])
                    numTargetRowsUpdated = int(json.loads(line)['commitInfo']['operationMetrics']['numTargetRowsUpdated'])
                    numOutputRows = int(json.loads(line)['commitInfo']['operationMetrics']['numOutputRows'])
                    print("deleted : " + str(numTargetRowsDeleted))
                    print("inserted : " + str(numTargetRowsInserted))
                    print("updated : " + str(numTargetRowsUpdated))
                    print("numOutputRows : " + str(numOutputRows))
                    print(line)
                    print(numTargetRowsDeleted)
                    print(numTargetRowsInserted)
                    print(numTargetRowsUpdated)
                    eot_content = {}
                    part_values = []
                    part_name = []
                    for line in contents.splitlines():
                        if '"add"' in line:
                            dict_line = json.loads(line)['add']
                            for k, v in enumerate(dict_line['partitionValues']):
                                part_value = dict_line['partitionValues'][v]
                                if part_value is not None:
                                    part_name.append(v)
                                    part_values.append(part_value)
                    # Keep unique values
                    if len(part_name) == 0:
                        part_name = set(['1'])
                        part_values = set(['1'])
                    else:
                        part_name = set(part_name)
                        part_values = set(part_values)
                    # If partition column name does not come from delta log add the lakehouse entry
                    if list(part_name)[0] == '1':
                        part_name.remove('1')
                        part_name.add(jobArgs.get('partition_column', '1'))
                    batchId = jobArgs['batch_id']
                    dataDeliveryName = jobArgs['dataDeliveryName']
                    producer_type = jobArgs['producer_type']
                    s3_bucket = s3bucket
                    num_partitions = len(part_values)
                    data_producer = jobArgs['data_producer']
                    custodian = jobArgs['custodian']
                    custodian_contact = jobArgs['custodian_contact']
                    jobRunId = jobArgs['jobRunId']
                    delivery_eot_file = schema_name + '.' + table_name + '_' + str(batchId) + '.eot'
                    delivery_eot_file_path = 'eot/' + schema_name + '.' + table_name + '/' + delivery_eot_file

                    eot_content = {
                        "process_dttm": str(datetime.fromtimestamp(time.time()).strftime("%Y-%m-%d %H:%M:%S")),
                        "data_delivery_name": dataDeliveryName,
                        "delivery_eot_file": delivery_eot_file,
                        "delivery_eot_file_path": delivery_eot_file_path,
                        "bucket_name": s3_bucket,
                        "batch": {
                            "batchId": batchId,
                            "delta_table_path": delta_table_path,
                            "partitionIds": {
                                list(part_name)[0]: list(part_values)
                            }
                        },
                        "process_tz": 'UTC',
                        "s3_bucket": s3_bucket,
                        'num_partitions': num_partitions,
                        "data_producer": data_producer,
                        "custodian": custodian,
                        "custodian_contact": custodian_contact,
                        "producer_type": producer_type,
                        "producer_job_id": jobRunId
                    }
                    try:
                        if numTargetRowsInserted + numTargetRowsUpdated + numOutputRows > 0:
                            print("Run Put")
                            put_eot_file(delta_table_path, eot_content, client_session, batchId)
                        elif numTargetRowsInserted + numTargetRowsUpdated + numOutputRows == 0:
                            print(" No EOT file will be create because no rows were inserted or updated")

                    except ClientError as e:
                        print("Unexpected error: %s" % e)
        
        return numTargetRowsInserted, numTargetRowsUpdated, numOutputRows, numTargetRowsDeleted, version




def generate_delta_batch_eot_multi(logger, delta_table_path, client_session, DeltaTable, spark, jobArgs, no_of_delta_log_files=1, shrink_partitions=0):
    
    """

    This function will be used by pipelines having multiple merges.
    :param delta_table_path: delta table s3 path
    :param client_session:  - instance of boto3 aws session
    :param DeltaTable: - instance of DeltaTable object
    :param spark: - instance of spark object
    :param jobArgs: - dict containing the job required arguments
    :param no_of_history_files: - number of delta logs you want to retrieve to get the partition column values
    :param shrink_partitions: 0/1 if partitions needs to be shrinked, mandatory to pass batchIdColumnName in jobArgs
    [batch_id, dataDeliveryName, producer_type, custodian, custodian_contact, jobRunId]
    :return: eot_content
    """
    numTargetRowsInserted = 0
    numTargetRowsUpdated = 0
    numOutputRows = 0
    numTargetRowsDeleted = 0

    total_numTargetRowsInserted = 0
    total_numTargetRowsDeleted = 0
    total_numTargetRowsUpdated = 0
    total_numOutputRows = 0

    log_path_list = []
    eot_content = {}
    part_values = []
    part_name = []
    version_list = []
    
    valid_delta_operations = ['WRITE', 'MERGE']
    num_versions = 100
    o = urlparse(delta_table_path, allow_fragments=False)
    s3bucket = o.hostname
    table_path = o.path
    schema_name = table_path.split('/')[1]
    table_name = table_path.split('/')[2]
    deltaTable = DeltaTable.forPath(spark, delta_table_path)
    lastOperationDF = deltaTable.history(num_versions)
    table_run_logs_record = get_dynamo_record_from_partition_key(logger, table_table_run_logs, jobArgs['jobRunId'])
    table_version_before = table_run_logs_record.get('table_version_before', -1)
    logger.info('table_version_before: '+str(table_version_before))
    if table_version_before != -1:
        lastOperationDF = lastOperationDF.filter(lastOperationDF['operation'].isin(valid_delta_operations) & (
                    lastOperationDF['version'] > table_version_before)).orderBy(
            lastOperationDF['version'].desc())
        no_of_delta_log_files = lastOperationDF.count()
    else:
        lastOperationDF = lastOperationDF.filter(lastOperationDF['operation'].isin(valid_delta_operations)).orderBy(
            lastOperationDF['version'].desc()).limit(no_of_delta_log_files)
    deltaLog = lastOperationDF.toJSON().collect()
    default_log = '00000000000000000000'  ## Default max length

    # Required for the eot content
    batchId = jobArgs['batch_id']
    dataDeliveryName = jobArgs['dataDeliveryName']
    producer_type = jobArgs['producer_type']
    s3_bucket = s3bucket
    data_producer = jobArgs['data_producer']
    custodian = jobArgs['custodian']
    custodian_contact = jobArgs['custodian_contact']
    jobRunId = jobArgs['jobRunId']
    delivery_eot_file = schema_name + '.' + table_name + '_' + str(batchId) + '.eot'
    delivery_eot_file_path = 'eot/' + schema_name + '.' + table_name + '/' + delivery_eot_file
    
    # This will store the filepath of logs to a list for processing later     
    for i in range(0, no_of_delta_log_files, 1):
        log = json.loads(deltaLog[i])
        version = str(log['version'])
        version_len = len(version)
        log_file = default_log[:-version_len] + version
        logPath = table_path[1:] + '/_delta_log/' + log_file + '.json'
        log_path_list.append(logPath)
        # this is to have a list of versions to be stored in lakehouse_table_run_logs
        version_list.append(version)
    
    # Loop through the list of files and get the partition column values
    for log_path in log_path_list:
        contents = get_log_file(s3bucket, log_path, client_session)
    
        for line in contents.splitlines():
            if 'commitInfo' in line:
                if json.loads(line)['commitInfo']['operation'] == 'WRITE':
                    numTargetRowsInserted = int(json.loads(line)['commitInfo']['operationMetrics']['numOutputRows'])
                    logger.info("Inserted :" + str(numTargetRowsInserted))
                
                elif json.loads(line)['commitInfo']['operation'] == 'MERGE':
                    numTargetRowsDeleted = int(json.loads(line)['commitInfo']['operationMetrics']['numTargetRowsDeleted'])
                    numTargetRowsInserted = int(json.loads(line)['commitInfo']['operationMetrics']['numTargetRowsInserted'])
                    numTargetRowsUpdated = int(json.loads(line)['commitInfo']['operationMetrics']['numTargetRowsUpdated'])
                    numOutputRows = int(json.loads(line)['commitInfo']['operationMetrics']['numOutputRows'])
                    logger.info("deleted : " + str(numTargetRowsDeleted))
                    logger.info("inserted : " + str(numTargetRowsInserted))
                    logger.info("updated : " + str(numTargetRowsUpdated))
                    logger.info("numOutputRows : " + str(numOutputRows))
                
            if '"add"' in line:
                dict_line = json.loads(line)['add']
                for k, v in enumerate(dict_line['partitionValues']):
                    part_value = dict_line['partitionValues'][v]
                    if part_value is not None:
                        part_name.append(v)
                        part_values.append(part_value)    

        total_numTargetRowsInserted += numTargetRowsInserted
        total_numTargetRowsDeleted += numTargetRowsDeleted
        total_numTargetRowsUpdated += numTargetRowsUpdated
        total_numOutputRows += numOutputRows
    
    # After processing all the log files and getting the partition column values, keep unique values
    if len(part_name) == 0:
        part_name = set(['1'])
        part_values = set(['1'])
    else:
        part_name = set(part_name)
        part_values = set(part_values)
    # If partition column name does not come from delta log add the lakehouse entry
    if list(part_name)[0] == '1':
        part_name.remove('1')
        part_name.add(jobArgs.get('partition_column', '1'))

    num_partitions = len(part_values)
    # This is to handle the eot of source tables without any partition column
    # we need to have an empty dict on partitionIds
    partitionIds = {}
    if list(part_name)[0] != '1':
        partitionIds = {list(part_name)[0] : list(part_values)}

    if shrink_partitions == 1:
        where_clause = ' where ' + jobArgs['batchIdColumnName'] + '=\'' + batchId + '\' and ' + str(
            list(part_name)[0]) + ' in ' + str(list(part_values)).replace('[', '(').replace(']', ')')
        logger.info(f"select distinct cast({list(part_name)[0]} as string) from {schema_name}.{table_name} {where_clause} ")
        shrink_part_values = spark.sql(
            f"select distinct cast({list(part_name)[0]} as string) from {schema_name}.{table_name} {where_clause} ").collect()

        if len(shrink_part_values) > 0:
            partitionIds = {list(part_name)[0]: [pv[0] for pv in shrink_part_values]}
            logger.info('After shrinking partitions: ' + str(partitionIds))
        else:
            logger.info('No updated records found after shrinking partitions')
            total_numTargetRowsInserted = 0
            total_numTargetRowsDeleted = 0
            total_numTargetRowsUpdated = 0
            total_numOutputRows = 0

    # Construct the eot content
    eot_content = {
        "process_dttm": str(datetime.fromtimestamp(time.time()).strftime("%Y-%m-%d %H:%M:%S")),
        "data_delivery_name": dataDeliveryName,
        "delivery_eot_file": delivery_eot_file,
        "delivery_eot_file_path": delivery_eot_file_path,
        "bucket_name": s3_bucket,
        "batch": {
            "batchId": batchId,
            "delta_table_path": delta_table_path,
            "partitionIds": partitionIds

        },
        "process_tz": 'UTC',
        "s3_bucket": s3_bucket,
        'num_partitions': num_partitions,
        "data_producer": data_producer,
        "custodian": custodian,
        "custodian_contact": custodian_contact,
        "producer_type": producer_type,
        "producer_job_id": jobRunId
        }   
    
    try:
        if total_numTargetRowsInserted + total_numTargetRowsDeleted + total_numTargetRowsUpdated + total_numOutputRows > 0:
            logger.info("Run Put")
            put_eot_file(delta_table_path, eot_content, client_session, batchId)
        elif numTargetRowsInserted == 0:
            logger.info(" No EOT file will be created because no rows were inserted or updated")
    except ClientError as e:
        logger.error("Unexpected error: %s" % e)

    return total_numTargetRowsInserted, total_numTargetRowsUpdated, total_numOutputRows, total_numTargetRowsDeleted, str(version_list)


def get_delta_table_version(target_s3_location, DeltaTable, spark):
    """This function gets the latest delta table version
    Args:
        target_s3_location (_type_): s3 path of the table

    Returns:
        version: table version
        
    """
    version = -1
    delta_table_path = target_s3_location
    deltaTable = DeltaTable.forPath(spark, delta_table_path)
    valid_delta_operations = ['WRITE', 'MERGE']
    lastOperationDF = deltaTable.history(100)
    lastOperationDF = lastOperationDF.filter(lastOperationDF['operation'].isin(valid_delta_operations)).orderBy(
            lastOperationDF['version'].desc()).limit(1)
    deltaLog = lastOperationDF.toJSON().collect()
    if len(deltaLog) > 0:
        log = json.loads(deltaLog[0])
        version = str(log['version'])
    
    return version


def generate_report_eot_master(logger, client_session, batch_id):
    """
    This function will be used to generate eot for reports which pass validation.
    param client_session:  - instance of boto3 aws session
    param validation_dttm: - report date
    return: eot_content

    """
    try:
        tz = pytz.timezone('Australia/Darwin')
        today_darwin_dt = datetime.strptime(datetime.now(tz).date().strftime("%Y-%m-%d"), '%Y-%m-%d')
        # today_darwin_dt = datetime.strptime('2022-11-16', '%Y-%m-%d')

        resp = table_table_config.query(
            IndexName="batch_name-index",
            ProjectionExpression='table_id, batch_name, force_run, generate_eot, report_dep_objs, report_group, target_schema_name, target_table_name, target_s3_location, run_frequency, is_active, run_time',
            ScanIndexForward=False,
            KeyConditionExpression="batch_name = :batch_name",
            FilterExpression="is_active <> :is_active",
            ExpressionAttributeValues={
                ":batch_name": 'reporting',
                ":is_active": False}
        )
        reports = resp['Items']
        while 'LastEvaluatedKey' in resp:
            resp = table_table_config.query(
                IndexName="batch_name-index",
                ProjectionExpression='table_id, batch_name, force_run, generate_eot, report_dep_objs, report_group, target_schema_name, target_table_name, target_s3_location, run_frequency, is_active, run_time',
                ScanIndexForward=False,
                KeyConditionExpression="batch_name = :batch_name",
                FilterExpression="is_active <> :is_active",
                ExpressionAttributeValues={
                    ":batch_name": 'reporting',
                    ":is_active": False
                }, ExclusiveStartKey=resp['LastEvaluatedKey']
            )
            reports = reports + resp['Items']
        validation_dttm = ''
        for report in reports:
            try:
                logger.info("checking report: " + str(report))
                run_frequency = str(report['run_frequency'].split('|')[0]).lower()
                run_time = datetime.strptime(str(report.get('run_time', '0000')), '%H%M').time()
                validate_dttm_to = today_darwin_dt - timedelta(days=1)
                dep_status_logger = {}
                delivery_eot_file_path = ''
                if run_frequency == 'weekly':
                    logger.info("Weekly Report")
                    validate_dttm_from = validate_dttm_to - timedelta(weeks=1)
                    run_report = True if today_darwin_dt.weekday() == int(report['run_frequency'].split('|')[1]) else False
                elif run_frequency == 'biweekly':
                    validate_dttm_from = validate_dttm_to - timedelta(weeks=2)
                elif run_frequency == 'monthly':
                    logger.info("Monthly Report")
                    validate_dttm_from = validate_dttm_to - relativedelta(months=1)
                    run_report = True if today_darwin_dt.strftime("%d") == str(
                        report['run_frequency'].split('|')[1]) else False
                elif run_frequency == 'daily':
                    logger.info("Daily Report")
                    validate_dttm_from = validate_dttm_to
                    run_report = True
                else:
                    raise Exception("Please correct run_frequency in lakehouse table config for " + report['table_id'])
                validation_dttm = str(validate_dttm_from) + " - " + str(validate_dttm_to)
                logger.info("validation_dttm: " + str(validation_dttm))

                if not run_report or check_validation_status(logger, table_table_run_logs, report['table_id'], validation_dttm)[
                           'is_complete']:
                    continue
                all_dep_complete = True
                for dep in report.get('report_dep_objs', []):
                    dep_validate_dttm_from = validate_dttm_from
                    dep_validate_dttm_to = validate_dttm_to
                    incr_day = timedelta(days=1)
                    while dep_validate_dttm_from <= dep_validate_dttm_to:
                        logger.info("Checking Dep " + dep + " for " + str(dep_validate_dttm_from))
                        dep_dttm_status = \
                        check_validation_status(logger, table_table_run_logs, dep, str(dep_validate_dttm_from), 60)[
                            'is_complete']
                        if not dep_dttm_status:
                            dep_status_logger[dep + '-' + str(dep_validate_dttm_from)] = 'Validation failed'
                        all_dep_complete = all_dep_complete * dep_dttm_status
                        dep_validate_dttm_from += incr_day
                logger.info("all_dep_complete: " + str(all_dep_complete))
                validation_status = {"is_complete": False, "desc": str(dep_status_logger)}

                if (all_dep_complete and datetime.now(tz).time() > run_time) or report.get('force_run', False):
                    logger.info("Generate EOT")
                    pipeline_config = query_pipeline_config(table_pipeline_config, report['table_id'])
                    dep_name = pipeline_config['pipeline_dependencies'][0]['name']
                    logger.info("dep_name: "+str(dep_name))
                    data_delivery_name = table_ed_dep_config.query(
                        KeyConditionExpression="dep_name = :dep_name",
                        ExpressionAttributeValues={
                            ":dep_name": dep_name
                        })['Items'][0]['data_delivery_name']
                    logger.info("data_delivery_name: "+str(data_delivery_name))
                    delta_table_path = '{}/{}/{}'.format(report['target_s3_location'], report['target_schema_name'],
                                                         report['target_table_name'])
                    delivery_eot_file = report['target_schema_name'] + '.' + report['target_table_name'] + '_' + str(
                        batch_id) + '.eot'
                    delivery_eot_file_path = 'eot/' + report['target_schema_name'] + '.' + report[
                        'target_table_name'] + '/' + delivery_eot_file
                    # Construct the eot content
                    eot_content = {
                        "process_dttm": str(datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
                        "data_delivery_name": data_delivery_name,
                        "delivery_eot_file": delivery_eot_file,
                        "delivery_eot_file_path": delivery_eot_file_path,
                        "bucket_name": report['target_s3_location'],
                        "batch": {
                            "batchId": batch_id,
                            "delta_table_path": delta_table_path,
                            "partitionIds": {"report_dttm": [str(validate_dttm_from.date()), str(validate_dttm_to.date())]}
                        },
                        "process_tz": 'UTC',
                        "s3_bucket": report['target_s3_location'],
                        'num_partitions': 1,
                        "data_producer": 'validation master',
                        "custodian": 'Team Vulcan',
                        "custodian_contact": 'TeamVulcan@sportsbet.com.au',
                        "producer_type": 'reporting',
                        "producer_job_id": batch_id
                    }
                    put_eot_file(delta_table_path, eot_content, client_session, batch_id)
                    validation_status = {"is_complete": True}
                kwargs_table = {'ctl_run_id': batch_id + '_' + report['table_id'], 'ctl_table_run_status': 'SUCCESS',
                                'table_id': report['table_id'],
                                'ctl_batch_id': batch_id,
                                'ctl_table_run_start_time': (datetime.now()).strftime('%Y-%m-%d %H:%M:%S'),
                                'ctl_table_run_end_time': (datetime.now()).strftime('%Y-%m-%d %H:%M:%S'),
                                'validation_dttm': validation_dttm,
                                'validation_status': validation_status, 'eot_file_path': delivery_eot_file_path}
                insert_or_update_table(logger, table_table_run_logs, 'ctl_run_id', batch_id + '_' + report['table_id'],
                                       **kwargs_table)
            except Exception as e:
                logger.error(str(e))
                ex_type, ex_value, ex_traceback = sys.exc_info()
                kwargs_table = {'ctl_run_id': batch_id + '_' + report['table_id'], 'ctl_table_run_status': 'FAILED',
                                'table_id': report['table_id'],
                                'ctl_batch_id': batch_id,
                                'ctl_table_run_start_time': (datetime.now()).strftime('%Y-%m-%d %H:%M:%S'),
                                'ctl_table_run_end_time': (datetime.now()).strftime('%Y-%m-%d %H:%M:%S'),
                                'validation_dttm': validation_dttm,
                                'ctl_err_desc': str(ex_value),
                                'ctl_err_code': -1
                                }
                insert_or_update_table(logger, table_table_run_logs, 'ctl_run_id', batch_id + '_' + report['table_id'], **kwargs_table)

    except Exception as exc:
        logger.error("Exeception raised while creating EOT from generate EOT master.")
        logger.error(str(exc))
        raise exc