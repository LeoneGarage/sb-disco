import os
import logging
import traceback

from datetime import datetime
from multiprocessing.pool import ThreadPool
import concurrent
import time

from lakehouselib.framework.lakehouse.dynamodb.utility import *
from lakehouselib.services.aws.s3.utility import *

logging.basicConfig()
logger = logging.getLogger(__name__)


def create_import_empty_tbl_list(s3_session, assets_list):
    '''
    Will return the list of tuple required by cleanup_s3_for_asset function
    :param s3_session: boto3 session object
    :param assets_list: list of dictionaries of assets, subset of pipeline_run  containing only the assets to process
    :return: list of tuples (table_id, s3_session, s3_bucket_name, s3_folder)
    '''
    empty_tbl_list = []
    for asset in assets_list:
        table_id = f"{asset['source_schema']}.{asset['source_table']}"
        s3_bucket_name = asset['target_restore_location'].split('/')[2]
        s3_folder = asset['source_schema'] + '/' + asset['source_table']
        empty_tbl_list.append((table_id, s3_session, s3_bucket_name, s3_folder))
    return empty_tbl_list


def create_export_empty_tbl_list(s3_session, pipeline_config):
    '''
    Will return the list of tuple required by empty_s3_folder function
    :param s3_session: boto3 session object
    :param pipeline_config: pipeline_run_log entry
    :return: list of tuples
    '''
    empty_tbl_list = []
    s3_bucket_name = pipeline_config['export_location'].split('/')[0]
    main_folder = pipeline_config['export_location'].split('/')[1:]
    for asset in pipeline_config['assets_to_clone']:
        source_schema = asset['source_schema']
        source_table = asset['source_table']
        if not main_folder:
            s3_folder = '/' + source_schema + '/' + source_table
        else:
            s3_folder = '/' + main_folder + '/' + source_schema + '/' + source_table
        empty_tbl_list.append((s3_session, s3_bucket_name, s3_folder))
    return empty_tbl_list


def create_copy_parallel_tbl_list(s3_session, target_environment, export_location,  assets_to_copy):
    '''
    Will return the list of tuple required by copy_parallel function
    :param s3_session: boto3 session object
    :param target_environment: env dev/stg
    :param export_location: export location value from log
    :param assets_to_copy: list of dictionaries of assets, subset of pipeline_run  containing only the assets to process
    :return: list of tuples (table_id, s3_session, source_s3_bucket, source_folder, dest_bucket, dest_prefix)
    '''
    copy_parallel_tbl_list = []
    for asset in assets_to_copy:
        source_s3_bucket = export_location.split('/')[0]
        dest_bucket = asset['target_restore_location'].split('/')[2]
        source_folder = export_location.split('/')[1] + '/' + target_environment + '/' + asset['target_restore_location'].split('/')[3] + '/' + \
            asset['target_restore_location'].split('/')[4] + '/'
        table_id = f"{asset['source_schema']}.{asset['source_table']}"
        dest_prefix = asset['source_schema'] + '/' + asset['source_table']
        copy_parallel_tbl_list.append((table_id, s3_session, source_s3_bucket, source_folder, dest_bucket, dest_prefix))
    return copy_parallel_tbl_list


def create_drop_delta_table_tbl_list(logger, spark, assets_list):
    '''
    Will return the list of tuple required by drop_delta_table function
    :param logger: logger object
    :param spark: spark object
    :param assets_list: list of dictionaries of assets, subset of pipeline_run_log  containing only the assets to process
    :return: list of tuples (logger, spark, table)
    '''
    drop_delta_table_tbl_list = []
    for tbl in assets_list:
        table = tbl['source_schema'] + '.' + tbl['source_table']
        drop_delta_table_tbl_list.append((logger, spark, table))
    return drop_delta_table_tbl_list


def create_delta_table_tbl_list(logger, spark, assets_to_create):
    '''
     Will return the list of tuple required by drop_delta_table function
    :param logger: logger object
    :param spark: spark object
    :param assets_to_create: list of dictionaries of assets, subset of pipeline_run_log  containing only the assets to process
    :return: list of tuples (logger, spark, target_s3_bucket, target_folder, source_schema, source_table, partitionColumn)
    '''
    # TODO confirm that is ok to name the target table based on the folder structure in target_restore_location
    # do they always coincide?
    create_delta_table_tbl_list = []
    for asset in assets_to_create:
        target_restore_location = asset['target_restore_location']
        target_s3_bucket = target_restore_location.split("/")[2].lower()
        target_folder = target_restore_location.split("/")[3].lower() + '/' + target_restore_location.split("/")[4].lower()
        source_schema = target_restore_location.split("/")[3].lower()
        source_table = target_restore_location.split("/")[4].lower()
        partitionColumn = asset.get('partitionColumn')
        create_delta_table_tbl_list.append((logger, spark, target_s3_bucket, target_folder, source_schema, source_table, partitionColumn))
    return create_delta_table_tbl_list


def get_source_columns(logger, spark, asset):
    """
    :param logger: object
    :param spark: spark object
    :param asset: object to be cloned information
    :return: list of columns and their data types
    """
    if asset["source_columns"] == "*":
        try:
            df = spark.sql(
                "select * from {}.{} limit 1".format(asset["source_schema"], asset["source_table"])
            )
        except Exception as e:
            logger.error("Error in `get_source_columns`")
            logger.error(e)
    elif asset["source_columns"] != "*":
        df = spark.sql(
            "select {} from {}.{} limit 1".format(
                asset["source_columns"], asset["source_schema"], asset["source_table"]
            )
        )
    return df.dtypes

def update_source_columns(sanitize_list, source_columns):
    """
    :param sanitize_list: list of column to sanize
    :param source_columns: list of source columns
    :return: list of columns to be used in data extraction
    """
    ol = []
    stl = []
    stl_fd = []
    res = []
    for sc in source_columns:
        ol.append("cast(" + sc[0] + " as " + sc[1] + ") as " + sc[0])
    if sanitize_list:
        for sc in source_columns:
            for col_to_sanitize in sanitize_list:
                if col_to_sanitize['table_column'] == sc[0]:
                    # cast sanitazied column to original dtype
                    stl.append("cast(" + col_to_sanitize["sanitized_value"] + " as " + sc[1] + ") as " + sc[0]) 
                    # list with only the sanitazied columns
                    stl_fd.append("cast(" + sc[0] + " as " + sc[1] + ") as " + sc[0])
        # source columns minus sanitezed columns
        cl = [i for i in ol if i not in stl_fd]
        lz = list(enumerate(ol))
        stl_i = [next((sub[0] for sub in lz if sub[1] == i), 0) for i in stl_fd]
        scl_i = [next((sub[0] for sub in lz if sub[1] == i), 0) for i in cl]
        scl_i.sort()
        stl_i.sort()
        # list of sanitized data with original index
        stzi = list(zip(stl_i, stl))
        # list of source columns without sanitized columns with original index
        sczi = list(zip(scl_i, cl))
        l = sczi + stzi
        l.sort()
        for i in l:
            # final result 
            res.append(i[1])
    else:
        res = ol
            
    return ','.join(res)


def generate_extract_sql(logger, asset, updated_source_columns):
    """
    :param asset: object to be cloned information
    :param updated_source_columns: list of columns to be used in data extraction
    :return: sql query string used for data extract
    """
    try:
        sql = "select {} from {}{}".format(
            updated_source_columns,
            asset["source_schema"] + "." + asset["source_table"],
            " where " + asset["filters"] if asset["filters"] != "" else "",
        )
    except Exception as e:
        logger.error("Error in `generate_extract_sql`")
        logger.error(e)
    return sql


def generate_export(logger, asset, export_location):
    """
    :param asset: object to be cloned information
    :param export_location: parameter from pipeline config
    :return: export df command as a string
    """
    try:
        if asset["partitionColumn"] == "":
            export_df = 'df.write.option("header",True).mode("overwrite").parquet("s3://{}/{}/{}/")'.format(
                export_location, asset["source_schema"], asset["source_table"]
            )
        else:
            export_df = 'df.write.option("header",True).partitionBy("{}").mode("overwrite").parquet("s3://{}/{}/{}/")'.format(
                asset["partitionColumn"],
                export_location,
                asset["source_schema"],
                asset["source_table"],
            )
    except Exception as e:
        logger.error("Error in `generate_export`")
        logger.error(e)
    return export_df


def drop_delta_table(logger, spark, table):
    """
    Function will drop the delta table from the catalog
    :param asset: dict with the asset information
    :return: tuple (table_id, status, error_msg) used for collecting results when executed in multithreading
    """
    try:
        spark.sql(
            "DROP TABLE IF EXISTS {}".format(table)
        )
        return (table, 'success', None)
    except Exception as e:
        er_msg = f"Error in `drop_delta_table` for table  {table} {e}"
        logger.error(e)
        return (table, 'failed', er_msg)


def create_delta_table(logger, spark, target_s3_bucket, target_folder, source_schema, source_table, partitionColumn=None):
    """
    Will create a delta table from raw parquet files
      :param logger: logger object
      :param spark: spark object
      :param target_s3_bucket: s3 bucket name
      :param target_folder: target folder
      :param source_schema: table schema
      :param source_table: table name
      :param partitionColumn: partition column name
      :return:  tuple (table_id, status, error_msg) used for collecting results when executed in multithreading
    """
    try:
        if partitionColumn != '':
            spark.sql(
                "CONVERT TO DELTA parquet.`s3://{}/{}/` PARTITIONED BY ({} STRING)".format(
                    target_s3_bucket, target_folder, partitionColumn
                )
            )
            time.sleep(10)
            spark.sql(
                "create table {}.{} using delta location 's3://{}/{}/'".format(
                    source_schema,
                    source_table,
                    target_s3_bucket,
                    target_folder,
                )
            )
            validate_is_delta(logger, spark, source_schema, source_table)
        else:
            spark.sql(
                "CONVERT TO DELTA parquet.`s3://{}/{}/`".format(
                    target_s3_bucket, target_folder
                )
            )
            time.sleep(10)
            spark.sql(
                "create table {}.{} using delta location 's3://{}/{}/'".format(
                    source_schema,
                    source_table,
                    target_s3_bucket,
                    target_folder
                )
            )
            validate_is_delta(logger, spark, source_schema, source_table)
        return (f"{source_schema}.{source_table}", 'success', None)
    except Exception as e:
        msg = f"Error in `create_delta_table` for {source_schema}.{source_table} {e}"
        logger.error(msg)
        return (f"{source_schema}.{source_table}", 'failed', msg)

def get_target_location(logger, spark, asset, target_environment):
    """
    :param logger: logger object
    :param spark: spark object session
    :param asset: object to be cloned information
    :param target_environment: parameter from pipeline config stg/dev
    :return: updated s3 path used for target writes
    """
    try:
        df = spark.sql(
            "DESCRIBE TABLE EXTENDED {}.{}".format(
                asset["source_schema"], asset["source_table"]
            )
        )
    except Exception as e:
        logger.error("Error in `get_target_location`")
        logger.error(e)
        return
    list_persons = map(lambda row: row.asDict(), df.collect())
    for ls in list_persons:
        if ls["col_name"] == "Location":
            target_restore_location = str(ls["data_type"]).replace(
                "prd", target_environment
            )
    return target_restore_location

def validate_rmf_pipeline(pipeline_config, log_pipeline_runs):
    '''
    :param pipeline_config: RMF pipeline configuration from dynamodb
    :return:
    kwargs_table: set initial pipeline log status
    kwargs: input for main export function
    assets_to_clone: list of tables to clone
    '''
    assets_to_retry = []    
    # If pipeline is Inactive exit    
    if pipeline_config['pipeline_status_nm'] != 'active':
        print('Job is Inactive')
        print('Should Exit')
        
    updated_pipeline_config = pipeline_config

    if log_pipeline_runs:
        for asset  in log_pipeline_runs['assets_to_clone']:
            if asset['status'] == 'pending':
                assets_to_retry.append(asset) 
            else:
                if asset['status'] == 'failed':
                    if not asset['error_msg'].startswith('generate_extract_sql'):
                        asset['status'] = 'pending' 
                        assets_to_retry.append(asset)
                
        updated_pipeline_config['assets_to_clone'] = log_pipeline_runs['assets_to_clone']
    else:
        # Set Pipeline log entry
        for asset in updated_pipeline_config['assets_to_clone']:
            asset['status'] = 'pending'

    assets_to_clone = updated_pipeline_config['assets_to_clone']
    
    kwargs_table = updated_pipeline_config
    kwargs_table['pipeline_run_status'] = 'running'
    kwargs_table['pipeline_stage'] = 'export_local'
    
    if  log_pipeline_runs:
        kwargs_table['pipeline_run_id'] = log_pipeline_runs['pipeline_run_id']
    else:
        kwargs_table['pipeline_run_id'] = pipeline_config['pipeline_name'] + '-' + str(datetime.fromtimestamp(time.time()).strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3])

    kwargs_table['last_updated_ts'] = datetime.fromtimestamp(time.time()).strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3]

    try:
        roleArn = os.getenv("deltalake_assume_role_arn")
    except Exception as e:
        logger.error("Error in `Get OS.getenv roleArn`")
        logger.error(e)
        raise e
    # Setup kwargs used by function main_run_local_export()
    kwargs = {}
    kwargs['roleArn'] = roleArn
    kwargs['roleSessionName'] = 'RMF-Clone-Prd-Local'
    kwargs['table_log'] = 'ed_pipeline_log_runs'
    kwargs['table_run_id'] = kwargs_table['pipeline_run_id']
    kwargs['sanitize_config_table_name'] = pipeline_config['sanitize_config_table_name']
    kwargs['target_environment'] = pipeline_config['target_environment']
    kwargs['export_location'] = pipeline_config['export_location'] + '/' + pipeline_config['target_environment']
    kwargs['pipeline_name'] = pipeline_config['pipeline_name']
    return kwargs_table, kwargs, assets_to_clone, assets_to_retry


# #####################################################
# ######## functions used at import
# #####################################################

def validate_is_delta(logger, spark, source_schema, source_table):
    '''
    Function will vlidate that the table is in Delta format
    :param logger: logger object
    :param spark: spark object
    :param source_schema: source schema name
    :param source_table: source table name
    :return: nothing
    '''
    try:
        if spark.sql('describe detail {}.{}'.format(source_schema, source_table)).collect()[0].asDict()['format'] == 'delta':
            pass
        else:
            raise CustomException('{}.{} not in delta format'.format(source_schema, source_table))
    except Exception as e:
        logger.error("Error in `create_delta_table` for " + source_schema + '.' + source_table)
        logger.error(e)


def copy_parallel(table_id, s3_session, src_bucket, src_prefix, dest_bucket, dest_prefix):
    '''
    :param table_id: schema.table_name   
    :param s3_session: s3 client object
    :param src_bucket: source s3 bucket name
    :param src_prefix: source prefix folder
    :param dest_bucket: destination s3 bucket
    :param dest_prefix: destination prefix folder
    :return:  tuple (table_id, status, error_msg)
    '''
    try:
        with concurrent.futures.ThreadPoolExecutor() as executor:
            lst = get_s3_keys(s3_session, src_bucket, src_prefix)
            futures = []
            for s3_key in lst:
                futures.append\
                    (executor.submit(copy_s3_object, s3_session=s3_session, src_bucket=src_bucket, src_prefix=src_prefix,
                     dest_bucket=dest_bucket, dest_prefix=dest_prefix, s3_key=s3_key))
        for future in concurrent.futures.as_completed(futures):
            future.result()
        return (table_id, 'success', None)
    except Exception as exc:
        msg = f'Error copying data for table_id {table_id} {exc}'
        return (table_id, 'failed', msg)


def cleanup_s3_for_asset(table_id, s3_session, s3_bucket_name, s3_folder):
    """
    Will empty a folder from a bucket and returns status and error message for further logging

    :param table_id: schema.table_name   
    :param s3_session: s3 client object
    :param s3_bucket_name: destination s3 bucket
    :param s3_folder: destination folder to cleanup
    :return:  tuple (table_id, status, error_msg)
    """
    try:
        path = f's3://{s3_bucket_name}/{s3_folder}'
        empty_s3_folder(s3_session, s3_bucket_name, s3_folder)
        return (table_id, 'success', None)
    except Exception as exc:
        msg = f'Error deleting content from {path} {exc}'
        return (table_id, 'failed', msg)

# #####################################################
# ######## functions for validating and logging in dynamodb at import 
# #####################################################


def update_pipeline_run_status(logger,  roleArn, roleSessionName, config_table_name,  new_pipeline_run_status, kwargs_table, new_err_msg=None):
    """
    updates the log entry with status success/failed and error message for the pipeline_run_status
    :param logger: logger object
    :param roleArn: role arn used for dynamo access
    :param roleSessionName: role Session Name
    :param config_table_name: dynamodb table name
    :param new_pipeline_run_status: received status success,running,failed
    :param kwargs_table:
    :param new_err_msg:
    :return: kwargs_table the dictionary for log entry updated
    """
    try:
        # todo there is a more elegant method to check for expired token and refresh connection
        dyno_resource = create_session_sts(logger, roleArn, roleSessionName, 'dynamodb', 'resource')
        table_pipeline_log_runs = dyno_resource.Table(config_table_name)
        pipeline_run_id = kwargs_table['pipeline_run_id']
        kwargs_table['pipeline_run_status'] = new_pipeline_run_status
        if new_err_msg:
            kwargs_table['error_msg'] = new_err_msg
        kwargs_table['last_updated_ts'] = datetime.fromtimestamp(time.time()).strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3]
        insert_or_update_table(logger, table_pipeline_log_runs, 'pipeline_name', pipeline_run_id, **kwargs_table)
    except Exception as e:
        # If there is a token expired issue reconnect to dynamodb
        logger.error(f"Error updating pipeline status to {new_pipeline_run_status} {new_err_msg} {e}")
        print(f"Error updating pipeline status to {new_pipeline_run_status}   {new_err_msg}  {e}")
    return kwargs_table


def update_asset_status(logger, roleArn, roleSessionName, config_table_name, step, result, kwargs_table):
    """
    Adds result status for an asset and updates the log in dynamodb
    :param logger: logger object
    :param roleArn: role arn used for dynamo access
    :param roleSessionName: role Session Name
    :param config_table_name: dynamodb table name
    :param step  name of the current step while running import
    :param result is a tuple of form (table_id, status, msg) and is the result of an operation for an asset
    :return kwargs_table the dictionary for log entry updated
    """
    table_id = result[0]
    status = result[1]
    err_msg = result[2]
    assets = kwargs_table['assets_to_clone']
    for item in assets:
        if table_id == f"{item['source_schema']}.{item['source_table']}":
            poz = assets.index(item)  # find the position of the asset in the list to update on the log
            assets[poz]['status'] = status   
            assets[poz]['step'] = step
            # when reaching the last step update status for restore_target key
            if step == 'create_delta_tables':
                assets[poz]['restore_target'] = status 
            assets[poz]['last_updated_ts'] = datetime.fromtimestamp(time.time()).strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3]
            assets[poz]['err_msg'] = err_msg  
            kwargs_table = update_pipeline_run_status(logger,  roleArn, roleSessionName, config_table_name, 'running', kwargs_table)
    return kwargs_table


def resume_pipeline_log_import_target(logger,  roleArn, roleSessionName, config_table_name, pipeline_name, pipeline_run_id):
    """
    validate that the pipeline_log_run_id is corresponding to a log that has all assets exported with success
    mark the assets that needs to be imported with status pending
    and reinitialize statuses, error_msg for the current execution
    :param logger: logger object
    :param roleArn: role arn used for all dynamodb actions
    :param roleSessionName: roleSessionName
    :param config_table_name: dynamodb table (ed_pipeline_log_runs)
    :param pipeline_name: ed pipeline name
    :param pipeline_run_id: ed pipeline run id
    :return kwargs_table the dictionary for log entry updated

    """
    dyno_resource = create_session_sts(logger, roleArn, roleSessionName, 'dynamodb', 'resource')
    pipeline_run = get_pipeline_log_run(logger, dyno_resource, config_table_name, pipeline_name, pipeline_run_id)
    if not pipeline_run:
        raise Exception(f"No Entry in {config_table_name} table for {pipeline_run_id}.")
      
    updated_pipeline_run = pipeline_run
    kwargs_table = updated_pipeline_run
    
    kwargs_table['pipeline_stage'] = 'restore_target'
    kwargs_table['error_msg'] = ''
    pipeline_run_id = pipeline_run['pipeline_run_id']
    assets_to_clone = updated_pipeline_run['assets_to_clone']
    # log the starting of import_to_target and intitialize statuses for restore_target stage
    kwargs_table = update_pipeline_run_status(logger,  roleArn, roleSessionName, config_table_name, 'starting', kwargs_table, ' ')

    # TODO confirm that we want this extra check
    #     if export_local was failed or there is not asset exported with success or all assets were imported with success, exit
    if  pipeline_run.get('pipeline_stage') == 'export_local' and  pipeline_run.get('pipeline_run_status') == 'failed':
        msg = 'restore_target - Export local was failed - will exit now'
        raise Exception(msg)

    export_statuses = []    
    for asset in assets_to_clone:
        export_statuses.append(asset['export_local'])
        
    if 'failed' in set(export_statuses):
        msg = 'restore_target - Not all assets have been exported with success - will exit now'
        kwargs_table = update_pipeline_run_status(logger,  roleArn, roleSessionName, config_table_name, 'failed', kwargs_table, msg)
        raise Exception(msg)
        
    # initialize statuses for assets to import
    for asset in kwargs_table['assets_to_clone']:
        if asset.get('export_local') == 'success' and asset.get('restore_target') != 'success':
            asset['restore_target'] = 'running'
            asset['status'] = 'pending'
            asset['step'] = None
    kwargs_table = update_pipeline_run_status(logger, roleArn, roleSessionName, config_table_name, 'running', kwargs_table)
    return kwargs_table


# #####################################################
# ######## main functions for export and import
# #####################################################

def main_run_local_export(logger, spark, config_table_name, pipeline_name):
    '''
    Function will export data from RMF to local PRD bucket.
    :param logger: logger object
    :param spark: spark object session
    :param assets_to_clone: list of assets
    :return:(pipeline_run_id , status)
    '''
    # Setup Session - Assume Role 
    run_id = None
    run_status = None
    try:
        try:
            roleArn = os.getenv("deltalake_assume_role_arn")
        except Exception as e:
            logger.error("Error in `Get OS.getenv roleArn`")
            logger.error(e)
            raise e

        log_pipeline_runs = ''
        log_table_name = 'ed_pipeline_log_runs'
        roleSessionName = 'RMF-Clone-Prd-Local'
        dyno_resource = create_session_sts(logger, roleArn, roleSessionName, 'dynamodb', 'resource')
        s3_session = create_session_sts(logger, roleArn, roleSessionName, 's3', 'resource')
        try:
            config_table = dyno_resource.Table(config_table_name)
            pipeline_config = query_pipeline_config(config_table, pipeline_name)
        except Exception as e:
            msg = f"No Entry in {config_table_name} table for {pipeline_name}. {e}"
            raise Exception(msg)
        
        try:
            log_config_table = dyno_resource.Table(log_table_name)
            log_pipeline_runs = query_pipeline_config(log_config_table, pipeline_name)
        except Exception as e:
            msg = f"No Entry in {log_config_table} table for {pipeline_name}. {e}"
            logger.info(msg)
        try:
            kwargs_table, kwargs, assets_to_clone, assets_to_retry = validate_rmf_pipeline(pipeline_config, log_pipeline_runs)
            kwargs['roleArn'] = roleArn
        except Exception as e:
            raise Exception(f"Invalid pipeline. Error:{e}")

        table_pipeline_log_runs = dyno_resource.Table('ed_pipeline_log_runs')
        run_id = kwargs_table['pipeline_run_id']
        insert_or_update_table(logger, table_pipeline_log_runs, 'pipeline_name', kwargs_table['pipeline_run_id'], **kwargs_table)
        msg = f"\nStarting pipeline_log_run {kwargs_table['pipeline_run_id']}"
        print(msg)
        logger.info(msg)
    except Exception as e:
        # If there is issue connecting to dynamodb or  pipeline is invalid exit 
        run_status = 'failed'
        logger.error(f"Error starting the pipeline. {e}")
        return run_id, run_status
    
    if  log_pipeline_runs:
        assets_to_clone = assets_to_retry
        
    for asset in assets_to_clone:
        # In case of long running jobs - the session needs to be renewed 
        dyno_resource = create_session_sts(logger, roleArn, roleSessionName, 'dynamodb', 'resource')
        source_schema = asset['source_schema']
        source_table = asset['source_table']
        export_operation = asset.get('export_operation') # get function returns None if the key does not exist without crashing

        target_environment = pipeline_config['target_environment']
        
        table_id = source_schema + '.' + source_table
        asset['status'] = 'running'
        asset['last_updated_ts'] = datetime.fromtimestamp(time.time()).strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3]
        insert_or_update_table(logger, table_pipeline_log_runs, 'pipeline_name', kwargs_table['pipeline_run_id'], **kwargs_table)
        print('\n############## Doing Asset: ' + source_schema + '.' + source_table)
        #  Update Asset status
        sanitize_list = get_sanitize_conf(logger, dyno_resource, kwargs['sanitize_config_table_name'], table_id)
        if export_operation == 'overwrite':
            try:
                s3_bucket_name = pipeline_config['export_location'].split('/')[0]
                main_folder = pipeline_config['export_location'].split('/')[1:]
                source_schema =asset['source_schema']
                source_table = asset['source_table']
                if not main_folder:
                    s3_folder =  target_environment + '/' + source_schema + '/' + source_table
                elif len(main_folder) > 1:
                    s3_folder = '/'.join(main_folder) + '/' + target_environment + '/' + source_schema + '/' + source_table
                else:
                    s3_folder =  main_folder[0] + '/' + target_environment + '/' + source_schema + '/' + source_table
                empty_s3_folder(s3_session, s3_bucket_name, s3_folder)
            except Exception as e:
                logger.error("Error in `empty_s3_folder`")
                logger.error(e)
                asset['status'] = 'failed'
                asset['export_local'] = 'failed'
                asset['error_msg'] = '`empty_s3_folder` - ' + str(e)
                asset['last_updated_ts'] = datetime.fromtimestamp(time.time()).strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3]
                insert_or_update_table(logger, table_pipeline_log_runs, 'pipeline_name', kwargs_table['pipeline_run_id'], **kwargs_table)
                break
        try:
            source_columns = get_source_columns(logger, spark, asset)
            asset['target_restore_location'] = get_target_location(logger, spark, asset, kwargs['target_environment'])
            asset['source_columns'] = str(source_columns)
            asset['last_updated_ts'] = datetime.fromtimestamp(time.time()).strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3]
            insert_or_update_table(logger, table_pipeline_log_runs, 'pipeline_name', kwargs_table['pipeline_run_id'], **kwargs_table)
        except Exception as e:
            logger.error("Error in `get_source_columns`")
            logger.error(e)
            asset['status'] = 'failed'
            asset['export_local'] = 'failed'
            asset['error_msg'] = '`get_source_columns` - ' + str(e)
            asset['last_updated_ts'] = datetime.fromtimestamp(time.time()).strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3]
            insert_or_update_table(logger, table_pipeline_log_runs, 'pipeline_name', kwargs_table['pipeline_run_id'], **kwargs_table)
            break
        try:
            updated_source_columns = update_source_columns(sanitize_list, source_columns)
            asset['updated_source_columns'] = str(updated_source_columns)
            asset['last_updated_ts'] = datetime.fromtimestamp(time.time()).strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3]
            insert_or_update_table(logger, table_pipeline_log_runs, 'pipeline_name', kwargs_table['pipeline_run_id'], **kwargs_table)
        except Exception as e:
            logger.error("Error in `update_source_columns`")
            logger.error(e)
            asset['status'] = 'failed'
            asset['export_local'] = 'failed'
            asset['error_msg'] = 'updated_source_columns - ' + str(e)
            asset['last_updated_ts'] = datetime.fromtimestamp(time.time()).strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3]
            insert_or_update_table(logger, table_pipeline_log_runs, 'pipeline_name', kwargs_table['pipeline_run_id'], **kwargs_table)
            break
        try:
            df = spark.sql(generate_extract_sql(logger, asset, updated_source_columns))
            asset['last_updated_ts'] = datetime.fromtimestamp(time.time()).strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3]
            insert_or_update_table(logger, table_pipeline_log_runs, 'pipeline_name', kwargs_table['pipeline_run_id'], **kwargs_table)
        except Exception as e:
            logger.error("Error in `generate_extract_sql`")
            logger.error(e)
            asset['status'] = 'failed'
            asset['export_local'] = 'failed'
            asset['error_msg'] = 'generate_extract_sql - ' + str(e)
            asset['last_updated_ts'] = datetime.fromtimestamp(time.time()).strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3]
            insert_or_update_table(logger, table_pipeline_log_runs, 'pipeline_name', kwargs_table['pipeline_run_id'], **kwargs_table)
            break
        try:
            print('Exporting - ' + source_schema + '.' + source_table)
            eval(generate_export(logger, asset, kwargs['export_location']))
            asset['status'] = 'success'
            asset['export_local'] = 'success'
            asset['last_updated_ts'] = datetime.fromtimestamp(time.time()).strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3]
            insert_or_update_table(logger, table_pipeline_log_runs, 'pipeline_name', kwargs_table['pipeline_run_id'], **kwargs_table)
        except Exception as e:
            logger.error("Error in `generate_export`")
            logger.error(e)
            asset['status'] = 'failed'
            asset['export_local'] = 'failed'
            asset['error_msg'] = 'generate_export - ' + str(e)
            insert_or_update_table(logger, table_pipeline_log_runs, 'pipeline_name', kwargs_table['pipeline_run_id'], **kwargs_table)
            break
        print('\n############## Export Complete for : ' + source_schema + '.' + source_table)
    kwargs_table['export_local'] = 'success'
    kwargs_table['pipeline_run_status'] = 'running'
    kwargs_table['last_updated_ts'] = datetime.fromtimestamp(time.time()).strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3]
    insert_or_update_table(logger, table_pipeline_log_runs, 'pipeline_name', kwargs_table['pipeline_run_id'], **kwargs_table)
    run_id = kwargs_table['pipeline_run_id']
    run_status = kwargs_table['pipeline_run_status']
    return run_id, run_status


def main_run_import_target(logger, spark, roleSessionName, roleArn, roleArnS3, config_table_name, pipeline_name,
                           pipeline_run_id):
    '''
    Imports Delta Tables from Cloned PRD into STG/DEV

    Prerequisites: 
            - entry in pipeline_run_log dynamodb table with assets exported with success
            - roleArnS3 should have cross account access to copy s3 files

    :param logger: logger object
    :param spark: spark object
    :param roleSessionName: roleSessionName
    :param roleArn: role arn used for all dynamodb actions
    :param roleArnS3: role arn used for all S3 actions
    :param config_table_name: dynamodb table (ed_pipeline_log_runs)
    :param pipeline_name: ed pipeline name
    :param pipeline_run_id: ed pipeline run id
    :return: success/failed
    '''
    msg = f"\n####### Starting import_to_target for pipeline_log_run {pipeline_run_id}"
    print(msg)
    logger.info(msg)
    
    try:
        s3_session = create_session_sts(logger, roleArnS3, roleSessionName, 's3', 'resource')
        kwargs_table = resume_pipeline_log_import_target(logger, roleArn, roleSessionName, config_table_name, pipeline_name, pipeline_run_id)      
    except Exception as e:
        # If there is issue connecting to dynamodb or  pipeline_log_run_id is invalid exit 
        logger.error(f"Error starting the job. Error: {traceback.format_exc()}")
        return 'failed'

    assets_to_import = [item for item in kwargs_table['assets_to_clone'] if item['status'] == 'pending' and item['restore_target'] == 'running']
    msg = "\n####### Import to target - assets to process:"
    print(msg)
    logger.info(msg)

    for item in assets_to_import:
        msg = f"{item['source_schema']}.{item['source_table']}"
        print(msg)
        logger.info(msg)
    pool = ThreadPool()

    step = 'cleanup_s3_for_asset'
    msg = f"\n####### Import to target - step - {step} "
    print(msg)
    logger.info(msg)   
    kwargs_table['step'] = step
    kwargs_table = update_pipeline_run_status(logger, roleArn, roleSessionName, config_table_name, 'running', kwargs_table)
    try:
        empty_tbl_list = create_import_empty_tbl_list(s3_session, assets_to_import)       
        tic = time.perf_counter()
        cleanup_results = pool.starmap(cleanup_s3_for_asset, empty_tbl_list)
        toc = time.perf_counter()
        print(f"\n {step} in {toc - tic:0.4f} seconds")
        for result in cleanup_results:
            kwargs_table = update_asset_status(logger, roleArn, roleSessionName, config_table_name, step, result, kwargs_table) 
    except Exception as e:
        msg = f"{step} -failed ERROR:{traceback.format_exc()}"
        logger.error(msg)
        kwargs_table = update_pipeline_run_status(logger,  roleArn, roleSessionName, config_table_name, 'failed', kwargs_table, msg)
        return 'failed'
   
    step = 'copy_parallel'
    msg = f"\n####### Import to target - step - {step} "
    print(msg)
    logger.info(msg)    
    kwargs_table['step'] = step
    kwargs_table = update_pipeline_run_status(logger, roleArn, roleSessionName, config_table_name, 'running', kwargs_table )
    assets_to_copy = [item for item in kwargs_table['assets_to_clone'] if item['status'] == 'success' and item['restore_target'] == 'running']
    try:
        s3_session = create_session_sts(logger, roleArnS3, roleSessionName, 's3', 'client')
        target_environment = kwargs_table['target_environment']
        export_location = kwargs_table['export_location']
        copy_param_list = create_copy_parallel_tbl_list(s3_session, target_environment, export_location,  assets_to_copy)
        tic = time.perf_counter()
        copy_results = pool.starmap(copy_parallel, copy_param_list)
        toc = time.perf_counter()
        print(f"copy_s3_cross done in {toc - tic:0.4f} seconds")
        for result in copy_results:
            kwargs_table = update_asset_status(logger, roleArn, roleSessionName, config_table_name, step, result, kwargs_table) 
    except Exception as e:
        msg = f"{step} -failed ERROR:{traceback.format_exc()}"
        logger.error(msg)
        kwargs_table = update_pipeline_run_status(logger,  roleArn, roleSessionName, config_table_name, 'failed', kwargs_table, msg )
        return 'failed'

    step = 'drop_delta_tables'
    msg= f"\n####### Import to target - step - {step} "
    print(msg)
    logger.info(msg)    
    kwargs_table['step'] = step
    kwargs_table = update_pipeline_run_status(logger, roleArn, roleSessionName, config_table_name, 'running', kwargs_table ) 
    assets_to_drop =[item  for item in kwargs_table['assets_to_clone'] if item['status'] == 'success' and item['restore_target'] == 'running']
    try:
        tic = time.perf_counter()
        drop_delta_table_tbl_list = create_drop_delta_table_tbl_list(logger, spark, assets_to_drop)
        del_results = pool.starmap(drop_delta_table, drop_delta_table_tbl_list)
        toc = time.perf_counter()
        print(f"Dropping Tables from Catalog done in {toc - tic:0.4f} seconds")
        for result in del_results:
            kwargs_table = update_asset_status(logger, roleArn, roleSessionName, config_table_name, step, result, kwargs_table) 
    except Exception as e:
        msg = f"{step} -failed ERROR:{traceback.format_exc()}"
        logger.error(msg)
        kwargs_table = update_pipeline_run_status(logger,  roleArn, roleSessionName, config_table_name, 'failed', kwargs_table, msg )
        return 'failed'
      
    step = 'create_delta_tables'
    msg= f"\n####### Import to target - step - {step} "
    print(msg)
    logger.info(msg)    
    kwargs_table['step'] = step
    kwargs_table = update_pipeline_run_status(logger, roleArn, roleSessionName, config_table_name, 'running', kwargs_table )     
    assets_to_create =[item  for item in kwargs_table['assets_to_clone'] if item['status'] == 'success' and item['restore_target'] == 'running']
    for item in assets_to_create:
        print(f"{item['source_schema']}.{item['source_table']}")      
    try:
        tic = time.perf_counter()
        delta_table_tbl_list = create_delta_table_tbl_list(logger, spark, assets_to_create)
        create_results = pool.starmap(create_delta_table, delta_table_tbl_list)
        toc = time.perf_counter()
        print(f"Convert Parquet to Delta and Create Delta Table done in {toc - tic:0.4f} seconds")
        for result in create_results:
            kwargs_table = update_asset_status(logger, roleArn, roleSessionName, config_table_name, step, result, kwargs_table)
    except Exception as e:
        msg = f"{step} -failed ERROR:{traceback.format_exc()}"
        logger.error(msg)
        kwargs_table = update_pipeline_run_status(logger,  roleArn, roleSessionName, config_table_name, 'failed', kwargs_table, msg )
        return 'failed'
      
    for asset in kwargs_table['assets_to_clone']:
        if asset.get('restore_target')== 'running':
            asset['restore_target'] = asset['status']
    msg = ''
    kwargs_table = update_pipeline_run_status(logger,  roleArn, roleSessionName, config_table_name, 'success', kwargs_table, msg )
    return 'success'
