# from *_table_config table
from operator import itemgetter

import traceback

from lakehouselib.system.exception.handler import LakehouseError
from pyspark.sql.types import StructType


def get_incremental_key_col(job_vars, config_item):
    """Get the increment key, name for a target table that's used for SCD2

    Parameters
    ----------
    job_vars : util.config.stream.jobconfiguration class JobVariables
        All the required job variables to be used through out the job (JobVariables() -> job_vars)

    config_item : single row from dynamodb scanfilter
        The configuration items we are interested in for the table (get_ddb_config_meta)

    Returns
    -------
    return : str
        the column name of the incremental key in the target table
    """
    try:
        columns = str(config_item['source_incr_column']).split("|")
        return columns
    except Exception as exc:
        err_msg = "Error obtaining `get_incremental_key_col` for job `{}`".format(job_vars.job_name)
        raise LakehouseError(trace_err=traceback.format_exc(), err_nbr='5.22', err_msg=err_msg, job_vars=job_vars)


def get_timestamp_col(job_vars, config_item):
    """Get the timestamp column name for a target table that's used for SCD2

    Parameters
    ----------
    job_vars : util.config.stream.jobconfiguration class JobVariables
        All the required job variables to be used through out the job (JobVariables() -> job_vars)

    config_item : single row from dynamodb scanfilter
        The configuration items we are interested in for the table (get_ddb_config_meta)

    Returns
    -------
    return : str
        the timestamp column name in the target table
    """
    try:
        columns = config_item['source_ts_column']
        return columns
    except Exception as exc:
        err_msg = "Error obtaining `get_timestamp_col` for job `{}`".format(job_vars.job_name)
        raise LakehouseError(trace_err=traceback.format_exc(), err_nbr='5.23', err_msg=err_msg, job_vars=job_vars)


def get_src_partition_col(job_vars, config_item):
    """Get the filesystem partition column name(s) for a source table

    Parameters
    ----------
    job_vars : util.config.stream.jobconfiguration class JobVariables
        All the required job variables to be used through out the job (JobVariables() -> job_vars)

    config_item : single row from dynamodb scanfilter
        The configuration items we are interested in for the table (get_ddb_config_meta)

    Returns
    -------
    return : list
        the filesystem partition columns for source table (seperated by '|' and split)
    """
    try:
        columns = str(config_item['source_partition_column']).split("|")
        return columns
    except Exception as exc:
        err_msg = "Error obtaining `get_src_partition_col` for job `{}`".format(job_vars.job_name)
        raise LakehouseError(trace_err=traceback.format_exc(), err_nbr='5.24', err_msg=err_msg, job_vars=job_vars)


def get_target_partition_col(job_vars, config_item):
    """Get the filesystem partition column name(s) for a target table

    Parameters
    ----------
    job_vars : util.config.stream.jobconfiguration class JobVariables
        All the required job variables to be used through out the job (JobVariables() -> job_vars)

    config_item : single row from dynamodb scanfilter
        The configuration items we are interested in for the table (get_ddb_config_meta)

    Returns
    -------
    return : list
        the filesystem partition columns for target table (seperated by '|' and split)
    """
    try:
        columns = str(config_item['target_partition_column']).split("|")
        return columns
    except Exception as exc:
        err_msg = "Error obtaining `get_target_partition_col` for job `{}`".format(job_vars.job_name)
        raise LakehouseError(trace_err=traceback.format_exc(), err_nbr='5.24', err_msg=err_msg, job_vars=job_vars)


def get_target_schema_name(job_vars, config_item):
    """Get the schema name for a target table

    Parameters
    ----------
    job_vars : util.config.stream.jobconfiguration class JobVariables
        All the required job variables to be used through out the job (JobVariables() -> job_vars)

    config_item : single row from dynamodb scanfilter
        The configuration items we are interested in for the table (get_ddb_config_meta)

    Returns
    -------
    return : str
        the name of the schema target table
    """
    try:
        columns = str(config_item['target_schema_name'])
        return columns
    except Exception as exc:
        err_msg = "Error obtaining `get_target_schema_name` for job `{}`".format(job_vars.job_name)
        raise LakehouseError(trace_err=traceback.format_exc(), err_nbr='5.25', err_msg=err_msg, job_vars=job_vars)


def get_target_table_name(job_vars, config_item):
    """Get the table name for a target table

    Parameters
    ----------
    job_vars : util.config.stream.jobconfiguration class JobVariables
        All the required job variables to be used through out the job (JobVariables() -> job_vars)

    config_item : single row from dynamodb scanfilter
        The configuration items we are interested in for the table (get_ddb_config_meta)

    Returns
    -------
    return : str
        the name of the table for the target
    """
    try:
        columns = str(config_item['target_table_name'])
        return columns
    except Exception as exc:
        err_msg = "Error obtaining `get_target_table_name` for job `{}`".format(job_vars.job_name)
        raise LakehouseError(trace_err=traceback.format_exc(), err_nbr='5.26', err_msg=err_msg, job_vars=job_vars)


def get_target_all_columns(job_vars, meta_rows):
    """Get the defined column names name for a source table

    Parameters
    ----------
    job_vars : util.config.stream.jobconfiguration class JobVariables
        All the required job variables to be used through out the job (JobVariables() -> job_vars)

    meta_rows : resultset from dynamodb scanfilter
        The column items we are interested in for the table (get_ddb_table_meta)

    Returns
    -------
    return : list
        the column names for the source table
    """
    try:
        sorted_meta_rows = sorted(meta_rows, key=lambda x: int(x['target_column_order']))
        columns = [item['target_column_alias'] for item in sorted_meta_rows if item['is_row_active']]
        return columns
    except Exception as exc:
        err_msg = "Error obtaining values from `get_source_business_key_columns` for job `{}`".format(job_vars.job_name)
        raise LakehouseError(trace_err=traceback.format_exc(), err_nbr='5.21', err_msg=err_msg, job_vars=job_vars)


def get_target_schema_definition_as_str(job_vars, meta_rows):
    """Get the schema definition for the target table

    Parameters
    ----------
    job_vars : util.config.stream.jobconfiguration class JobVariables
        All the required job variables to be used through out the job (JobVariables() -> job_vars)

    meta_rows : resultset from dynamodb scanfilter
        The column items we are interested in for the table (get_ddb_table_meta)

    Returns
    -------
    return : str
        the column names and data types for the source table
    """
    try:
        sorted_meta_rows = sorted(meta_rows, key=lambda x: int(x['target_column_order']))

        col_defn_list = []
        for item in sorted_meta_rows:
            if not item['is_row_active']:
                continue

            target_column_datatype = item['target_column_datatype']
            target_column_alias = item["target_column_alias"]

            col_defn = f"{target_column_alias} {target_column_datatype}"

            if target_column_datatype.lower() == 'decimal':
                target_column_precision = item['target_column_precision']
                target_column_scale = item['target_column_scale']
                col_defn += f'({target_column_precision},{target_column_scale})'

            col_defn_list.append(col_defn)

        return '|'.join(col_defn_list)
    except Exception as exc:
        err_msg = "Error obtaining values from `get_target_schema_definition_as_str` for job `{}`".format(job_vars.job_name)
        raise LakehouseError(trace_err=traceback.format_exc(), err_nbr='5.21', err_msg=err_msg, job_vars=job_vars)


def get_target_schema_definition_as_dict(job_vars, meta_rows):
    """Get the schema definition for the target table

    Parameters
    ----------
    job_vars : util.config.stream.jobconfiguration class JobVariables
        All the required job variables to be used through out the job (JobVariables() -> job_vars)

    meta_rows : resultset from dynamodb scanfilter
        The column items we are interested in for the table (get_ddb_table_meta)

    Returns
    -------
    return : dict
        the column names and data types for the source table
    """
    try:
        sorted_meta_rows = sorted(meta_rows, key=lambda x: int(x['target_column_order']))

        col_defns = {}
        for item in sorted_meta_rows:
            if not item['is_row_active']:
                continue

            target_column_datatype = item['target_column_datatype']
            target_column_alias = item["target_column_alias"]

            col_dtype = target_column_datatype

            if target_column_datatype.lower() == 'decimal':
                target_column_precision = item['target_column_precision']
                target_column_scale = item['target_column_scale']
                col_dtype += f'({target_column_precision},{target_column_scale})'

            col_defns[target_column_alias] = col_dtype

        return col_defns
    except Exception as exc:
        err_msg = "Error obtaining values from `get_target_schema_definition_as_dict` for job `{}`".format(job_vars.job_name)
        raise LakehouseError(trace_err=traceback.format_exc(), err_nbr='5.21', err_msg=err_msg, job_vars=job_vars)


def get_source_business_key_columns(job_vars, sorted_meta_rows):
    """Get the defined "business keys" column names name for a source table

    Parameters
    ----------
    job_vars : util.config.stream.jobconfiguration class JobVariables
        All the required job variables to be used through out the job (JobVariables() -> job_vars)

    sorted_meta_rows : resultset from dynamodb scanfilter
        The column items we are interested in for the table (get_ddb_table_meta)

    Returns
    -------
    return : list
        the column names of defined "business keys" for the source table
    """
    try:
        columns = [item['source_column_name'] for item in sorted_meta_rows if item['is_source_table_key'] == True]
        return columns
    except Exception as exc:
        err_msg = "Error obtaining values from `get_source_business_key_columns` for job `{}`".format(job_vars.job_name)
        raise LakehouseError(trace_err=traceback.format_exc(), err_nbr='5.21', err_msg=err_msg, job_vars=job_vars)


def get_source_data_columns(job_vars, sorted_meta_rows):
    """Get the defined data column names name for a source table (not control, business key, or audit)

    Parameters
    ----------
    job_vars : util.config.stream.jobconfiguration class JobVariables
        All the required job variables to be used through out the job (JobVariables() -> job_vars)

    sorted_meta_rows : resultset from dynamodb scanfilter
        The column items we are interested in for the table (get_ddb_table_meta)

    Returns
    -------
    return : list
        the column names of defined data fields for the source table
    """
    try:
        columns = [item['source_column_name'] for item in sorted_meta_rows if
                   item['is_audit_column'] == False and item['is_source_table_key'] == False]
        return columns
    except Exception as exc:
        err_msg = "Error obtaining values from `get_source_data_columns` for job `{}`".format(job_vars.job_name)
        raise LakehouseError(trace_err=traceback.format_exc(), err_nbr='5.19', err_msg=err_msg, job_vars=job_vars)


def get_source_audit_columns(job_vars, sorted_meta_rows):
    """Get the defined audit column names name for a source table

    Parameters
    ----------
    job_vars : util.config.stream.jobconfiguration class JobVariables
        All the required job variables to be used through out the job (JobVariables() -> job_vars)

    sorted_meta_rows : resultset from dynamodb scanfilter
        The column items we are interested in for the table (get_ddb_table_meta)

    Returns
    -------
    return : list
        the column names of defined audit fields for the source table
    """
    try:
        columns = [item['source_column_name'] for item in sorted_meta_rows if
                   item['is_audit_column'] == True]
        return columns
    except Exception as exc:
        err_msg = "Error obtaining values from `get_source_audit_columns` for job `{}`".format(job_vars.job_name)
        raise LakehouseError(trace_err=traceback.format_exc(), err_nbr='5.20', err_msg=err_msg, job_vars=job_vars)


def get_business_key_columns(job_vars, sorted_meta_rows, with_col_order=False):
    """Get the defined "business keys" column names name for a target table

    Parameters
    ----------
    job_vars : util.config.stream.jobconfiguration class JobVariables
        All the required job variables to be used through out the job (JobVariables() -> job_vars)

    sorted_meta_rows : resultset from dynamodb scanfilter
        The column items we are interested in for the table (get_ddb_table_meta)

    Returns
    -------
    return : list
        the column names of defined "business keys" for the target table
    """
    try:
        if with_col_order:
            columns = {item['target_column_order']: item['target_column_alias'] for item in sorted_meta_rows if
                    item['is_target_table_key'] == True}
        else:
            columns = [item['target_column_alias'] for item in sorted_meta_rows if
                       item['is_target_table_key'] == True]
        return columns
    except Exception as exc:
        err_msg = "Error obtaining values from `get_business_key_columns` for job `{}`".format(job_vars.job_name)
        raise LakehouseError(trace_err=traceback.format_exc(), err_nbr='5.21', err_msg=err_msg, job_vars=job_vars)


def get_audit_columns(job_vars, sorted_meta_rows):
    """Get the defined audit column names name for a target table

    Parameters
    ----------
    job_vars : util.config.stream.jobconfiguration class JobVariables
        All the required job variables to be used through out the job (JobVariables() -> job_vars)

    sorted_meta_rows : resultset from dynamodb scanfilter
        The column items we are interested in for the table (get_ddb_table_meta)

    Returns
    -------
    return : list
        the column names of defined audit fields for the target table
    """
    try:
        columns = [item['target_column_alias'] for item in sorted_meta_rows if
                   item['is_audit_column'] == True]
        return columns
    except Exception as exc:
        err_msg = "Error obtaining values from `get_audit_columns` for job `{}`".format(job_vars.job_name)
        raise LakehouseError(trace_err=traceback.format_exc(), err_nbr='5.20', err_msg=err_msg, job_vars=job_vars)


def get_data_columns(job_vars, sorted_meta_rows, with_col_order=False):
    """Get the defined data column names name for a target table (not control, business key, or audit)

    Parameters
    ----------
    job_vars : util.config.stream.jobconfiguration class JobVariables
        All the required job variables to be used through out the job (JobVariables() -> job_vars)

    sorted_meta_rows : resultset from dynamodb scanfilter
        The column items we are interested in for the table (get_ddb_table_meta)

    Returns
    -------
    return : list
        the column names of defined data fields for the target table
    """
    try:
        if with_col_order:
            columns = {item['target_column_order']: item['target_column_alias'] for item in sorted_meta_rows if
                    item['is_audit_column'] == False and item['is_target_table_key'] == False}
        else:
            columns = [item['target_column_alias'] for item in sorted_meta_rows if
                       item['is_audit_column'] == False and item['is_target_table_key'] == False]
        return columns
    except Exception as exc:
        err_msg =  "Error obtaining values from `get_data_columns` for job `{}`".format(job_vars.job_name)
        raise LakehouseError(trace_err=traceback.format_exc(), err_nbr='5.19', err_msg=err_msg, job_vars=job_vars)


def map_source_to_target(df, job_vars, sorted_meta_rows):
    """Maps the source column named to the target columns names (requires exploded data)

    Parameters
    ----------
    df : org.apache.spark.sql.DataFrame
        The incoming data from kafka (read_from_kafka)

    job_vars : util.config.stream.jobconfiguration class JobVariables
        All the required job variables to be used through out the job (JobVariables() -> job_vars)

    sorted_meta_rows : resultset from dynamodb scanfilter
        The column items we are interested in for the table (get_ddb_table_meta)

    Returns
    -------
    mapped_data : org.apache.spark.sql.DataFrame
        a dataframe with all the names of the columns as specified in DDB
    """
    try:
        select_expr_list = []
        for item in sorted_meta_rows:
            select_expr = ''
            source_column_name = item['source_column_name']
            target_column_datatype = item['target_column_datatype']
            target_column_alias = item["target_column_alias"]

            if __df_has_column(df, source_column_name):
                select_expr += f'cast({source_column_name} as '
            else:
                select_expr += 'cast(null as '

            select_expr += target_column_datatype
            if target_column_datatype.lower() == 'decimal':
                target_column_precision = item['target_column_precision']
                target_column_scale = item['target_column_scale']
                select_expr += f'({target_column_precision}, {target_column_scale})'
            select_expr += f') {target_column_alias}'

            select_expr_list.append(select_expr)
        mapped_data = df.selectExpr(select_expr_list).dropDuplicates()
        return mapped_data
    except Exception as exc:
        err_msg = "Error mapping columns with DDB definitions in `map_source_to_target` for job `{}`".format(job_vars.job_name)
        raise LakehouseError(trace_err=traceback.format_exc(), err_nbr='4.16', err_msg=err_msg, job_vars=job_vars)


def get_ddb_config_meta(job_vars, ddb_client, ddb_table_name):
    """Get a list of tables and configuration attributess from DDB related to the kafka topic

    Parameters
    ----------
    job_vars : util.config.stream.jobconfiguration class JobVariables
        All the required job variables to be used through out the job (JobVariables() -> job_vars)

    ddb_client :  boto_session.resource for dynamo
        The boto client for dynamodb

    ddb_table_name :  dynamoDB table
        The dynamodb object to filter and get results from

    Returns
    -------
    ddb_results : list
        a list of all the target table names and their configuration attributes as per DDB
    """
    try:
        ddb_table = ddb_client.Table(ddb_table_name)

        ddb_filter = dict()

        ddb_filter['is_row_active'] = {
            'AttributeValueList': [True],
            'ComparisonOperator': 'EQ'
        }

        if 'kafka_topic' in job_vars.job_args.keys():
            ddb_filter['source_kafka_topic'] = {
                'AttributeValueList': [job_vars.job_args['kafka_topic']],
                'ComparisonOperator': 'EQ'
            }
        else:
            err_msg = "Error running `get_ddb_config_meta` DDB query for for job `{}`, 'kafka_topic' has not been specified in 'job_args'".format(job_vars.job_name)
            raise LakehouseError(trace_err=traceback.format_exc(), err_nbr='2.9', err_msg=err_msg, job_vars=job_vars)

        if 'load_type' in job_vars.job_args.keys():
            ddb_filter['load_type'] = {
                'AttributeValueList': [job_vars.job_args['load_type']],
                'ComparisonOperator': 'EQ'
            }
        else:
            err_msg = "Error running `get_ddb_config_meta` DDB query for for job `{}`, 'load_type' has not been specified in 'job_args'".format(job_vars.job_name)
            raise LakehouseError(trace_err=traceback.format_exc(), err_nbr='2.9', err_msg=err_msg, job_vars=job_vars)

        lastEvaluatedKey = None
        ddb_results = list()

        while True:
            if not lastEvaluatedKey:
                response = ddb_table.scan(ScanFilter=ddb_filter,
                                          ConditionalOperator='AND')
            else:
                response = ddb_table.scan(ScanFilter=ddb_filter,
                                          ConditionalOperator='AND',
                                          ExclusiveStartKey=lastEvaluatedKey)

            ddb_results.extend(response['Items'])

            if 'LastEvaluatedKey' in response:
                lastEvaluatedKey = response['LastEvaluatedKey']
            else:
                break

        return {"Items": ddb_results}

    except Exception as exc:
        err_msg = "Error running `get_ddb_config_meta` DDB query for for job `{}`".format(job_vars.job_name)
        raise LakehouseError(trace_err=traceback.format_exc(), err_nbr='2.9', err_msg=err_msg, job_vars=job_vars)


def get_ddb_table_all(job_vars, ddb_client, ddb_table_name):
    """Get all records in dynamodb table

    Parameters
    ----------
    job_vars : util.config.stream.jobconfiguration class JobVariables
        All the required job variables to be used through out the job (JobVariables() -> job_vars)

    ddb_client :  boto_session.resource for dynamo
        The boto client for dynamodb

    ddb_table_name :  dynamoDB table
        The dynamodb object to filter and get results from

    Returns
    -------
    ddb_results : list
        a list of all records in DDB table
    """
    try:
        ddb_table = ddb_client.Table(ddb_table_name)

        lastEvaluatedKey = None
        ddb_results = list()

        while True:
            if not lastEvaluatedKey:
                response = ddb_table.scan()
            else:
                response = ddb_table.scan(ExclusiveStartKey=lastEvaluatedKey)

            ddb_results.extend(response['Items'])

            if 'LastEvaluatedKey' in response:
                lastEvaluatedKey = response['LastEvaluatedKey']
            else:
                break

        return {"Items": ddb_results}

    except Exception as exc:
        err_msg = "Error running `get_ddb_table_all` DDB query for table `{}`".format(
            ddb_table_name)
        raise LakehouseError(trace_err=traceback.format_exc(), err_nbr='2.11', err_msg=err_msg, job_vars=job_vars)


def get_ddb_table_meta(job_vars, ddb_client, ddb_table_name, table_id, target_layer_type):
    """Query DDB for a list of fields and configuration attributes for a lakehouse table

    Parameters
    ----------
    job_vars : util.config.stream.jobconfiguration class JobVariables
        All the required job variables to be used through out the job (JobVariables() -> job_vars)

    ddb_client :  boto_session.resource for dynamo
        The boto client for dynamodb

    ddb_table_name : str
        the name of the ddb table

    table_id : str
        the name of the table

    target_layer_type : str
        the platforms defined data layer to filter and get results from

    Returns
    -------
    ddb_results : list
        a list of all the target table columns names and their configuration attributes as per DDB
    """
    try:
        ddb_table = ddb_client.Table(ddb_table_name)

        lastEvaluatedKey = None
        ddb_results = list()

        ddb_filter = {
            "table_id": {
                "AttributeValueList": [table_id],
                "ComparisonOperator": "EQ"
            },
            "target_layer_type": {
                "AttributeValueList": [target_layer_type],
                "ComparisonOperator": "EQ"
            },
            "is_row_active": {
                "AttributeValueList": [True],
                "ComparisonOperator": "EQ"
            }
        }

        while True:
            if not lastEvaluatedKey:
                response = ddb_table.scan(ScanFilter=ddb_filter,
                                          ConditionalOperator='AND')
            else:
                response = ddb_table.scan(ScanFilter=ddb_filter,
                                          ConditionalOperator='AND',
                                          ExclusiveStartKey=lastEvaluatedKey)

            ddb_results.extend(response['Items'])

            if 'LastEvaluatedKey' in response:
                lastEvaluatedKey = response['LastEvaluatedKey']
            else:
                break

        return {"Items": ddb_results}

    except Exception as exc:
        err_msg = "Error running `get_ddb_table_meta` DDB query for table `{}`".format(table_id)
        raise LakehouseError(trace_err=traceback.format_exc(), err_nbr='2.8', err_msg=err_msg, job_vars=job_vars)


def get_ddb_table_config_items(job_vars, ddb_client, ddb_table_name):
    """Obtain a list configuration attributes for a lakehouse table

    Parameters
    ----------
    job_vars : util.config.stream.jobconfiguration class JobVariables
        All the required job variables to be used through out the job (JobVariables() -> job_vars)

    ddb_client :  boto_session.resource for dynamo
        The boto client for dynamodb

    ddb_table_name : str
        the name of the ddb table

    Returns
    -------
    ddb_results : list
        a dict with the table_name as the key, of all the kafka brokers table configuration attributes
    """

    try:
        a_config_meta = dict()
        config_meta = get_ddb_config_meta(job_vars, ddb_client, ddb_table_name)
        for config_item in config_meta['Items']:
            table_name = config_item['table_id']
            if table_name not in a_config_meta:
                a_config_meta[table_name] = config_item
        return a_config_meta
    except Exception as exc:
        err_msg = "Error running `get_ddb_table_config_items` DDB query for table `{}`".format(ddb_table_name)
        raise LakehouseError(trace_err=traceback.format_exc(), err_nbr='5.18', err_msg=err_msg, job_vars=job_vars)


def get_ddb_metadata_config_items(job_vars, ddb_client, ddb_table_name):
    """Obtain a list of fields and configuration attributes for a lakehouse table

    Parameters
    ----------
    job_vars : util.config.stream.jobconfiguration class JobVariables
        All the required job variables to be used through out the job (JobVariables() -> job_vars)

    ddb_client :  boto_session.resource for dynamo
        The boto client for dynamodb

    ddb_table_name : str
        the name of the ddb table

    Returns
    -------
    ddb_results : list
        a dict with the table_name as the key,  of all the target table columns names and their configuration attributes
    """
    try:
        a_table_meta = dict()
        for table_id in job_vars.ddb_table_config:
            # TODO remove 'Bronze' and pass argument '--job-type' from spark-submit
            table_meta = get_ddb_table_meta(job_vars, ddb_client, ddb_table_name, table_id, 'Bronze')['Items']
            sorted_meta_rows = sorted(table_meta, key=itemgetter('target_column_order'))
            if table_id not in a_table_meta:
                a_table_meta[table_id] = sorted_meta_rows
        return a_table_meta
    except Exception as exc:
        err_msg = "Error running `get_ddb_metadata_config_items` DDB query for table `{}`".format(ddb_table_name)
        raise LakehouseError(trace_err=traceback.format_exc(), err_nbr='5.17', err_msg=err_msg, job_vars=job_vars)


def get_ddb_exc_config_items(job_vars, ddb_client, ddb_table_name):
    """Obtain a list of fields and configuration attributes for an exception

    Parameters
    ----------
    job_vars : util.config.stream.jobconfiguration class JobVariables
        All the required job variables to be used through out the job (JobVariables() -> job_vars)

    ddb_client :  boto_session.resource for dynamo
        The boto client for dynamodb

    ddb_table_name : str
        the name of the ddb table

    Returns
    -------
    ddb_results : list
        a dict with the exc_nbr as the key, and all attributes associated with each exception config value
    """
    try:
        a_exec_config = dict()
        config_meta = get_ddb_table_all(job_vars, ddb_client, ddb_table_name)
        for config_item in config_meta['Items']:
            err_nbr = config_item['err_nbr']
            if err_nbr not in a_exec_config:
                a_exec_config[err_nbr] = config_item
        return a_exec_config
    except Exception as exc:
        err_msg = "Error running `get_ddb_exc_config_items` DDB query for table `{}`".format(ddb_table_name)
        raise LakehouseError(trace_err=traceback.format_exc(), err_nbr='3.14', err_msg=err_msg, job_vars=job_vars)


def __df_get_field(fields, name):
    """Retrieves the field, which matches the provided name

    Parameters
    ----------
    fields : pyspark.sql.types.StructField[]
        An list of fields to search

    name : str
        Name of the field to find

    Returns
    -------
    field : pyspark.sql.types.StructField
        The field that matches the provided name
    """
    for field in fields:
        if field.name == name:
            return field
    return None


def __df_has_column(df, path):
    """Checks if the column (can be nested) exists within the data frame

    Parameters
    ----------
    df : pyspark.sql.DataFrame
        The data frame to check for the presence of a column

    path : str
        The 'path' of a column within the data frame. This value can represent a nested column,
        where each element is separated by a full stop '.'

    Returns
    -------
    is_present : bool
        boolean value indicating a column matching the provided path is present in the data frame
    """
    fields = df.schema.fields
    field = None

    for item in path.split('.'):
        field = __df_get_field(fields, item)

        if field is None:
            return False

        if isinstance(field.dataType, StructType):
            fields = field.dataType.fields
        else:
            fields = list()

    return field is not None