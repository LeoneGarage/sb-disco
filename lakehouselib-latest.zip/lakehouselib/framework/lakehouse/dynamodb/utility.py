import boto3
from boto3.dynamodb.conditions import Key, Attr
from datetime import datetime, timedelta
from lakehouselib.services.aws.sessionmanager.utility import *

client_session = create_aws_session()
dynamodb = client_session.resource('dynamodb', region_name='ap-southeast-2')
table_table_config = dynamodb.Table('lakehouse_table_config')
table_batch_run_logs = dynamodb.Table('lakehouse_batch_run_logs')
table_table_run_logs = dynamodb.Table('lakehouse_table_run_logs')
table_metadata_config = dynamodb.Table('lakehouse_metadata_config')
table_pipeline_log_runs = dynamodb.Table('ed_pipeline_log_runs')
table_ed_dep_config = dynamodb.Table('ed_dep_config')
table_pipeline_config = dynamodb.Table('ed_pipeline_config')
table_lakehouse_backfill_job_history = dynamodb.Table('lakehouse_backfill_job_history')


def query_table_config(logger, table_table_config, batch_name=None, target_table_name=None, target_schema_name=None, table_id=None):
    """
    Function to query the lakehouse_table_config table

    params:
        batch_name: batch name
        target_table_name
        target_schema_name
        table_id

    return:
        List of configs for the batch
    """
    try:
        if bool(batch_name):
            response_table_config = table_table_config.query(
                IndexName="batch_name-target_table_name-index",
                KeyConditionExpression=Key('batch_name').eq(batch_name)
                )
        
        elif bool(table_id):
            response_table_config = table_table_config.query(
                KeyConditionExpression=Key('table_id').eq(table_id)
                )
        
        elif bool(target_table_name) and bool(target_schema_name):
            response_table_config = table_table_config.query(
                IndexName="target_table_name-target_schema_name-index",
                KeyConditionExpression=Key('target_table_name').eq(target_table_name) & Key('target_schema_name').eq(target_schema_name)
                )
        else:
            return
        
        items_table_config = response_table_config['Items']

        while 'LastEvaluatedKey' in response_table_config:
            if bool(batch_name):
                response_table_config = table_table_config.query(
                    IndexName="batch_name-target_table_name-index",
                    KeyConditionExpression=Key('batch_name').eq(batch_name),
                    ExclusiveStartKey=response_table_config['LastEvaluatedKey']
                    )

            elif bool(table_id):
                response_table_config = table_table_config.query(
                    KeyConditionExpression=Key('table_id').eq(table_id),
                    ExclusiveStartKey=response_table_config['LastEvaluatedKey']
                    )

            elif bool(target_table_name) and bool(target_schema_name):
                response_table_config = table_table_config.query(
                    IndexName="target_table_name-target_schema_name-index",
                    KeyConditionExpression=Key('target_table_name').eq(
                        target_table_name) & Key('target_schema_name').eq(target_schema_name),
                    ExclusiveStartKey=response_table_config['LastEvaluatedKey']
                    )

            items_table_config.extend(response_table_config['Items'])

        tables_to_process = [item for item in items_table_config if item['is_row_active']]

        # Sort based on the process_seq
        #tables_to_process.sort(key= lambda x:x['process_seq'])
        logger.info(tables_to_process)
        return tables_to_process
    except Exception as exc:
        logger.error(exc)
        raise exc


def query_metadata_config(logger, table_metadata_config, table_id=None):
    """
    Function to query the lakehouse_metadata_config table

    params:
        table_id: table_id

    return:
        List of configs for the table
    """
    try:
        if bool(table_id):
            response_metadata_config = table_metadata_config.query(
                IndexName="table_id-index",
                KeyConditionExpression=Key('table_id').eq(table_id)
            )
        
            items_metadata_config = response_metadata_config['Items']
        
            while 'LastEvaluatedKey' in response_metadata_config:
                if bool(table_id):
                    response_metadata_config = table_metadata_config.query(
                        IndexName="table_id-index",
                        KeyConditionExpression=Key('table_id').eq(table_id),
                        ExclusiveStartKey=response_metadata_config['LastEvaluatedKey']
                    )

            metadata_to_process = [item for item in items_metadata_config if item['is_row_active']]

            logger.info(metadata_to_process)
            return metadata_to_process

    except Exception as exc:
        logger.error(exc)
        raise exc


def check_table_run_in_a_batch(logger, table_table_run_logs, ctl_batch_id):
    """
    Function to check for unsuccessful process in a batch

    params:
        table_table_run_logs: this is the DynamoDB table for table run logs
        ctl_batch_id: ctl_batch_id

    return:
        None, True, False
    """
    try:
        response_logs = table_table_run_logs.query(
            IndexName="ctl_batch_id-index",
            KeyConditionExpression=Key('ctl_batch_id').eq(ctl_batch_id)
        )
        table_success = True

        items_response_logs = response_logs['Items']
        items_response_logs.sort(key=lambda x: x['ctl_table_run_status'])
        if len(items_response_logs) == 0:
            return 'None'
        else:
            for item in items_response_logs:
                if (item['ctl_table_run_status'] == 'FAILED'):
                    table_success = False
                    break
            return (table_success)

    except Exception as exc:
        logger.error(exc)
        raise exc


def insert_or_update_table(logger, table, key_column, key_value, exclude_cols_from_overwrites={'lakehouse_table_run_logs': ['table_version_before']}, **kwargs):
        """
        Function that updates the DynamoDB lakehouse tables

        params:
        key_column: the partition key
        key_value: the partition key value
        kwargs: dictionary form of attributes and its values

        Sample for insert:
        kwargs_table ={'ctl_run_id':table_run_id, 'ctl_table_run_status' : 'STARTED', 'table_id': table_id, 'ctl_batch_id': pkg_run_id, 'min_val': table['last_load_key'], 'ctl_table_run_start_time':(datetime.now()).strftime('%Y-%m-%d %H:%M:%S')  }
        insert_or_update_table(table_table_run_logs, 'ctl_run_id', table_run_id, **kwargs_table)

        Sample for update:
        kwargs_table ={'ctl_table_run_status' : 'SUCCESS', 'ctl_table_run_end_time': (datetime.now()).strftime('%Y-%m-%d %H:%M:%S'), 'rows_inserted': rows_inserted }
        insert_or_update_table(table_table_run_logs, 'ctl_run_id', table_run_id, **kwargs_table)

        """
        try:
            
            # first, check if key column exists in the table.
            # normally, if the row does not exist (the dev would know if it's the first time the record is getting inserted), the partition key will be provided as part of the kwargs
            # the change here is - if the batch id (pipeline log run id) already exists in the table after some retries on the EMR cluster,
            # then it will ensure that it will only update the row, so it doesn't fail.
            
            # there are instances wherein we don't want to update the column if value already exists.
            # this is the dict of all the table:column list that should not be overwritten
            # sample: exclude_cols_from_overwrites = {'lakehouse_table_run_logs': ['table_version_before'], 'lakehouse_batch_run_logs': ['batch_name', 'ctl_batch_run_end_time', 'ctl_batch_run_start_time']}
            response = table.query(KeyConditionExpression=Key(key_column).eq(key_value))
            
            if response['Items']:
                
                # check if key column exists on the kwargs
                # if it exists, and since this is an update, remove the key/value on the dict
                if key_column in kwargs.keys():
                    kwargs.pop(key_column) 
                
                # check if the table is in the dict of table/columns to exclude from overwrites
                # if it exists on the dict of tables/cols not to overwrite, then get the cols
                if bool(table.name in exclude_cols_from_overwrites.keys()):
                    cols_to_exclude_list = exclude_cols_from_overwrites[table.name]
                    for col in cols_to_exclude_list:
                        # pop the key on the kwargs
                        if col in response['Items'][0].keys():
                            # pop if there's value in the table column AND the key is in kwargs
                            if bool(response['Items'][0][col]) and col in kwargs.keys() :
                                kwargs.pop(col) 
                
                update_expression = []
                attribute_values = {}
            
                # after all the popping, then come up with the update expression and expressionattributes
                for key, value in kwargs.items():
                    update_expression.append(f'{key}=:{key}')
                    attribute_values[f':{key}'] = value
            
                table.update_item(
                    Key={key_column: key_value},
                    UpdateExpression='set ' + ','.join(update_expression),
                    ExpressionAttributeValues=attribute_values,
                    ReturnValues="UPDATED_NEW"
                )

            else:
                item = kwargs
                table.put_item(Item=item)

        
        except Exception as exc:
            logger.error(exc)
            raise exc


def check_dep_batch_run(logger, table_pipeline_log_runs, dep_batch_id, pipeline_name, back_days=7):
    """
        Function to query the ed_pipeline_log_runs table
        to check if dependent batch is successfully processed
        params:
            dep_batch_id: batch id to be checked in parent pipleine
            pipeline_name: pipeline_name of parent

        return:
            pipeline_run_id
    """

    try:
        s3 = client_session.resource('s3')
        pipeline_run_id = pipeline_name + '-' + (datetime.today() - timedelta(days=back_days)).strftime("%Y-%m-%d")
        resp = table_pipeline_log_runs.query(
            ProjectionExpression='pipeline_name, pipeline_run_id, pipeline_run_status, pipeline_dependencies, record_marker_s3',
            ScanIndexForward=False,
            KeyConditionExpression="pipeline_name = :pipeline_name and pipeline_run_id >= :pipeline_run_id",
            FilterExpression="pipeline_run_status = :pipeline_run_status",
            ExpressionAttributeValues={
                ":pipeline_name": pipeline_name,
                ":pipeline_run_id": pipeline_run_id,
                ":pipeline_run_status": 'success'
            }
        )
        log_runs = resp['Items']

        while 'LastEvaluatedKey' in resp:
            resp = table_pipeline_log_runs.query(
                ProjectionExpression='pipeline_name, pipeline_run_id, pipeline_run_status, pipeline_dependencies, record_marker_s3',
                ScanIndexForward=False,
                KeyConditionExpression="pipeline_name = :pipeline_name and pipeline_run_id >= :pipeline_run_id",
                FilterExpression="pipeline_run_status = :pipeline_run_status",
                ExpressionAttributeValues={
                    ":pipeline_name": pipeline_name,
                    ":pipeline_run_id": pipeline_run_id,
                    ":pipeline_run_status": 'success'
                }, ExclusiveStartKey=resp['LastEvaluatedKey']
            )
            log_runs = log_runs + resp['Items']

        for item in log_runs:
            if "record_marker_s3" in item:
                path_parts = item['record_marker_s3'].replace("s3://", "").split("/")
                s3_bucket = path_parts.pop(0)
                file_key = "/".join(path_parts)
                data = s3.Object(s3_bucket, file_key).get()['Body'].read()
                if "\"batch_id\": " + "\"" + dep_batch_id + "\"" in str(data):
                    return str(item['pipeline_run_id'])
            else:
                for dep in item['pipeline_dependencies']:
                    if "\'batch_id\': " + "\'" + dep_batch_id + "\'" in str(dep):
                        return str(item['pipeline_run_id'])
        return ''

    except Exception as exc:
        logger.error(exc)
        raise exc


def query_pipeline_config(table_pipeline_config, pipeline_name=None):
    """
    Function to query the ed_pipeline_config table

    params:
        table_pipeline_config: batch name
        pipeline_name
        
    return:
        List of configs for the batch
    """
    try:
        if bool(pipeline_name):
            response_table_config = table_pipeline_config.query(
                KeyConditionExpression=Key('pipeline_name').eq(pipeline_name),
                ScanIndexForward=False
                )
        else:
            return
        
        items_pipeline_config = response_table_config['Items'][0]
        return items_pipeline_config
    except Exception as exc:
        raise exc


def get_pipeline_log_run(logger, session, table_name, pipeline_name, pipeline_run_id):
    """
    :param logger
    :param session: session object for dynamo query access
    :param table_name: ed_pipeline_log_runs
    :param pipeline_name: pipeline_name
    :param pipeline_run_id: pipeline_run_id to retreive
    :return: Dict with pipeline_run_log
    """
    try:
        table = session.Table(table_name)
        response = table.query(
            KeyConditionExpression=Key('pipeline_name').eq(pipeline_name) & Key('pipeline_run_id').eq(pipeline_run_id)
        )
    except Exception as exc:
        logger.error(exc)
        logger.error("Error in `get_pipeline_log_run`")
        raise exc
    return response['Items'][0]


def get_sanitize_conf(logger, session, config_table_name, table_id):
    '''
    Will fetch sanitize information for a specific column
    :param session: dynamodb session object
    :param config_table_name: lakehouse_sanitize_config
    :param table_id: table_id value (schema_name + table_name)
    :return: list of dynamodb entries
    '''
    try:
        table = session.Table(config_table_name)
        response = table.query(
            KeyConditionExpression=Key('table_id').eq(table_id)
        )
    except Exception as e:
        logger.error("Error in `get_target_location`")
        logger.error(e)
    return response['Items']

def get_dynamo_record_from_partition_key(logger, table, key_value):
    """
        Function to query dynamo record on hash partition key
        params:
            table: Table object of dynamo table to be queried
            key_value: value of hash key column
        return:
            dict record
    """
    try:
        key_name = [key['AttributeName'] for key in table.key_schema if key['KeyType'] == 'HASH'][0]
        response = table.query(KeyConditionExpression=Key(key_name).eq(key_value))
        if len(response['Items']) == 0:
            return {}
        else:
            return response['Items'][0]
    except Exception as exc:
        logger.error(exc)
        raise exc


def check_validation_status(logger, table_table_run_logs, table_id, validation_dttm, back_days=14):
    """
        Function to query lakehuse table run logs to get validation status of a table
        params:
            table_id: Table id of the dataset to be checked
            validation_dtm: validaiton datetime
        return:
            dict record
    """
    try:
        ctl_table_run_start_time = (datetime.today() - timedelta(days=back_days)).strftime("%Y-%m-%d")
        default_validation_status = {"is_complete": False}
        #       print(ctl_table_run_start_time)
        resp = table_table_run_logs.query(
            IndexName="table_id-ctl_table_run_start_time-index",
            ScanIndexForward=False,
            KeyConditionExpression="table_id = :table_id and ctl_table_run_start_time >= :ctl_table_run_start_time",
            FilterExpression="validation_dttm = :validation_dttm and validation_status.is_complete = :status_value",
            ExpressionAttributeValues={
                ":table_id": table_id,
                ":ctl_table_run_start_time": ctl_table_run_start_time,
                ":validation_dttm": validation_dttm,
                ":status_value": True
            })
        #       print(resp)
        if len(resp['Items']) > 0:
            return resp['Items'][0]['validation_status']
        else:
            return default_validation_status

    except Exception as exc:
        logger.error(exc)
        raise exc