from boto3.dynamodb.conditions import Key
import json
from pyspark.sql.functions import sequence, to_date, explode, col, count, countDistinct, min, max, sha2, concat_ws, \
    row_number, from_unixtime, to_timestamp, lag, lead, xxhash64, lit, coalesce, when, element_at, current_timestamp, \
    format_string, date_format, desc, when, substring
from pyspark.sql.types import *
from pyspark.sql import Window
import boto3
import os
from botocore.config import Config
from operator import itemgetter
from datetime import datetime, timedelta
import sys
from pyspark.sql import functions as f


from lakehouselib.data.schema.handlers.glue.utility import *
from lakehouselib.framework.lakehouse.dynamodb.utility import *
from lakehouselib.data.transform.dataframeutils.utility import *
from lakehouselib.framework.lakehouse.handlers.utility import *
from lakehouselib.data.format.delta.utility import *

# eot-related stuff
from lakehouselib.services.aws.s3.utility import *
from lakehouselib.services.aws.sessionmanager.utility import *
from lakehouselib.statehandlers.eotfile.generator.utility import *
# client_session = create_aws_session()

def build_scd2(spark,df_input, target_schema, target_table, batch_id, resp_tbl, resp_meta):

    """
        This function reads the data from input df and writes data back
        with end dating utilizing meta information from dynamo tables

    """
    
    spark.sql("SET spark.databricks.delta.schema.autoMerge.enabled = true")
    spark.catalog.clearCache()

    # Generate run id
    run_id = str(int(datetime.utcnow().timestamp() * 1000))
    print("Generated run id for this run: " + run_id)
    #     df_input.show(10, False)
    table_id = resp_tbl[0]['table_id']
    target_s3_bucket = resp_tbl[0]['target_s3_location']
    load_type = resp_tbl[0]['load_type'].split("|")[0]
    last_load_key = str(resp_tbl[0]['last_load_key'])
    incremental_key_col = resp_tbl[0]['source_incr_column'].split("|")[0]
    seq_key_cols = resp_tbl[0]['source_incr_column'].split("|")[1:]
    if (len(seq_key_cols) == 0):
        seq_key_cols = [incremental_key_col]
    timestamp_col = resp_tbl[0]['source_ts_column']
    src_partition_col = str(resp_tbl[0]['source_partition_column']).split("|")
    target_partition_col = str(resp_tbl[0]['target_partition_column']).split("|")
    rows_inserted = '0'
    rows_updated = '0'

    # Inserting start entry to run log table					  	 
    dynamodb = get_resource('dynamodb', region_name='ap-southeast-2')
    log_table = dynamodb.Table('lakehouse_table_run_logs')
    
    kwargs_table ={'ctl_run_id':run_id, 'ctl_batch_id': batch_id, 'table_id': table_id, 'min_val': last_load_key, 'ctl_table_run_start_time': str(datetime.now().strftime("%Y-%m-%d %H:%M:%S")), 'rows_inserted': '0', 'rows_updated': '0', 'ctl_table_run_status': 'STARTED'}
    insert_or_update_table(log_table, 'ctl_run_id', run_id, **kwargs_table)

    

    try:
        sorted_meta_rows = sorted(resp_meta, key=itemgetter('target_column_order'))
        aud_col = [item['target_column_alias'] for item in sorted_meta_rows if item['is_audit_column'] == True]
        data_col = [item['target_column_alias'] for item in sorted_meta_rows if
                    item['is_audit_column'] == False and item['is_target_table_key'] == False]
        business_key_col = [item['target_column_alias'] for item in sorted_meta_rows if
                            item['is_target_table_key'] == True]
        hash_col = [item['target_column_alias'] for item in sorted_meta_rows if item['is_audit_column'] == False]

        if len(data_col) > 0:
            # Dynamically create select - filter, alias, typecast all the required columns
            select_expr = []
            select_distinct_col = set()
            for item in sorted_meta_rows:
                select_expr.append("cast(" + item["target_column_name"] + " as " + (
                    item["target_column_datatype"] + "(" + str(item["target_column_precision"]) + "," + str(
                        item["target_column_scale"]) + ")" if item["target_column_datatype"].lower() == "decimal" else
                    item["target_column_datatype"]) + ") " + item["target_column_alias"])
                select_distinct_col.add(item["source_column_name"])

            print("Reading source data")
            df_input = df_input.select(*list(select_distinct_col))

            print("Applying falttening")
            df_src = flatten_array_struct_df(df_input)

            print("Enforcing meta schema")
            df_delta = df_src.selectExpr(select_expr)

        else:
            df_delta = df_input
        #         df_delta.show(10, False)

        print("filtering not null business keys")
        bk_not_null_query = ""
        for bk in business_key_col:
            bk_not_null_query = bk_not_null_query + bk + " IS NOT NULL AND "
        bk_not_null_query = bk_not_null_query[:-4]
        df_delta = df_delta.filter(bk_not_null_query)
        #         df_delta.show(10, False)

        # assign hash on the data columns
        print("applying hash")
        df_delta = df_delta.withColumn("ctl_hash", xxhash64(*(hash_col)))

        print("Repartitioning incoming delta df")
        #             df_delta = df_delta.repartition(50).cache() # paramterize later
        df_delta = df_delta.cache()
        df_delta = df_delta.coalesce(200)
        src_count = df_delta.count()
        print("src_count: " + str(src_count))

        print("Removing dups")
        df_delta = df_delta.withColumn("row_num", row_number().over(
            Window.partitionBy(*(business_key_col + [incremental_key_col])).orderBy(
                *[desc(c) for c in seq_key_cols]))).filter(col("row_num") == 1).drop("row_num")
        #         df_delta.show(10, False)					  

        print("Getting Last Load Key from source")
        if (len(src_partition_col) > 0 and src_count > 0):
            print("Adding partition information to last load key")
            p_query = ""
            for p_col_source in src_partition_col:
                for item in sorted_meta_rows:
                    if item["source_column_name"] == p_col_source:
                        p_col_target = item["target_column_alias"]
                p_query = p_query + '\"{}>=\",\"\\\"\",max({}),\"\\\"\", \" AND \",'.format(p_col_source,
                                                                                            p_col_target)
            p_query = p_query[:-10]
            p_query = "concat(" + p_query + ") as max_parition_col"
            last_load_info = df_delta.selectExpr(
                [f"max({incremental_key_col}) as last_load_key", f"{p_query}"]).collect()
            print("last_load_info: " + str(last_load_info))
            last_load_key = str(last_load_info[0].asDict()["last_load_key"]) + "|" + last_load_info[0].asDict()[
                "max_parition_col"]
            print("last_load_key: " + str(last_load_key))
        elif len(src_partition_col) == 0 and src_count > 0:
            last_load_info = df_delta.selectExpr([f"max({incremental_key_col}) as last_load_key"]).collect()
            print("last_load_info: " + str(last_load_info))
            last_load_key = str(last_load_info[0].asDict()["last_load_key"]) + "|"
            print("last_load_key: " + str(last_load_key))
        else:
          last_load_key =  str(resp_tbl[0]['last_load_key'])
        
        if int(last_load_key.split("|")[0]) <= int(resp_tbl[0]['last_load_key'].split("|")[0]):
            print("no new delta records found from source")
            max_partition = str(resp_tbl[0]['last_load_key']).split("|")[1]
            partition_date = [str(x).strip().split("=")[1].replace("\"", "") for x in max_partition.split("AND") if 'p_headerdate' in x][0]
            next_date = datetime.strptime(partition_date, '%Y-%m-%d').date() + timedelta(days=1)
            curr_utc_date = datetime.utcnow().date()
            if(next_date <= curr_utc_date):
                last_load_key = str(resp_tbl[0]['last_load_key']).split("|")[0] + "|" + "p_headerdate>=\"" + str(next_date) + "\""
            else:
              last_load_key = str(resp_tbl[0]['last_load_key'])
            print("last_load_key: " + str(last_load_key))

        if src_count > 0:

            if (load_type.lower() == "hist"):
                print("*********** HISTORICAL SCD2 LOAD IN PROGRESS ********** ")

                print("applying prev_rec_hash_val")
                df_delta = df_delta.withColumn("prev_rec_hash_val", lag(col=col("ctl_hash"), default=-1, offset=1).over(
                    Window.partitionBy(*(business_key_col)).orderBy(col(incremental_key_col))))

                print("filtering unchanged")
                df_delta = df_delta.filter(col("prev_rec_hash_val") != col("ctl_hash"))

                # end date records in case multiple updates coming in delta df
                print("adding scd columns")

                df_delta = df_delta.withColumn("p_headerts", to_timestamp(
                    format_string("%s.%s", date_format(from_unixtime(col(timestamp_col) / 1000), "yyyy-MM-dd HH:mm:ss"),
                                  (substring(col(incremental_key_col), -3, 3))))) \
                    .withColumn("ctl_effective_start_utc_dts", col("p_headerts")) \
                    .withColumn("ctl_effective_end_utc_dts",
                                lead(col=col("ctl_effective_start_utc_dts"), default='9999-12-31', offset=1).over(
                                    Window.partitionBy(*(business_key_col)).orderBy(col(incremental_key_col))))

                # write delta to target
                print("write to target")
                df_delta.drop("prev_rec_hash_val") \
                    .withColumn("ctl_inserted_run_id", lit(run_id)) \
                    .withColumn("ctl_updated_run_id", lit(run_id)) \
                    .withColumn("op_type", lit("I")) \
                    .withColumn("ctl_created_utc_dts", current_timestamp()) \
                    .withColumn("ctl_modified_utc_dts", current_timestamp()) \
                    .withColumn("ctl_part_id", lit(0)) \
                    .withColumn("ctl_is_deleted", lit(0)) \
                    .withColumn("ctl_src_id", lit(1)) \
                    .withColumn("ctl_created_batch_id", lit(batch_id)) \
                    .withColumn("ctl_updated_batch_id", lit(batch_id)).write.partitionBy(*(target_partition_col)).format("delta").mode("overwrite").option(
                    "overwriteSchema", "true").option("mergeSchema", "true").save(
                    target_s3_bucket + "/" + target_schema + "/" + target_table)

                # Table creation on the target
                print("creating target DB")
                spark.sql(f"""
                CREATE DATABASE IF NOT EXISTS {target_schema}
                COMMENT 'Bronze Database Activity Feeds' 
                LOCATION '{target_s3_bucket}/{target_schema}/'
                """)

                print("creating target table")
                spark.sql(f""" DROP TABLE IF EXISTS {target_schema}.{target_table} """)
                spark.sql(f"""
                CREATE TABLE {target_schema}.{target_table}
                USING DELTA LOCATION '{target_s3_bucket}/{target_schema}/{target_table}'
                """)

                rows_inserted = \
                    spark.sql(
                        "select count(*) as rows_inserted from {}.{} ".format(target_schema, target_table)).collect()[
                        0].asDict()["rows_inserted"]
                print("rows_inserted: " + str(rows_inserted))
                rows_updated = '0'
                print("rows_updated: " + str(rows_updated))

                # save the incremental key value in Dynamo for subsequent delta loads
                print("last_load_key: " + str(last_load_key))
                dynamodb = get_resource('dynamodb', region_name='ap-southeast-2')
                config_table = dynamodb.Table('lakehouse_table_config')
                kwargs_table_config = {'last_load_key': last_load_key, 'load_type': 'INC' }
                insert_or_update_table(config_table, 'table_id', table_id, **kwargs_table_config)
                
                
                print("*********** HISTORICAL SCD2 LOAD COMPLETED ********** ")
            else:

                print("*********** INCREMENTAL SCD2 LOAD IN PROGRESS ********** ")

                # Read target data
                print("Reading target data")
                df_current = spark.read.format("delta").load(
                    target_s3_bucket + "/" + target_schema + "/" + target_table)
                #             df_current.show(10, False)

                # Remove duplicates from df_delta
                print("Joining with target to get active rows for delta")
                df_join = df_current.join(df_delta.select(*(business_key_col)).distinct(), business_key_col,
                                          "inner").select(df_current["*"]).drop("p_headerts").drop(
                    "ctl_effective_start_utc_dts").drop("ctl_effective_end_utc_dts")

                print("Unioning delta with active records from target")
                df_union = df_join.unionByName(df_delta, allowMissingColumns=True)

                # prepare full select delta df
                print("prepare df_inserts/updates")
                df_scd2 = df_union.withColumn("ctl_inserted_run_id", lit(run_id)) \
                    .withColumn("ctl_updated_run_id", lit(run_id)) \
                    .withColumn("op_type", lit("I")) \
                    .withColumn("ctl_created_utc_dts",
                                when(col("ctl_created_utc_dts").isNull(), current_timestamp()).otherwise(
                                    col("ctl_created_utc_dts"))) \
                    .withColumn("ctl_modified_utc_dts", current_timestamp()) \
                    .withColumn("ctl_part_id", lit(0)) \
                    .withColumn("ctl_is_deleted", lit(0)) \
                    .withColumn("ctl_src_id", lit(1))\
                    .withColumn("ctl_created_batch_id", lit(batch_id)) \
                    .withColumn("ctl_updated_batch_id", lit(batch_id))
                
                print("applying prev_rec_hash_val")
                df_scd2 = df_scd2.withColumn("prev_rec_hash_val", lag(col=col("ctl_hash"), default=-1, offset=1).over(
                    Window.partitionBy(*(business_key_col)).orderBy(
                        *([incremental_key_col] + ["ctl_created_utc_dts"]))))

                print("filtering unchanged")
                df_scd2 = df_scd2.filter(col("prev_rec_hash_val") != col("ctl_hash")).drop("prev_rec_hash_val")

                # end date records incase multiple updates coming in df_scd2
                print("Adding end dating columns to delta")
                df_scd2.withColumn("p_headerts", to_timestamp(
                    format_string("%s.%s", date_format(from_unixtime(col(timestamp_col) / 1000), "yyyy-MM-dd HH:mm:ss"),
                                  (substring(col(incremental_key_col), -3, 3))))) \
                    .withColumn("ctl_effective_start_utc_dts", col("p_headerts")) \
                    .withColumn("ctl_effective_end_utc_dts",
                                lead(col=col("ctl_effective_start_utc_dts"), default='9999-12-31', offset=1).over(
                                    Window.partitionBy(*(business_key_col)).orderBy(
                                        *([incremental_key_col] + ["ctl_created_utc_dts"])))) \
                    .createOrReplaceTempView("tmp_l1_df_scd2_updates")

                # Prepare join condition for updating end date on updated records
                update_sql_join = ""
                for i in business_key_col + [incremental_key_col] + ['ctl_hash']:
                    update_sql_join = update_sql_join + "Source." + i + " = Target." + i + " AND "
                update_sql_join = update_sql_join[:-4]

                # End date the records which have a new version  # add runid and op_type = I/U then use this to get counts
                print("Merging updates")
                spark.sql(f"""
                            MERGE INTO {target_schema}.{target_table} AS Target USING tmp_l1_df_scd2_updates AS Source 
                            ON {update_sql_join}  
                            WHEN MATCHED AND Target.ctl_effective_end_utc_dts <> Source.ctl_effective_end_utc_dts 
                            THEN UPDATE SET Target.ctl_effective_end_utc_dts = Source.ctl_effective_end_utc_dts, Target.op_type = 'U', Target.ctl_updated_run_id = Source.ctl_updated_run_id, 
                            Target.ctl_modified_utc_dts = current_timestamp(), Target.ctl_updated_batch_id = Source.ctl_updated_batch_id
                            WHEN NOT MATCHED
                            THEN INSERT *
                             """)

                rows_info = \
                    spark.sql(f"DESCRIBE HISTORY {target_schema}.{target_table}").filter(
                        col('operation').isin(['WRITE', 'MERGE'])).orderBy(col("version").desc()).limit(1).select(
                            element_at(col('operationMetrics'), 'numTargetRowsUpdated').alias("rows_updated"),
                            element_at(col('operationMetrics'), 'numTargetRowsInserted').alias("rows_inserted")
                    ).collect()[0]

                rows_updated = str(rows_info["rows_updated"])
                print("rows_updated: " + str(rows_updated))
                rows_inserted = str(rows_info["rows_inserted"])
                print("rows_inserted: " + str(rows_inserted))

                print("updating last load key to config table")
                dynamodb = get_resource('dynamodb', region_name='ap-southeast-2')
                config_table = dynamodb.Table('lakehouse_table_config')				  
                kwargs_table_config = {'last_load_key': last_load_key}
                insert_or_update_table(config_table, 'table_id', table_id, **kwargs_table_config)

                #       spark.catalog.clearCache()
                print("*********** INCREMENTAL SCD2 LOAD COMPLETED ********** ")
        else:
            print("No records to be merged from the source")
            print("Updating last load key")
            print("last_load_key: " + str(last_load_key))
            dynamodb = get_resource('dynamodb', region_name='ap-southeast-2')
            config_table = dynamodb.Table('lakehouse_table_config')				  
            kwargs_table_config = {'last_load_key': last_load_key, 'load_type': 'INC' }
            insert_or_update_table(config_table, 'table_id', table_id, **kwargs_table_config)
            
    except Exception as ex:
        print(str(ex))
        dynamodb = get_resource('dynamodb', region_name='ap-southeast-2')
        log_table = dynamodb.Table('lakehouse_table_run_logs')
        # Write failure entry to log table
        print(str(sys.exc_info()))
        ex_type, ex_value, ex_traceback = sys.exc_info()

        kwargs_table ={'ctl_table_run_status' : 'FAILED', 'ctl_err_code': str(ex_type.__name__), 'ctl_err_desc': str(ex_value), 'ctl_table_run_end_time': (datetime.now()).strftime('%Y-%m-%d %H:%M:%S') }
        insert_or_update_table(log_table, 'ctl_run_id', run_id, **kwargs_table)        		 
        raise

    else:
        # No exceptions, write success entry to log table
        dynamodb = get_resource('dynamodb', region_name='ap-southeast-2')
        log_table = dynamodb.Table('lakehouse_table_run_logs')
        
        kwargs_table ={'max_val' : last_load_key, 'rows_inserted': rows_inserted, 'rows_updated': rows_updated, 'ctl_table_run_status': 'SUCCESS', 'ctl_table_run_end_time': str(datetime.now().strftime("%Y-%m-%d %H:%M:%S")) }
        insert_or_update_table(log_table, 'ctl_run_id', run_id, **kwargs_table)

def merge_sat(spark,sqlContext, df_input, batch_id, resp_tbl, ref_batch_list, hash_excl_col_list, logger):
    spark.sql("SET spark.databricks.delta.schema.autoMerge.enabled = true")
    run_id = str(int(datetime.utcnow().timestamp() * 1000))
    logger.info("Generated run id for this run: " + run_id)
    table_id = resp_tbl['Items'][0]['table_id']
    logger.info("table_id: " + table_id)
    rows_inserted = '0'
    rows_updated = '0'
    rows_deleted = '0'

    # Inserting start entry to run log table
    client_session = create_aws_session()
    dynamodb = client_session.resource('dynamodb', region_name='ap-southeast-2')
    log_table = dynamodb.Table('lakehouse_table_run_logs')
    kwargs_table = {'ctl_run_id': run_id, 'ctl_batch_id': batch_id, 'table_id': table_id,
                    'min_val': ref_batch_list[0], 'max_val': ref_batch_list[-1],
                    'ctl_table_run_start_time': str(datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
                    'rows_inserted': '0', 'rows_updated': '0', 'ctl_table_run_status': 'STARTED'}
    insert_or_update_table(logger, log_table, 'ctl_run_id', run_id, **kwargs_table)

    load_type = resp_tbl['Items'][0]['load_type'].split("|")[0]
    logger.info("load_type: " + load_type)
    key_cols = resp_tbl['Items'][0]['key_columns'].split(",")
    logger.info("key_cols: " + str(key_cols))
    target_partition_col = str(resp_tbl['Items'][0]['target_partition_column']).split("|")
    logger.info("target_partition_col: " + str(target_partition_col))
    target_table = resp_tbl['Items'][0]['target_table_name']
    logger.info("target_table_name: " + target_table)
    target_schema = resp_tbl['Items'][0]['target_schema_name']
    logger.info("target_schema_name: " + target_schema)
    target_s3_location = resp_tbl['Items'][0]['target_s3_location']
    logger.info("target_s3_location: " + target_s3_location)
    incremental_key_col = resp_tbl['Items'][0]['source_incr_column'].split("|")[0]
    logger.info("incremental_key_col: " + incremental_key_col)
    separator = '|'
    logger.info("separator: " + str(separator))

    aud_cols = ['ctl_inserted_run_id', 'ctl_updated_run_id', 'op_type',
                'ctl_created_utc_dts', 'ctl_modified_utc_dts', 'ctl_part_id', 'ctl_is_deleted', 'ctl_src_id',
                'ctl_effective_start_utc_dts', 'ctl_effective_end_utc_dts', 'ctl_hash', 'ctl_created_batch_id',
                'ctl_updated_batch_id']

    hash_excl_col_list = hash_excl_col_list + aud_cols

    try:
        logger.info("applying hash")
        
        hash_cols = sorted([c for c in df_input.columns if c not in hash_excl_col_list])
        logger.info("hash_cols: " + str(hash_cols))
        df_delta = df_input.withColumn("ctl_hash", xxhash64(*hash_cols))
        # df_delta.show(10, False)

        if len(df_delta.head(1)) > 0:

            if (load_type.lower() == "hist"):
                logger.info("*********** HISTORICAL SCD2 LOAD IN PROGRESS ********** ")
                logger.info("write to target")
                df_delta_final = df_delta.withColumn("ctl_inserted_run_id", lit(run_id)) \
                    .withColumn("ctl_updated_run_id", lit(run_id)) \
                    .withColumn("op_type", lit("I")) \
                    .withColumn("ctl_created_utc_dts", current_timestamp()) \
                    .withColumn("ctl_modified_utc_dts", current_timestamp()) \
                    .withColumn("ctl_part_id", lit(0)) \
                    .withColumn("ctl_is_deleted", lit(0)) \
                    .withColumn("ctl_src_id", lit(1)) \
                    .withColumn("ctl_created_batch_id", lit(batch_id)) \
                    .withColumn("ctl_updated_batch_id", lit(batch_id))

                df_delta_final.write.partitionBy(*(target_partition_col)).format("delta").mode("overwrite") \
                    .option("overwriteSchema", "true").option("mergeSchema", "true").save(
                    target_s3_location + "/" + target_schema + "/" + target_table)

                dict_target_schema_defn = dict(df_delta_final.dtypes)
                target_schema_defn = convert_kv_to_string(dict_target_schema_defn, separator)
                new_cols_list = create_hive_metastore(logger, spark, sqlContext, target_schema, target_s3_location,
                                                      target_table, dict_target_schema_defn,
                                                      target_partition_col[0], separator)

                update_glue_catalog(logger, spark, target_s3_location, target_schema, target_table,
                                    target_schema_defn, target_partition_col[0], new_cols_list)

                rows_inserted = \
                    spark.sql(
                        "select count(*) as rows_inserted from {}.{} ".format(target_schema,
                                                                              target_table)).collect()[
                        0].asDict()["rows_inserted"]
                logger.info("rows_inserted: " + str(rows_inserted))
                rows_updated = '0'
                logger.info("rows_updated: " + str(rows_updated))

                client_session = create_aws_session()
                dynamodb = client_session.resource('dynamodb', region_name='ap-southeast-2')
                config_table = dynamodb.Table('lakehouse_table_config')
                config_table.update_item(
                    Key={
                        'table_id': table_id
                    },
                    UpdateExpression="SET last_load_key = :last_load_key, load_type = :load_type ",
                    ExpressionAttributeValues={":last_load_key": ref_batch_list[-1], ":load_type": "INC"},
                )
                logger.info("*********** HISTORICAL SCD2 LOAD COMPLETED ********** ")
            else:
                logger.info("*********** INCREMENTAL SCD2 LOAD IN PROGRESS ********** ")

                logger.info("Reading target data")
                df_current = spark.read.format("delta").load(
                    target_s3_location + "/" + target_schema + "/" + target_table).where(
                    "ctl_effective_end_utc_dts = '9999-12-31'")

                df_delta = df_delta.withColumn("ctl_inserted_run_id", lit(run_id)) \
                    .withColumn("ctl_updated_run_id", lit(run_id)) \
                    .withColumn("op_type", lit("I")) \
                    .withColumn("ctl_created_utc_dts", current_timestamp()) \
                    .withColumn("ctl_modified_utc_dts", current_timestamp()) \
                    .withColumn("ctl_part_id", lit(0)) \
                    .withColumn("ctl_is_deleted", lit(0)) \
                    .withColumn("ctl_src_id", lit(1)) \
                    .withColumn("ctl_created_batch_id", lit(batch_id)) \
                    .withColumn("ctl_updated_batch_id", lit(batch_id))

                dict_target_schema_defn = dict(df_delta.dtypes)
                target_schema_defn = convert_kv_to_string(dict_target_schema_defn, separator)
                new_cols_list = create_hive_metastore(logger, spark, sqlContext, target_schema, target_s3_location,
                                                      target_table, dict_target_schema_defn,
                                                      target_partition_col[0], separator)
                logger.info("new_cols_list")
                logger.info(str(new_cols_list))

                df_join = df_delta.join(df_current, key_cols).filter(
                    df_current['ctl_hash'] != df_delta['ctl_hash']).select(df_delta['*'])

                #                 print("df_join")
                #                 df_join.printSchema()
                #                 df_join.show(10, False)

                for kc in key_cols:
                    df_join = df_join.withColumn(kc + "_mergekey", lit(None))
                    df_delta = df_delta.withColumn(kc + "_mergekey", col(kc))

                #                 print("df_delta")
                #                 df_delta.printSchema()
                #                 print("df_join")
                #                 df_join.printSchema()

                df_source = df_delta.unionByName(df_join, allowMissingColumns=True)
                df_source.createOrReplaceTempView("df_source")

                insert_cols = ''
                insert_vals = ''
                for ic in df_source.columns:
                    if not ic.endswith('_mergekey'):
                        insert_cols = insert_cols + ic + ','
                        insert_vals = insert_vals + 'Source.' + ic + ','
                insert_cols = insert_cols[:-1]
                insert_vals = insert_vals[:-1]

                #                 print("insert_cols: " + insert_cols)
                #                 print("insert_vals: " + insert_vals)

                update_sql_join = ""
                for i in key_cols:
                    update_sql_join = update_sql_join + "Source." + i + "_mergekey" + " = Target." + i + " AND "
                update_sql_join = update_sql_join[:-4]

                merge_stmt = f"""
                            MERGE INTO {target_schema}.{target_table} AS Target USING df_source AS Source 
                            ON {update_sql_join}  
                            WHEN MATCHED AND Target.ctl_effective_end_utc_dts='9999-12-31' AND Target.ctl_hash = Source.ctl_hash AND Source.ctl_effective_start_utc_dts < Target.ctl_effective_start_utc_dts
                            THEN UPDATE SET Target.ctl_effective_start_utc_dts = Source.ctl_effective_start_utc_dts, Target.op_type = 'U', Target.ctl_updated_run_id = Source.ctl_updated_run_id, 
                            Target.ctl_modified_utc_dts = Source.ctl_modified_utc_dts, Target.ctl_updated_batch_id = Source.ctl_updated_batch_id
                            WHEN MATCHED AND Target.ctl_effective_end_utc_dts='9999-12-31' AND Target.ctl_hash != Source.ctl_hash
                            THEN UPDATE SET Target.ctl_effective_end_utc_dts = Source.ctl_effective_start_utc_dts, Target.op_type = 'U', Target.ctl_updated_run_id = Source.ctl_updated_run_id, 
                            Target.ctl_modified_utc_dts = Source.ctl_modified_utc_dts, Target.ctl_updated_batch_id = Source.ctl_updated_batch_id
                            WHEN NOT MATCHED THEN
                            INSERT({insert_cols})
                            VALUES({insert_vals})
                            """
                logger.info(merge_stmt)
                merge_data(logger, spark, merge_stmt)

                rows_info = \
                    spark.sql(f"DESCRIBE HISTORY {target_schema}.{target_table}").filter(
                        col('operation').isin(['WRITE', 'MERGE'])).orderBy(col("version").desc()).limit(1).select(
                            element_at(col('operationMetrics'), 'numTargetRowsUpdated').alias("rows_updated"),
                            element_at(col('operationMetrics'), 'numTargetRowsInserted').alias("rows_inserted")
                    ).collect()[0]

                rows_updated = str(rows_info["rows_updated"])
                logger.info("rows_updated: " + str(rows_updated))
                rows_inserted = str(rows_info["rows_inserted"])
                logger.info("rows_inserted: " + str(rows_inserted))

                logger.info("Calling update_glue_catalog")
                logger.info(str(target_partition_col))
                update_glue_catalog(logger, spark, target_s3_location, target_schema, target_table, target_schema_defn,
                                    target_partition_col[0], new_cols_list)

                logger.info("updating last load key to config table")
                client_session = create_aws_session()
                dynamodb = client_session.resource('dynamodb', region_name='ap-southeast-2')
                config_table = dynamodb.Table('lakehouse_table_config')
                kwargs_table_config = {'last_load_key': ref_batch_list[-1]}
                insert_or_update_table(logger, config_table, 'table_id', table_id, **kwargs_table_config)

                #       spark.catalog.clearCache()
                logger.info("*********** INCREMENTAL SCD2 LOAD COMPLETED ********** ")
        else:
            logger.info("No records to be merged from the source")

    except Exception as ex:
        logger.error(str(ex))
        client_session = create_aws_session()
        dynamodb = client_session.resource('dynamodb', region_name='ap-southeast-2')
        log_table = dynamodb.Table('lakehouse_table_run_logs')
        # Write failure entry to log table
        logger.error(str(sys.exc_info()))
        ex_type, ex_value, ex_traceback = sys.exc_info()
        kwargs_table = {'ctl_table_run_status': 'FAILED', 'ctl_err_code': str(ex_type.__name__),
                        'ctl_err_desc': str(ex_value),
                        'ctl_table_run_end_time': str(datetime.now().strftime("%Y-%m-%d %H:%M:%S"))}
        insert_or_update_table(logger, log_table, 'ctl_run_id', run_id, **kwargs_table)
        #             spark.catalog.clearCache()
        raise

    else:
        # No exceptions, write success entry to log table
        client_session = create_aws_session()
        dynamodb = client_session.resource('dynamodb', region_name='ap-southeast-2')
        log_table = dynamodb.Table('lakehouse_table_run_logs')
        kwargs_table = {'rows_inserted': rows_inserted, 'rows_updated': rows_updated,
                        'ctl_table_run_status': 'SUCCESS',
                        'ctl_table_run_end_time': str(datetime.now().strftime("%Y-%m-%d %H:%M:%S"))}
        insert_or_update_table(logger, log_table, 'ctl_run_id', run_id, **kwargs_table)
        #             spark.catalog.clearCache()
        return {'rows_inserted': int(rows_inserted), 'rows_updated': int(rows_updated),
                'rows_deleted': int(rows_deleted)}


def merge_sat_scd2(spark,sqlContext, df_input, batch_id, resp_tbl, ref_batch_list, hash_excl_col_list, logger):
    # This function merges data into the target table and sets ctl_effective_start_utc_dts and ctl_effective_end_utc_dts to create an scd2 history in the target table.
    # For this function to work:
    # Source records must be:
    # 	1. A row with a new key (not existing in target table) - these rows will be inserted
    # 	2. A row with an existing key that is next in sequence for the key.
    # 	NB. All source rows MUST have ctl_effective_end_utc_dts = '9999-12-31' - otherwise the next row processed for the same key will fail

    # The target table must have: 
    # 	1. No match on the key for any records in source
    # OR
    #   2. A record with match on the key AND ctl_effective_end_utc_dts = '9999-12-31'

    # If the source record has the same key, ctl_hash and ctl_effective_start_utc_dts, then no changes will be made to the target.

    spark.sql("SET spark.databricks.delta.schema.autoMerge.enabled = true")
    run_id = str(int(datetime.utcnow().timestamp() * 1000))
    logger.info("Generated run id for this run (merge_sat_scd2): " + run_id)
    table_id = resp_tbl['table_id']
    table_run_id = batch_id + '_' + table_id
    logger.info("table_id: " + table_id)
    rows_inserted = '0'
    rows_updated = '0'
    rows_deleted = '0'

    
    load_type = resp_tbl['load_type'].split("|")[0]
    logger.info("load_type: " + load_type)
    key_cols = resp_tbl['key_columns'].split(",")
    logger.info("key_cols: " + str(key_cols))
    target_partition_col = str(resp_tbl['target_partition_column']).split("|")
    logger.info("target_partition_col: " + str(target_partition_col))
    target_table = resp_tbl['target_table_name']
    logger.info("target_table_name: " + target_table)
    target_schema = resp_tbl['target_schema_name']
    logger.info("target_schema_name: " + target_schema)
    target_s3_location = resp_tbl['target_s3_location']
    logger.info("target_s3_location: " + target_s3_location)
    incremental_key_col = resp_tbl['source_incr_column'].split("|")[0]
    logger.info("incremental_key_col: " + incremental_key_col)
    separator = '|'
    logger.info("separator: " + str(separator))

    aud_cols = ['ctl_inserted_run_id', 'ctl_updated_run_id', 'ctl_src_id',
                'ctl_created_utc_dts', 'ctl_modified_utc_dts', 'ctl_part_id', 'ctl_is_deleted', 
                'ctl_effective_start_utc_dts', 'ctl_effective_end_utc_dts', 'ctl_hash', 'ctl_inserted_batch_id',
                'ctl_updated_batch_id']

    hash_excl_col_list = hash_excl_col_list + aud_cols

    try:
        ts = datetime.utcnow()
        logger.info("applying hash")
        df_input.printSchema()
        hash_cols = sorted([c for c in df_input.columns if c not in hash_excl_col_list])
        logger.info("hash_cols: " + str(hash_cols))
        df_delta = df_input.withColumn("ctl_hash", xxhash64(*hash_cols))
        # df_delta.show(10, False)

        if len(df_delta.head(1)) > 0:

            if (load_type.lower() == "hist"):
                logger.info("*********** HISTORICAL SCD2 LOAD IN PROGRESS ********** ")
                logger.info("write to target")
                
                
                df_delta_final = add_ctl_columns_on_source_dataframe(logger, df_delta, batch_id, table_run_id, ts, table_type='sat')
               
                df_delta_final.write.partitionBy(*(target_partition_col)).format("delta").mode("overwrite") \
                    .option("overwriteSchema", "true").option("mergeSchema", "true").save(
                    target_s3_location + "/" + target_schema + "/" + target_table)

                dict_target_schema_defn = dict(df_delta_final.dtypes)
                target_schema_defn = convert_kv_to_string(dict_target_schema_defn, separator)
                new_cols_list = create_hive_metastore(logger, spark, sqlContext, target_schema, target_s3_location,
                                                      target_table, dict_target_schema_defn,
                                                      target_partition_col[0], separator)

                update_glue_catalog(logger, spark, target_s3_location, target_schema, target_table,
                                    target_schema_defn, target_partition_col[0], new_cols_list)

                

                kwargs_table_config = {'last_load_key': ref_batch_list[-1], 'load_type': 'INC' }
                insert_or_update_table(logger, table_table_config, 'table_id', table_id, **kwargs_table_config)

                logger.info("*********** HISTORICAL SCD2 LOAD COMPLETED ********** ")
            else:
                logger.info("*********** INCREMENTAL SCD2 LOAD IN PROGRESS ********** ")

                df_delta = add_ctl_columns_on_source_dataframe(logger, df_delta, batch_id, table_run_id, ts, table_type='sat')

                logger.info("printing dups on df_delta start")
                # logger.info(df_delta.withColumn("rn", row_number().over(
                #     Window.partitionBy(*(key_cols)).orderBy(*(['ctl_effective_start_utc_dts'])))).where('rn>1').show(10,
                #                                                                                                      False))
                logger.info("printing dups on df_delta end")

                dict_target_schema_defn = dict(df_delta.dtypes)
                target_schema_defn = convert_kv_to_string(dict_target_schema_defn, separator)
                new_cols_list = create_hive_metastore(logger, spark, sqlContext, target_schema, target_s3_location,
                                                      target_table, dict_target_schema_defn,
                                                      target_partition_col[0], separator)

                
                logger.info("new_cols_list")
                logger.info(str(new_cols_list))
                logger.info("Reading target data")

                df_current = spark.read.format("delta").load(
                    target_s3_location + "/" + target_schema + "/" + target_table).where(
                    "ctl_effective_end_utc_dts = '9999-12-31'")

                df_join = df_delta.join(df_current, key_cols).filter(
                    df_current['ctl_hash'] != df_delta['ctl_hash']).select(df_delta['*']).distinct()

                for kc in key_cols:
                    df_join = df_join.withColumn(kc + "_mergekey", lit(None))
                    df_delta = df_delta.withColumn(kc + "_mergekey", col(kc))

                df_source = df_delta.unionByName(df_join, allowMissingColumns=True)

                # dedupe_key_columns = list(key_cols)
                # df_source = dedupe_dataframe_on_key(logger, df_source, dedupe_key_columns.append('ctl_hash'))
                df_source = df_source.cache()
                df_source_count = df_source.count()
                logger.info("df_source_count: " + str(df_source_count))
                df_source.createOrReplaceTempView("df_source")

                insert_cols = ''
                insert_vals = ''
                for ic in df_source.columns:
                    if not ic.endswith('_mergekey'):
                        insert_cols = insert_cols + ic + ','
                        insert_vals = insert_vals + 'Source.' + ic + ','
                insert_cols = insert_cols[:-1]
                insert_vals = insert_vals[:-1]

                update_sql_join = ""
                for i in key_cols:
                    update_sql_join = update_sql_join + "Source." + i + "_mergekey" + " = Target." + i + " AND "
                update_sql_join = update_sql_join[:-4]

                merge_stmt = f"""
                            MERGE INTO {target_schema}.{target_table} AS Target USING df_source AS Source 
                            ON {update_sql_join}  
                            WHEN MATCHED AND Target.ctl_effective_end_utc_dts='9999-12-31' AND Target.ctl_hash = Source.ctl_hash AND Source.ctl_effective_start_utc_dts < Target.ctl_effective_start_utc_dts
                            THEN UPDATE SET Target.ctl_effective_start_utc_dts = Source.ctl_effective_start_utc_dts, Target.ctl_updated_run_id = Source.ctl_updated_run_id, 
                            Target.ctl_modified_utc_dts = Source.ctl_modified_utc_dts, Target.ctl_updated_batch_id = Source.ctl_updated_batch_id
                            WHEN MATCHED AND Target.ctl_effective_end_utc_dts='9999-12-31' AND Target.ctl_hash != Source.ctl_hash
                            THEN UPDATE SET Target.ctl_effective_end_utc_dts = Source.ctl_effective_start_utc_dts, Target.ctl_updated_run_id = Source.ctl_updated_run_id, 
                            Target.ctl_modified_utc_dts = Source.ctl_modified_utc_dts, Target.ctl_updated_batch_id = Source.ctl_updated_batch_id
                            WHEN NOT MATCHED THEN
                            INSERT({insert_cols})
                            VALUES({insert_vals})
                            """
                logger.info(merge_stmt)
                merge_data(logger, spark, merge_stmt)

                logger.info("Calling update_glue_catalog")
                logger.info(str(target_partition_col))
                update_glue_catalog(logger, spark, target_s3_location, target_schema, target_table, target_schema_defn,
                                    target_partition_col[0], new_cols_list)

                logger.info("updating last load key to config table")
                
                kwargs_table_config = {'last_load_key': ref_batch_list[-1]}
                insert_or_update_table(logger, table_table_config, 'table_id', table_id, **kwargs_table_config)

                #       spark.catalog.clearCache()
                logger.info("*********** INCREMENTAL SCD2 LOAD COMPLETED ********** ")
        else:
            logger.info("No records to be merged from the source")

    except Exception as ex:
        logger.error(str(ex))
                
        raise

    else:
        
        return {'rows_inserted': int(rows_inserted), 'rows_updated': int(rows_updated),
                'rows_deleted': int(rows_deleted)}

def merge_scd2(spark,sqlContext, df_input, batch_id, resp_tbl, ref_batch_list, hash_excl_col_list, logger):
    # This function merges data into the target table and sets ctl_effective_start_utc_dts and ctl_effective_end_utc_dts to create an scd2 history in the target table.
    # This replaces the merge_sat_scd2 to address the issues outlined on this page: https://sportsbet.atlassian.net/wiki/spaces/JJ/pages/11503894939/DPT-6007+Dups+in+Residential+Address
    # This would fix these issues:
    # - duplicates on the sat table
    # - incorrect effective end dates
    # - effective start > effective end date
    #
    # Notes: 
    # On this version, inserts and updates related to no of rows inserted/updated on the lakehouse_table_run_logs are no longer done. This is handled on the pipeline itself
    # The correct no of rows inserted/updated are captured/identified on the generate_delta_batch_eot function
    
    spark.sql("SET spark.databricks.delta.schema.autoMerge.enabled = true")
    run_id = str(int(datetime.utcnow().timestamp() * 1000))
    logger.info("START of merge_scd2 with run id: " + run_id)
    
    # Define the variables
    table_id = resp_tbl['table_id']
    load_type = resp_tbl['load_type'].split("|")[0]
    # normally, key column is just one column in all sat tables
    # however, this is converted to a list later to be sure
    key_columns = resp_tbl['key_columns']
    # convert key_columns to a list - there are other pipelines that use pipe as separator, others use comma. 
    key_cols = key_columns.split(',') if ',' in key_columns else key_columns.split('|')
    # this is one columnn that can be hub_customer_id in other tables or hub_account_id in other silver tables
    # this needs to be in lakehouse table config
    key_col_parent = resp_tbl['key_col_parent'] 
    key_cols_parent = key_col_parent.split(',') if ',' in key_col_parent else key_col_parent.split('|') #pm
    target_partition_col = str(resp_tbl['target_partition_column']).split("|")
    target_table = resp_tbl['target_table_name']
    target_schema = resp_tbl['target_schema_name']
    target_s3_location = resp_tbl['target_s3_location']
    target_schema_defn = resp_tbl.get('target_schema_defn')
    incremental_key_col = resp_tbl['source_incr_column'].split("|")[0]
    separator = '|'
    aud_cols = ['ctl_inserted_run_id', 'ctl_updated_run_id', 'ctl_src_id',
                'ctl_created_utc_dts', 'ctl_modified_utc_dts', 'ctl_part_id', 'ctl_is_deleted', 
                'ctl_effective_start_utc_dts', 'ctl_effective_end_utc_dts', 'ctl_hash', 'ctl_inserted_batch_id',
                'ctl_updated_batch_id']
    cols_to_ignore_during_update = [ 'ctl_inserted_run_id','ctl_created_utc_dts','ctl_part_id', 'ctl_src_id', 'ctl_inserted_batch_id']
    cols_to_update_when_matched = [ 'ctl_updated_run_id','ctl_modified_utc_dts','ctl_is_deleted', 'ctl_effective_start_utc_dts', 'ctl_effective_end_utc_dts', 'ctl_updated_batch_id']
    hash_excl_col_list = hash_excl_col_list + aud_cols

    logger.info("table_id: " + table_id + " load_type: " + load_type + " key_cols: " + str(key_cols) + " incremental_key_col: " + incremental_key_col)
    logger.info("target_partition_col: " + str(target_partition_col) + " target_table_name: " + target_table + " target_schema_name: " + target_schema + " target_s3_location: " + target_s3_location)
    
    try:
        ts = datetime.utcnow()
        logger.info("applying hash")
        df_input.printSchema()
        hash_cols = sorted([c for c in df_input.columns if c not in hash_excl_col_list])
        logger.info("hash_cols: " + str(hash_cols))
        df_delta = df_input.withColumn("ctl_hash", xxhash64(*hash_cols))

        if len(df_delta.head(1)) > 0:

            # add ctl columns
            df_delta = add_ctl_columns_on_source_dataframe(logger, df_delta, batch_id, run_id, ts, table_type='sat')
            
            # get the schema definition of the input/source table
            if not bool(target_schema_defn):
                dict_target_schema_defn = dict(df_delta.dtypes)
                target_schema_defn = convert_kv_to_string(dict_target_schema_defn, separator)
            else:
                # Convert the target_schema_defn stored in DynamoDB (in str) to dict
                # This is pipe delimited
                dict_target_schema_defn = convert_string_to_dict(target_schema_defn, separator)
            
            if (load_type.lower() == "hist"):
                logger.info("*********** HISTORICAL SCD2 LOAD IN PROGRESS ********** ")
                
                df_delta.write.partitionBy(*(target_partition_col)).format("delta").mode("overwrite") \
                    .option("overwriteSchema", "true").option("mergeSchema", "true").save(
                    target_s3_location + "/" + target_schema + "/" + target_table)

                new_cols_list = create_hive_metastore(logger, spark, sqlContext, target_schema, target_s3_location,
                                                      target_table, dict_target_schema_defn,
                                                      target_partition_col[0], separator)

                update_glue_catalog(logger, spark, target_s3_location, target_schema, target_table,
                                    target_schema_defn, target_partition_col[0], new_cols_list)
                
                kwargs_table_config = {'last_load_key': ref_batch_list[-1], 'load_type': 'INC' }
                insert_or_update_table(logger, table_table_config, 'table_id', table_id, **kwargs_table_config)

                logger.info("*********** HISTORICAL SCD2 LOAD COMPLETED ********** ")
            else:
                logger.info("*********** INCREMENTAL SCD2 LOAD IN PROGRESS ********** ")
                
                # NOTE: Dataframes/tables/views are used and not CTEs as it's easier to query the data while debugging/testing

                # create the delta table
                new_cols_list = create_hive_metastore(logger, spark, sqlContext, target_schema, target_s3_location,
                                                      target_table, dict_target_schema_defn,
                                                      target_partition_col[0], separator)
                
                # Derive the variables used by the merge and other sql statements 
                key_column_list = []
                if bool(key_cols):
                    for column in key_cols:  
                        key_column_list.append('a.' + column + ' =  b.' + column )
                
                # pm    
                key_column_parent_list = []
                key_column_parent_partition_by_list = []
                if bool(key_cols_parent):
                    for column in key_cols_parent:  
                        key_column_parent_list.append('a.' + column + ' =  b.' + column )
                        key_column_parent_partition_by_list.append('a.' + column)

                target_partition_column_list = []
                if bool(target_partition_col):
                    for column in target_partition_col:  
                        target_partition_column_list.append('a.' + column + ' =  b.' + column )


                target_schema_defn_list = target_schema_defn.split('|')
                update_fields_when_hash_not_matched_list = []
                update_fields_when_hash_matched_list = []
                insert_fields_list = []
                for column in target_schema_defn_list:
                    column_name = column.split(' ')[0]
                    if column_name not in cols_to_ignore_during_update and column_name not in key_column_list:
                        update_fields_when_hash_not_matched_list.append(f'a.{column_name} = b.{column_name}')
                    if column_name in cols_to_update_when_matched:
                        update_fields_when_hash_matched_list.append(f'a.{column_name} = b.{column_name}')
                    insert_fields_list.append(column_name)
                
                #let's create a temp table/view so that we can query it later
                df_delta =  df_delta.withColumn("source",lit("_delta")) 
                df_delta.createOrReplaceTempView("tbl_delta")
                
                logger.info('Get minimum effective dates')
                # Get the min effective start date of every customer in the delta table
                # This way, even if we process the same data over and over again, we'd be able to get the correct sequence of dates.
                df_min_effective_start_date_sql = f"""
                    select {key_col_parent}, min(ctl_effective_start_utc_dts) as min_ctl_effective_start_utc_dts
                    from tbl_delta
                    group by {key_col_parent}
                    """
                logger.info(df_min_effective_start_date_sql)
                df_min_effective_start_date = spark.sql(df_min_effective_start_date_sql)
                df_min_effective_start_date.createOrReplaceTempView("tbl_min_effective_start_date") 

                # Get any records greater than the min effective start date
                # Also get one row less than the min effective dated row
                df_current_sql = f"""
                    with prev_records as (
                        select {'a.'+', a.'.join(insert_fields_list)}, row_number() over(partition by {' , '.join(key_column_parent_partition_by_list)} order by a.ctl_effective_start_utc_dts desc) rownum
                        from {target_schema}.{target_table} a
                        inner join tbl_min_effective_start_date b on {' and '.join(key_column_parent_list)}
                        where a.ctl_effective_start_utc_dts < min_ctl_effective_start_utc_dts
                            and a.ctl_is_deleted = 0
                        )
                    select {','.join(insert_fields_list)} 
                    from prev_records
                    where rownum =1
                    union
                    select {'a.'+', a.'.join(insert_fields_list)} 
                    from {target_schema}.{target_table} a
                    inner join tbl_min_effective_start_date b on {' and '.join(key_column_parent_list)}
                    where (a.ctl_effective_end_utc_dts =  '9999-12-31'
                        or a.ctl_effective_start_utc_dts >= min_ctl_effective_start_utc_dts)
                        and a.ctl_is_deleted = 0
                    """
                logger.info (df_current_sql)
                df_current = spark.sql(df_current_sql)
                df_current = df_current.withColumn("source",lit("current")) 
                df_current.createOrReplaceTempView("tbl_current") 

                # Let's do a union now to see what it looks like
                # We're joining current data in S3 and the delta so that we can properly expire old records later
                df_source = df_delta.unionByName(df_current, allowMissingColumns=True)
                df_source.createOrReplaceTempView("tbl_source")

                # This is for those records where there's no change on the data but only on the effective start date
                # This will contain only the valid data that we need to merge
                df_filtered_source = spark.sql(f"""
                    with unique_effective_start as
                    (
                    select distinct {key_col_parent}, ctl_effective_start_utc_dts
                    from tbl_source
                    ),
                    source as (
                        select {' , '.join(key_column_parent_partition_by_list)}, a.ctl_effective_start_utc_dts, a.ctl_hash, a.source, row_number() over (partition by {' , '.join(key_column_parent_partition_by_list)}, a.ctl_effective_start_utc_dts order by a.source) as row_num
                        from tbl_source a
                        inner join unique_effective_start b on {' and '.join(key_column_parent_list)}  and a.ctl_effective_start_utc_dts = b.ctl_effective_start_utc_dts
                    ),
                    distinct_source as (
                    select * from source 
                    where row_num = 1
                    ),
                    a as (
                        select {key_col_parent},ctl_effective_start_utc_dts, ctl_hash, 
                            lead(ctl_hash, 1, 0) over (partition by {key_col_parent} order by ctl_effective_start_utc_dts) as next_ctl_hash,
                            lag(ctl_hash, 1, 0) over (partition by {key_col_parent} order by ctl_effective_start_utc_dts) as prev_ctl_hash
                        from distinct_source
                        order by {key_col_parent}, ctl_effective_start_utc_dts
                        )
                    select {key_col_parent}, ctl_effective_start_utc_dts, ctl_hash 
                    from a
                    where (ctl_hash = next_ctl_hash and next_ctl_hash <> prev_ctl_hash) 
                        or (ctl_hash <> next_ctl_hash and ctl_hash <> prev_ctl_hash)
                        or (next_ctl_hash =0 and prev_ctl_hash =0)
                    """)
                df_filtered_source.createOrReplaceTempView("tbl_filtered_source")

                # As we joined current and delta earlier, we may have dups here on instances we are reprocessing bronze
                # Eliminate the dups on key values here 
                # NOTE: dropDuplicates will not work or even distinct - believe me. It's because of the data where there might be a diff ctl_created_utc_dt or other field values
                
                df_final_sql = f"""
                    with complete_list as (
                        select a.*, 
                        row_number() over(partition by {' , '.join(key_column_parent_partition_by_list)}, a.{key_columns}, a.ctl_effective_start_utc_dts, a.ctl_hash order by a.ctl_created_utc_dt) as row_num 
                        from tbl_source a
                        inner join tbl_filtered_source b on {' and '.join(key_column_parent_list)} 
                        and a.ctl_hash = b.ctl_hash 
                        and a.ctl_effective_start_utc_dts = b.ctl_effective_start_utc_dts
                        )
                    select * from complete_list where row_num = 1
                    """
                logger.info (df_final_sql)
                df_final = spark.sql(df_final_sql)
                # we're dropping the effective end date as it's no longer correct
                df_final = df_final.drop("ctl_effective_end_utc_dts") 

                # ensure there are no dups
                df_final = dedupe_dataframe_on_key(logger, df_final, key_cols)
                df_final.createOrReplaceTempView("tbl_final")

                # Apply the correct effective end dates
                df_final_source = spark.sql(f"""    
                        select * 
                        , LEAD(ctl_effective_start_utc_dts, 1, '9999-12-31') OVER(PARTITION BY {key_col_parent} ORDER BY ctl_effective_start_utc_dts) as ctl_effective_end_utc_dts
                        from tbl_final 
                        """)
                df_final_source.createOrReplaceTempView("tbl_final_source")

                # Merge for the inserts and updates
                merge_stmt = f"""MERGE INTO {target_schema}.{target_table} as a
                            USING tbl_final_source b
                            ON {' and '.join(key_column_list + target_partition_column_list)}
                            WHEN MATCHED AND a.ctl_hash = b.ctl_hash and a.ctl_effective_end_utc_dts <> b.ctl_effective_end_utc_dts and a.ctl_is_deleted = 0
                            THEN UPDATE SET {','.join(update_fields_when_hash_matched_list)}
                            WHEN MATCHED AND a.ctl_hash = b.ctl_hash and a.ctl_is_deleted = 1
                            THEN UPDATE SET {','.join(update_fields_when_hash_matched_list)}
                            WHEN MATCHED AND a.ctl_hash <> b.ctl_hash and a.ctl_is_deleted = 0
                            THEN UPDATE SET {','.join(update_fields_when_hash_not_matched_list)}
                            WHEN NOT MATCHED 
                            THEN INSERT ({','.join(insert_fields_list)})
                            VALUES({'b.'+', b.'.join(insert_fields_list)})    
                            """
                logger.info(merge_stmt)
                merge_data(logger, spark, merge_stmt)
                
                # for records that are no longer considered valid, delete the data (ctl_is_deleted=1)
                # we can monitor for another week if there's no issue on effective end dates
                df_to_be_deleted_sql = f"""select a.* 
                    from tbl_current a 
                    left outer join tbl_final_source b 
                    on {' and '.join(key_column_parent_list)}
                    and a.{key_columns} = b.{key_columns}
                    and a.ctl_effective_start_utc_dts = b.ctl_effective_start_utc_dts
                    where b.{key_columns} is null
                    """
                df_to_be_deleted = spark.sql(df_to_be_deleted_sql) 
                # update these fields to reflect that batch and time the record is getting updated
                if len(df_to_be_deleted.head(1)) > 0:
                    df_to_be_deleted = df_to_be_deleted.withColumn('ctl_is_deleted', lit(1)) \
                        .withColumn('ctl_updated_run_id', lit(run_id)) \
                        .withColumn('ctl_updated_batch_id', lit(batch_id)) \
                        .withColumn('ctl_modified_utc_dts', lit(ts)) \
                        .withColumn('ctl_effective_end_utc_dts', col('ctl_effective_start_utc_dts'))
                    # again, convert to temp view/table
                    df_to_be_deleted.createOrReplaceTempView("tbl_to_be_deleted")
                    
                    # Merge for the deletion
                    merge_delete_stmt = f"""MERGE INTO {target_schema}.{target_table} as a
                            USING tbl_to_be_deleted b
                            ON {' and '.join(key_column_list + target_partition_column_list)}
                            WHEN MATCHED AND a.ctl_hash = b.ctl_hash and a.ctl_is_deleted = 0
                            THEN UPDATE SET {','.join(update_fields_when_hash_matched_list)}
                            """
                    logger.info(merge_delete_stmt)
                    merge_data(logger, spark, merge_delete_stmt)
               
                logger.info("Calling update_glue_catalog")
                update_glue_catalog(logger, spark, target_s3_location, target_schema, target_table, target_schema_defn,
                                    target_partition_col[0], new_cols_list)

                logger.info("updating last load key to config table")
                kwargs_table_config = {'last_load_key': ref_batch_list[-1]}
                insert_or_update_table(logger, table_table_config, 'table_id', table_id, **kwargs_table_config)

                logger.info("*********** INCREMENTAL SCD2 LOAD COMPLETED ********** ")
        else:
            logger.info("No records to be merged from the source")

    except Exception as ex:
        logger.error(str(ex))
        
        # Write failure entry to log table
        logger.error(str(sys.exc_info()))
        ex_type, ex_value, ex_traceback = sys.exc_info()
        kwargs_table = {'ctl_table_run_status': 'FAILED', 'ctl_err_code': str(ex_type.__name__),
                        'ctl_err_desc': str(ex_value),
                        'ctl_table_run_end_time': str(datetime.now().strftime("%Y-%m-%d %H:%M:%S"))}
        insert_or_update_table(logger, table_table_run_logs, 'ctl_run_id', run_id, **kwargs_table)
        
        raise

def merge_scd2_merge_count(spark,sqlContext, df_input, batch_id, resp_tbl, ref_batch_list, hash_excl_col_list, logger):
    # new version of merge_scd2 that returns merge_count - number of times merge has been called on table
    # This function merges data into the target table and sets ctl_effective_start_utc_dts and ctl_effective_end_utc_dts to create an scd2 history in the target table.
    # This replaces the merge_sat_scd2 to address the issues outlined on this page: https://sportsbet.atlassian.net/wiki/spaces/JJ/pages/11503894939/DPT-6007+Dups+in+Residential+Address
    # This would fix these issues:
    # - duplicates on the sat table
    # - incorrect effective end dates
    # - effective start > effective end date
    #
    # Notes: 
    # On this version, inserts and updates related to no of rows inserted/updated on the lakehouse_table_run_logs are no longer done. This is handled on the pipeline itself
    # The correct no of rows inserted/updated are captured/identified on the generate_delta_batch_eot function
    # 
    # Modification: add merge_count as return value
    # Modification: Specify which date value to sort on, don't assume ctl_created_utc_dt
    
    spark.sql("SET spark.databricks.delta.schema.autoMerge.enabled = true")
    run_id = str(int(datetime.utcnow().timestamp() * 1000))
    logger.info("START of merge_scd2_date_key with run id: " + run_id)
        
    # Define the variables
    table_id = resp_tbl['table_id']
    load_type = resp_tbl['load_type'].split("|")[0]
    # normally, key column is just one column in all sat tables
    # however, this is converted to a list later to be sure
    key_columns = resp_tbl['key_columns']
    # convert key_columns to a list - there are other pipelines that use pipe as separator, others use comma. 
    key_cols = key_columns.split(',') if ',' in key_columns else key_columns.split('|')
    # this is one columnn that can be hub_customer_id in other tables or hub_account_id in other silver tables
    # this needs to be in lakehouse table config
    key_col_parent = resp_tbl['key_col_parent'] 
    key_cols_parent = key_col_parent.split(',') if ',' in key_col_parent else key_col_parent.split('|') #pm
    target_partition_col = str(resp_tbl['target_partition_column']).split("|")
    target_table = resp_tbl['target_table_name']
    target_schema = resp_tbl['target_schema_name']
    target_s3_location = resp_tbl['target_s3_location']
    target_schema_defn = resp_tbl.get('target_schema_defn')
    incremental_key_col = resp_tbl['source_incr_column'].split("|")[0]
    separator = '|'
    aud_cols = ['ctl_inserted_run_id', 'ctl_updated_run_id', 'ctl_src_id',
                'ctl_created_utc_dts', 'ctl_modified_utc_dts', 'ctl_part_id', 'ctl_is_deleted', 
                'ctl_effective_start_utc_dts', 'ctl_effective_end_utc_dts', 'ctl_hash', 'ctl_inserted_batch_id',
                'ctl_updated_batch_id']
    cols_to_ignore_during_update = [ 'ctl_inserted_run_id','ctl_created_utc_dts','ctl_part_id', 'ctl_src_id', 'ctl_inserted_batch_id']
    cols_to_ignore_during_update.append(target_partition_col)
    cols_to_update_when_matched = [ 'ctl_updated_run_id','ctl_modified_utc_dts','ctl_is_deleted', 'ctl_effective_start_utc_dts', 'ctl_effective_end_utc_dts', 'ctl_updated_batch_id']
    hash_excl_col_list = hash_excl_col_list + aud_cols
    merge_count = 0 # track the number of merges made from this function

    logger.info("table_id: " + table_id + " load_type: " + load_type + " key_cols: " + str(key_cols) + " incremental_key_col: " + incremental_key_col)
    logger.info("target_partition_col: " + str(target_partition_col) + " target_table_name: " + target_table + " target_schema_name: " + target_schema + " target_s3_location: " + target_s3_location)
    
    try:
        ts = datetime.utcnow()
        logger.info("applying hash")
        df_input.printSchema()
        hash_cols = sorted([c for c in df_input.columns if c not in hash_excl_col_list])
        logger.info("hash_cols: " + str(hash_cols))
        df_delta = df_input.withColumn("ctl_hash", xxhash64(*hash_cols))

        if len(df_delta.head(1)) > 0:

            # add ctl columns
            df_delta = add_ctl_columns_on_source_dataframe(logger, df_delta, batch_id, run_id, ts, table_type='sat')
            
            # get the schema definition of the input/source table
            if not bool(target_schema_defn):
                dict_target_schema_defn = dict(df_delta.dtypes)
                target_schema_defn = convert_kv_to_string(dict_target_schema_defn, separator)
            else:
                # Convert the target_schema_defn stored in DynamoDB (in str) to dict
                # This is pipe delimited
                dict_target_schema_defn = convert_string_to_dict(target_schema_defn, separator)
            
            if (load_type.lower() == "hist"):
                logger.info("*********** HISTORICAL SCD2 LOAD IN PROGRESS ********** ")
                
                df_delta.write.partitionBy(*(target_partition_col)).format("delta").mode("overwrite") \
                    .option("overwriteSchema", "true").option("mergeSchema", "true").save(
                    target_s3_location + "/" + target_schema + "/" + target_table)
                merge_count = merge_count + 1 # Not strictly a merge, but count as one for eot generation purposes

                new_cols_list = create_hive_metastore(logger, spark, sqlContext, target_schema, target_s3_location,
                                                      target_table, dict_target_schema_defn,
                                                      target_partition_col[0], separator)

                update_glue_catalog(logger, spark, target_s3_location, target_schema, target_table,
                                    target_schema_defn, target_partition_col[0], new_cols_list)
                
                kwargs_table_config = {'last_load_key': ref_batch_list[-1], 'load_type': 'INC' }
                insert_or_update_table(logger, table_table_config, 'table_id', table_id, **kwargs_table_config)

                logger.info("*********** HISTORICAL SCD2 LOAD COMPLETED ********** ")
            else:
                logger.info("*********** INCREMENTAL SCD2 LOAD IN PROGRESS ********** ")
                
                # NOTE: Dataframes/tables/views are used and not CTEs as it's easier to query the data while debugging/testing

                # create the delta table
                new_cols_list = create_hive_metastore(logger, spark, sqlContext, target_schema, target_s3_location,
                                                      target_table, dict_target_schema_defn,
                                                      target_partition_col[0], separator)
                
                # Derive the variables used by the merge and other sql statements 
                key_column_list = []
                if bool(key_cols):
                    for column in key_cols:  
                        key_column_list.append('a.' + column + ' =  b.' + column )
                
                # pm    
                key_column_parent_list = []
                key_column_parent_partition_by_list = []
                if bool(key_cols_parent):
                    for column in key_cols_parent:  
                        key_column_parent_list.append('a.' + column + ' =  b.' + column )
                        key_column_parent_partition_by_list.append('a.' + column)


                target_schema_defn_list = target_schema_defn.split('|')
                update_fields_when_hash_not_matched_list = []
                update_fields_when_hash_matched_list = []
                insert_fields_list = []
                for column in target_schema_defn_list:
                    column_name = column.split(' ')[0]
                    if column_name not in cols_to_ignore_during_update and column_name not in key_column_list:
                        update_fields_when_hash_not_matched_list.append(f'a.{column_name} = b.{column_name}')
                    if column_name in cols_to_update_when_matched:
                        update_fields_when_hash_matched_list.append(f'a.{column_name} = b.{column_name}')
                    insert_fields_list.append(column_name)
                
                #let's create a temp table/view so that we can query it later
                df_delta =  df_delta.withColumn("source",lit("_delta")) 
                df_delta.createOrReplaceTempView("tbl_delta")
                
                logger.info('Get minimum effective dates')
                # Get the min effective start date of every customer in the delta table
                # This way, even if we process the same data over and over again, we'd be able to get the correct sequence of dates.
                df_min_effective_start_date_sql = f"""
                    select {key_col_parent}, min(ctl_effective_start_utc_dts) as min_ctl_effective_start_utc_dts
                    from tbl_delta
                    group by {key_col_parent}
                    """
                logger.info(df_min_effective_start_date_sql)
                df_min_effective_start_date = spark.sql(df_min_effective_start_date_sql)
                df_min_effective_start_date.createOrReplaceTempView("tbl_min_effective_start_date") 

                # Get any records greater than the min effective start date
                # Also get one row less than the min effective dated row
                df_current_sql = f"""
                    with prev_records as (
                        select {'a.'+', a.'.join(insert_fields_list)}, row_number() over(partition by {' , '.join(key_column_parent_partition_by_list)} order by a.ctl_effective_start_utc_dts desc) rownum
                        from {target_schema}.{target_table} a
                        inner join tbl_min_effective_start_date b on {' and '.join(key_column_parent_list)}
                        where a.ctl_effective_start_utc_dts < min_ctl_effective_start_utc_dts
                            and a.ctl_is_deleted = 0
                        )
                    select {','.join(insert_fields_list)} 
                    from prev_records
                    where rownum =1
                    union
                    select {'a.'+', a.'.join(insert_fields_list)} 
                    from {target_schema}.{target_table} a
                    inner join tbl_min_effective_start_date b on {' and '.join(key_column_parent_list)}
                    where (a.ctl_effective_end_utc_dts =  '9999-12-31'
                        or a.ctl_effective_start_utc_dts >= min_ctl_effective_start_utc_dts)
                        and a.ctl_is_deleted = 0
                    """
                logger.info (df_current_sql)
                df_current = spark.sql(df_current_sql)
                df_current = df_current.withColumn("source",lit("current")) 
                df_current.createOrReplaceTempView("tbl_current") 

                # Let's do a union now to see what it looks like
                # We're joining current data in S3 and the delta so that we can properly expire old records later
                df_source = df_delta.unionByName(df_current, allowMissingColumns=True)
                df_source.createOrReplaceTempView("tbl_source")

                # This is for those records where there's no change on the data but only on the effective start date
                # This will contain only the valid data that we need to merge
                df_filtered_source = spark.sql(f"""
                    with unique_effective_start as
                    (
                    select distinct {key_col_parent}, ctl_effective_start_utc_dts
                    from tbl_source
                    ),
                    source as (
                        select {' , '.join(key_column_parent_partition_by_list)}, a.ctl_effective_start_utc_dts, a.ctl_hash, a.source, row_number() over (partition by {' , '.join(key_column_parent_partition_by_list)}, a.ctl_effective_start_utc_dts order by a.source) as row_num
                        from tbl_source a
                        inner join unique_effective_start b on {' and '.join(key_column_parent_list)}  and a.ctl_effective_start_utc_dts = b.ctl_effective_start_utc_dts
                    ),
                    distinct_source as (
                    select * from source 
                    where row_num = 1
                    ),
                    a as (
                        select {key_col_parent},ctl_effective_start_utc_dts, ctl_hash, 
                            lead(ctl_hash, 1, 0) over (partition by {key_col_parent} order by ctl_effective_start_utc_dts) as next_ctl_hash,
                            lag(ctl_hash, 1, 0) over (partition by {key_col_parent} order by ctl_effective_start_utc_dts) as prev_ctl_hash
                        from distinct_source
                        order by {key_col_parent}, ctl_effective_start_utc_dts
                        )
                    select {key_col_parent}, ctl_effective_start_utc_dts, ctl_hash 
                    from a
                    where (ctl_hash = next_ctl_hash and next_ctl_hash <> prev_ctl_hash) 
                        or (ctl_hash <> next_ctl_hash and ctl_hash <> prev_ctl_hash)
                        or (next_ctl_hash =0 and prev_ctl_hash =0)
                    """)
                df_filtered_source.createOrReplaceTempView("tbl_filtered_source")

                # As we joined current and delta earlier, we may have dups here on instances we are reprocessing bronze
                # Eliminate the dups on key values here 
                # NOTE: dropDuplicates will not work or even distinct - believe me. It's because of the data where there might be a diff ctl_created_utc_dt or other field values
                
                df_final_sql = f"""
                    with complete_list as (
                        select a.*, 
                        row_number() over(partition by {' , '.join(key_column_parent_partition_by_list)}, a.{key_columns}, a.ctl_effective_start_utc_dts, a.ctl_hash order by a.{target_partition_col[0]}) as row_num 
                        from tbl_source a
                        inner join tbl_filtered_source b on {' and '.join(key_column_parent_list)} 
                        and a.ctl_hash = b.ctl_hash 
                        and a.ctl_effective_start_utc_dts = b.ctl_effective_start_utc_dts
                        )
                    select * from complete_list where row_num = 1
                    """
                logger.info (df_final_sql)
                df_final = spark.sql(df_final_sql)
                # we're dropping the effective end date as it's no longer correct
                df_final = df_final.drop("ctl_effective_end_utc_dts") 

                # ensure there are no dups
                df_final = dedupe_dataframe_on_key(logger, df_final, key_cols)
                df_final.createOrReplaceTempView("tbl_final")

                # Apply the correct effective end dates
                df_final_source = spark.sql(f"""    
                        select * 
                        , LEAD(ctl_effective_start_utc_dts, 1, '9999-12-31') OVER(PARTITION BY {key_col_parent} ORDER BY ctl_effective_start_utc_dts) as ctl_effective_end_utc_dts
                        from tbl_final 
                        """)
                df_final_source.createOrReplaceTempView("tbl_final_source")

                # Merge for the inserts and updates
                merge_stmt = f"""MERGE INTO {target_schema}.{target_table} as a
                            USING tbl_final_source b
                            ON {' and '.join(key_column_list)}
                            WHEN MATCHED AND a.ctl_hash = b.ctl_hash and a.ctl_effective_end_utc_dts <> b.ctl_effective_end_utc_dts and a.ctl_is_deleted = 0
                            THEN UPDATE SET {','.join(update_fields_when_hash_matched_list)}
                            WHEN MATCHED AND a.ctl_hash = b.ctl_hash and a.ctl_is_deleted = 1
                            THEN UPDATE SET {','.join(update_fields_when_hash_matched_list)}
                            WHEN MATCHED AND a.ctl_hash <> b.ctl_hash and a.ctl_is_deleted = 0
                            THEN UPDATE SET {','.join(update_fields_when_hash_not_matched_list)}
                            WHEN NOT MATCHED 
                            THEN INSERT ({','.join(insert_fields_list)})
                            VALUES({'b.'+', b.'.join(insert_fields_list)})    
                            """
                logger.info(merge_stmt)
                merge_data(logger, spark, merge_stmt)
                merge_count = merge_count + 1
                
                # for records that are no longer considered valid, delete the data (ctl_is_deleted=1)
                # we can monitor for another week if there's no issue on effective end dates
                df_to_be_deleted_sql = f"""select a.* 
                    from tbl_current a 
                    left outer join tbl_final_source b 
                    on {' and '.join(key_column_parent_list)}
                    and a.{key_columns} = b.{key_columns}
                    and a.ctl_effective_start_utc_dts = b.ctl_effective_start_utc_dts
                    where b.{key_columns} is null
                    """
                df_to_be_deleted = spark.sql(df_to_be_deleted_sql) 
                # update these fields to reflect that batch and time the record is getting updated
                if len(df_to_be_deleted.head(1)) > 0:
                    df_to_be_deleted = df_to_be_deleted.withColumn('ctl_is_deleted', lit(1)) \
                        .withColumn('ctl_updated_run_id', lit(run_id)) \
                        .withColumn('ctl_updated_batch_id', lit(batch_id)) \
                        .withColumn('ctl_modified_utc_dts', lit(ts)) \
                        .withColumn('ctl_effective_end_utc_dts', col('ctl_effective_start_utc_dts'))
                    # again, convert to temp view/table
                    df_to_be_deleted.createOrReplaceTempView("tbl_to_be_deleted")
                    
                    # Merge for the deletion
                    merge_delete_stmt = f"""MERGE INTO {target_schema}.{target_table} as a
                            USING tbl_to_be_deleted b
                            ON {' and '.join(key_column_list)}
                            WHEN MATCHED AND a.ctl_hash = b.ctl_hash and a.ctl_is_deleted = 0
                            THEN UPDATE SET {','.join(update_fields_when_hash_matched_list)}
                            """
                    logger.info(merge_delete_stmt)
                    merge_data(logger, spark, merge_delete_stmt)
                    merge_count = merge_count + 1
               
                logger.info("Calling update_glue_catalog")
                update_glue_catalog(logger, spark, target_s3_location, target_schema, target_table, target_schema_defn,
                                    target_partition_col[0], new_cols_list)

                logger.info("updating last load key to config table")
                kwargs_table_config = {'last_load_key': ref_batch_list[-1]}
                insert_or_update_table(logger, table_table_config, 'table_id', table_id, **kwargs_table_config)

                logger.info("*********** INCREMENTAL SCD2 LOAD COMPLETED ********** ")
        else:
            logger.info("No records to be merged from the source")

        return merge_count
    except Exception as ex:
        logger.error(str(ex))
        
        # Write failure entry to log table
        logger.error(str(sys.exc_info()))
        ex_type, ex_value, ex_traceback = sys.exc_info()
        kwargs_table = {'ctl_table_run_status': 'FAILED', 'ctl_err_code': str(ex_type.__name__),
                        'ctl_err_desc': str(ex_value),
                        'ctl_table_run_end_time': str(datetime.now().strftime("%Y-%m-%d %H:%M:%S"))}
        insert_or_update_table(logger, table_table_run_logs, 'ctl_run_id', run_id, **kwargs_table)
        
        raise

def check_if_row_already_loaded(spark, df_input, batch_id, run_id, modified_utc_dts, target_tbl, match_cols_list, hash_excl_col_list, logger):
    """     
    This function checks for rows already existing in the target table, matching on both match_cols_list and hash, and if found:
     - updates the target ctl_updated_run_id, ctl_modified_utc_dts,ctl_updated_batch_id,ctl_updated_batch_id
     -returns the source dataset (df_input) with the previously loaded rows removed.  
     This is used prior to an scd2 type load, to avoid unnecessary/unwanted changes to effective start/end dates

    Parameters
    ----------
    spark : org.apache.spark
        The SparkSession object constructed created from `main.py`

     df_input: the dataset to be checked for previously loaded rows
    
    batch_id: the batch_id to use in updating the target rows, if they are found to be loaded already
    
    run_id: the run_id to use in updating the target rows, if they are found to be loaded already
    
    modified_utc_dts: the modified timestamp to use in updating the target rows, if they are found to be loaded already

    target_tbl: a list object containing parameters for the table to be loaded

    match_cols: A list with the columns to use in matching rows between source and target.
                This can be different from the keys for the table.  For example: Bet with mates uses activity_action and
                activity_utc_dts as well as the key columns to find matches.

    hash_excl_col_list: A list of columns to exclude from the hash key.

    logger : util.system.logging class Log4j
        The referenced log4j object obtained from `main.py`

    Returns:
        RDD/dataframe: Modified dataframe (previously loaded rows removed)
"""
    
    spark.sql("SET spark.databricks.delta.schema.autoMerge.enabled = true")
    logger.info("run id for this run (check_if_row_already_loaded): " + run_id)
    table_id = target_tbl['table_id']
    logger.info("table_id: " + table_id)
    
    target_table = target_tbl['target_table_name']
    logger.info("target_table_name: " + target_table)
    target_schema = target_tbl['target_schema_name']
    logger.info("target_schema_name: " + target_schema)
    
    #Check to see if the target table exists.  If not, then the rows cannot have been loaded alredy, so
    # return df_input unchanged.
    query = f"select * from {target_schema}.{target_table} limit 1"
    try:
      spark.sql(query)
      logger.info("table exists check passed OK")
    except Exception as ex:
        if "not found" in  str(ex):
            logger.info("table not found")
            return df_input
        else:
            raise ex
    
    logger.info("match_cols_list: " + str(match_cols_list))
 
    aud_cols = ['ctl_inserted_run_id', 'ctl_updated_run_id', 'ctl_src_id', 
                'ctl_created_utc_dts', "ctl_created_utc_dt", 'ctl_modified_utc_dts', 'ctl_part_id', 'ctl_is_deleted', 
                'ctl_effective_start_utc_dts', 'ctl_effective_end_utc_dts', 'ctl_hash', 'ctl_inserted_batch_id',
                'ctl_updated_batch_id']

    hash_excl_col_list = hash_excl_col_list + aud_cols

    try:
        logger.info("applying hash")
        hash_cols = sorted([c for c in df_input.columns if c not in hash_excl_col_list])
        logger.info("hash_cols: " + str(hash_cols))
        df_delta = df_input.withColumn("ctl_hash", xxhash64(*hash_cols))

        if len(df_delta.head(1)) > 0:

            logger.info("*********** Check for previously loaded rows in progress ********** ")
            logger.info("Reading target data")
            
            queryCurrent = f"select * from {target_schema}.{target_table} where ctl_is_deleted = 0 "
            logger.info("queryCurrent= " + queryCurrent)
            df_current = spark.sql(queryCurrent)

            #--- Check if records have already been loaded ---------------------------------
            df_match_check = df_delta.join(df_current, match_cols_list).filter(
                df_current['ctl_hash'] == df_delta['ctl_hash']).select(df_delta['*'])# Looking for rows that have been loaded already

            #If we have any records, update the batchIds and remove the records from the source
            if len(df_match_check.head(1)) > 0:
                logger.info("Found at least one row that has already been loaded")
                df_match_check.createOrReplaceTempView("df_match_source")
                update_sql_join = ""
                for i in match_cols_list:
                    update_sql_join = update_sql_join + "Source." + i  + " = Target." + i + " AND "
                update_sql_join = update_sql_join[:-4]
                query = f"""
                     MERGE INTO {target_schema}.{target_table} AS Target USING df_match_source AS Source 
                        ON {update_sql_join}  
                    WHEN MATCHED THEN UPDATE 
                    SET Target.ctl_updated_run_id = '{run_id}', 
                        Target.ctl_modified_utc_dts = '{modified_utc_dts}', 
                        Target.ctl_updated_batch_id = '{batch_id}'
                   
                """
                logger.info("update query = " + query)
                
                spark.sql(query)
                logger.info("update query has run")
                
                #now remove the rows from df_delta
                df_new_delta = df_delta.join(df_match_check, match_cols_list, "leftanti").select(df_delta['*'])
                
                return df_new_delta
            else:
                logger.info("Did not find any data already loaded")
                
                return df_input
                
    except Exception as ex:
        logger.info(str(ex))
        raise

def merge_sat_scd2_all_versions(spark,sqlContext, df_input, batch_id, resp_tbl, ref_batch_list, hash_excl_col_list, logger):
	# Georgi Mirkov : 10/08/2022
    # This function merges data into the target table keeping SCD2 logic and aligning the source to the destination
    # For this function to work:
    # Source must :
    # 	1. Provide all versions for any modified row/key # -- GM: fixed , only delta should be supported also
    # 	2. Calculate properly ctl_effective_start_utc_dts and ctl_effective_end_utc_dts --GM:  fixed -- just start_time will be taken under consideration
    # The function will check for any differences between the source and destination versions and will align them in the destination by 
	# 	1. Deleting any changed versions ( data_fields  / start_time / end_time )
	#	2. Inserting any records that don't exist in the destination by (bussiness_key , ctl_effective_start_utc_dts)
	#
	# In the normal BAU process in 99% of the case it should delete the open version , and reinsert it with closed version + insert the new version of the row
    # 
    # Notes : 
	# 	1. In case the bronze has less history than silver  function will basically delete all the history in silver as well so it needs to be used only for tables where bronze and silver history match (this behavior might be changed in the future to keep the silver history , however at this stage this is not done) 
	#	2. The source query needs to take care of 'fake' versions ( different start_time , but the same data as the previous code )
	#	3. Its good to have unchanging start_times for the versions ( should be the case if everything is ok with the source query) 


    spark.sql("SET spark.databricks.delta.schema.autoMerge.enabled = true")
    run_id = str(int(datetime.utcnow().timestamp() * 1000))
    logger.info("Generated run id for this run (merge_sat_scd2): " + run_id)
    table_id = resp_tbl['table_id']
    logger.info("table_id: " + table_id)
    rows_inserted = '0'
    rows_updated = '0'
    rows_deleted = '0'
    # Inserting start entry to run log table
    kwargs_table = {'ctl_run_id': run_id, 'ctl_batch_id': batch_id, 'table_id': table_id,
                    'min_val': ref_batch_list[0], 'max_val': ref_batch_list[-1],
                    'ctl_table_run_start_time': str(datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
                    'rows_inserted': '0', 'rows_updated': '0', 'ctl_table_run_status': 'STARTED'}
    insert_or_update_table(logger, table_table_run_logs, 'ctl_run_id', run_id, **kwargs_table)
    load_type = resp_tbl['load_type'].split("|")[0]
    logger.info("load_type: " + load_type)
    key_cols = resp_tbl['key_columns'].split(",")
    logger.info("key_cols: " + str(key_cols))
    target_partition_col = str(resp_tbl['target_partition_column']).split("|")
    logger.info("target_partition_col: " + str(target_partition_col))
    target_table = resp_tbl['target_table_name']
    logger.info("target_table_name: " + target_table)
    target_schema = resp_tbl['target_schema_name']
    logger.info("target_schema_name: " + target_schema)
    target_s3_location = resp_tbl['target_s3_location']
    logger.info("target_s3_location: " + target_s3_location)
    incremental_key_col = resp_tbl['source_incr_column'].split("|") 
    logger.info("separator: " + str(incremental_key_col))
    separator = '|'
    logger.info("separator: " + str(separator))
    aud_cols = ['ctl_inserted_run_id', 'ctl_updated_run_id', 'ctl_src_id',
                'ctl_created_utc_dts', 'ctl_modified_utc_dts', 'ctl_part_id', 'ctl_is_deleted', 
                'ctl_effective_start_utc_dts', 'ctl_effective_end_utc_dts', 'ctl_hash', 'ctl_inserted_batch_id',
                'ctl_updated_batch_id']
    hash_excl_col_list = hash_excl_col_list + aud_cols
    try:
        checkpoint_setted_up = False
        if target_table == 'sat_price_01':
            env = 'stg' if target_s3_location.endswith("stg-lsmjik7uyv8") else 'prd'
            logger.info(f'Environemnt is detected as [{env}]')
            checkpoint_bucket = f"dl-etl-work-{env}-lsmjik7uyv8"
            checkpoint_path = f"etl_work/pricing_data/silver/{table_id}"
            checkpoint_dir = f's3://{checkpoint_bucket}/{checkpoint_path}'
            spark.sparkContext.setCheckpointDir(checkpoint_dir)
            logger.info(f"Checkpoint dir is setup at [{checkpoint_dir}]")
            checkpoint_setted_up = True
        ts = datetime.utcnow()
        logger.info("applying hash")
        df_input.printSchema()
        hash_cols = sorted([c for c in df_input.columns if c not in hash_excl_col_list])
        logger.info("hash_cols: " + str(hash_cols))
        df_delta = df_input.withColumn("ctl_hash", xxhash64(*hash_cols))

        if len(df_delta.head(1)) > 0:
            if (load_type.lower() == "hist"):
                logger.info("*********** HISTORICAL SCD2 LOAD IN PROGRESS ********** ")
                logger.info("write to target")
                df_delta_final = add_ctl_columns_on_source_dataframe(logger, df_delta, batch_id, run_id, ts, table_type='sat')
               
                df_delta_final.write.partitionBy(*(target_partition_col)).format("delta").mode("overwrite") \
                    .option("overwriteSchema", "true").option("mergeSchema", "true").save(
                    target_s3_location + "/" + target_schema + "/" + target_table)

                dict_target_schema_defn = dict(df_delta_final.dtypes)
                target_schema_defn = convert_kv_to_string(dict_target_schema_defn, separator)
                new_cols_list = create_hive_metastore(logger, spark, sqlContext, target_schema, target_s3_location,
                                                      target_table, dict_target_schema_defn,
                                                      target_partition_col[0], separator)

                update_glue_catalog(logger, spark, target_s3_location, target_schema, target_table,
                                    target_schema_defn, target_partition_col[0], new_cols_list)
                rows_inserted = \
                    spark.sql(
                        "select count(*) as rows_inserted from {}.{} ".format(target_schema,
                                                                              target_table)).collect()[
                        0].asDict()["rows_inserted"]
                logger.info("rows_inserted: " + str(rows_inserted))
                rows_updated = '0'
                logger.info("rows_updated: " + str(rows_updated))
                kwargs_table_config = {'last_load_key': ref_batch_list[-1], 'load_type': 'INC' }
                insert_or_update_table(logger, table_table_config, 'table_id', table_id, **kwargs_table_config)
                logger.info("*********** HISTORICAL SCD2 LOAD COMPLETED ********** ")
            else:
                logger.info("*********** INCREMENTAL SCD2 LOAD IN PROGRESS ********** ")
                # build different join, partition, select statements
                dec_key_col_list = [ f" {i} desc " for i in incremental_key_col]
                inc_key_col_list = [ f" {i} asc " for i in incremental_key_col]
                join_clause =  " and ". join([ f"t1.{i} = t2.{i}" for i in key_cols ])
                partition_key_col_list =  [ f" t1.{i}  " for i in key_cols]
                t1_key_col_null_list = [f"t1.{i} is null " for i in key_cols]
                t2_key_col_null_list = [f"t2.{i} is null " for i in key_cols]
                filter_expr = ("({0}) in (select {0} from df_delta)").format(*key_cols)
                
                df_delta = add_ctl_columns_on_source_dataframe(logger, df_delta, batch_id, run_id, ts, table_type='sat')
                dict_target_schema_defn = dict(df_delta.dtypes)
                target_schema_defn = convert_kv_to_string(dict_target_schema_defn, separator)
                new_cols_list = create_hive_metastore(logger, spark, sqlContext, target_schema, target_s3_location,
                                                      target_table, dict_target_schema_defn,
                                                      target_partition_col[0], separator)
                logger.info("new_cols_list")
                logger.info(str(new_cols_list))
                logger.info("Reading target data")
                df_delta.createOrReplaceTempView("df_delta")
				#Get all versions for the PK's that needs to be loaded from the destination 
                df_current = spark.read.format("delta").load(
                    target_s3_location + "/" + target_schema + "/" + target_table).where(filter_expr)
                df_current.createOrReplaceTempView("df_current")
                # adding fictional ordering column
                df_current = df_current.withColumn("source_order", lit(0))
                df_delta = df_delta.withColumn("source_order", lit(1))
				# Get all rows from the target that are different than the source version for their PK + Start_Time  ( To be deleted from target)
                df_source_and_dest = df_delta.unionByName(df_current, allowMissingColumns=True)
                # drop the end datetime to be able to rebuild it.
                if 'ctl_effective_end_utc_dts' in df_source_and_dest.columns:
                    df_source_and_dest = df_source_and_dest.drop("ctl_effective_end_utc_dts")
                df_source_and_dest.createOrReplaceTempView('src_dest_vw')
                # remove fake duplicates ( same data with more than one version)
                hash_sql = f"""
                select * from 
                  (
                    select t1.* , 
                    lag(ctl_hash, 1, 0) over ( partition by {', '.join(partition_key_col_list)} order by {', '.join(inc_key_col_list)} , source_order desc )   as prev_hash 
                    from src_dest_vw t1 
                  )
                where prev_hash <> ctl_hash
                """
                logger.info(hash_sql)
                # df_source_and_dest = spark.sql(hash_sql)
                #logger.info(df_source_and_dest.count())
                #df_all = df_source_and_dest.where("ctl_hash<>prev_hash")
                df_all = spark.sql(hash_sql)
                df_all.createOrReplaceTempView("df_all")
                # remove duplicates based on key cols + start_time
                dedup_sql = f"""
                select * , lead(ctl_effective_start_utc_dts, 1, '9999-12-31T00:00:00.000+0000') over ( partition by  {', '.join(partition_key_col_list)} order by {', '.join(inc_key_col_list)} , source_order asc ) as ctl_effective_end_utc_dts
                from (
                  select *, row_number() over ( partition by  {', '.join(partition_key_col_list)} , t1.ctl_effective_start_utc_dts order by {', '.join(dec_key_col_list)}  , source_order  desc) as rn
                  from df_all t1
                  ) t1 where rn = 1
                """
                #logger.info(df_all.count())
                logger.info(dedup_sql)
                #df_all.createOrReplaceTempView("df_all") 
                df_all_clear = spark.sql(dedup_sql)
                df_all_clear = df_all_clear.drop("prev_hash", "rn", "source_order") 
                df_all_clear.createOrReplaceTempView("df_all_clear")
                #logger.info(df_all_clear.count())
                # get the scope for deletion
                df_delete_sql =  f""" 
                  select distinct t1.* 
                  from df_current t1  
                  left join df_all_clear  t2 
                  on {join_clause} 
                  and t2.ctl_effective_start_utc_dts = t1.ctl_effective_start_utc_dts 
                  where  t1.ctl_hash <> t2.ctl_hash  
                  or t2.ctl_effective_end_utc_dts <> t1.ctl_effective_end_utc_dts 
                  or ({' and '.join(t2_key_col_null_list)})
                """
                logger.info(df_delete_sql)
                df_delete = spark.sql(df_delete_sql)
				#Get all rows from the source that are different than the rows in the target ( To be inserted ) 
                # get the scope for insert
                df_insert_sql = f"""
                  select distinct t2.* 
                  from df_current t1  right join df_all_clear t2 
                  on {join_clause}  
                  and t2.ctl_effective_start_utc_dts = t1.ctl_effective_start_utc_dts 
                  where  t1.ctl_hash <> t2.ctl_hash  
                  or t2.ctl_effective_end_utc_dts <> t1.ctl_effective_end_utc_dts 
                  or ({' and '.join(t1_key_col_null_list)})
                """
                logger.info(df_insert_sql)
                df_insert = spark.sql(df_insert_sql)
                df_insert.createOrReplaceTempView("df_insert")
                # add columns to join for the delete and NOT to join for the insert 
                for kc in key_cols:
                    df_insert = df_insert.withColumn(kc + "_mergekey", lit(None))
                    df_delete = df_delete.withColumn(kc + "_mergekey", col(kc))
				#Create a data set to be merged. It can contains duplicates in case of updated as they are handled as Insert + Delete. 
				#
                df_source = df_delete.unionByName(df_insert, allowMissingColumns=True) 
                if checkpoint_setted_up:
                    df_source = df_source.checkpoint()
                    logger.info("Dataframe is checkpointed")
                else:
                    df_source.cache() 
                    logger.info("Dataframe is cached")
                #df_source_count = df_source.count()
                #logger.info("df_source_count: " + str(df_source_count))
                df_source.createOrReplaceTempView("df_source")
                # format insert and update lists
                insert_cols = ''
                insert_vals = ''
                for ic in df_source.columns:
                    if not ic.endswith('_mergekey'):
                        insert_cols = insert_cols + ic + ','
                        insert_vals = insert_vals + 'Source.' + ic + ','
                insert_cols = insert_cols[:-1]
                insert_vals = insert_vals[:-1]
                update_sql_join = ""
                for i in key_cols:
                    update_sql_join = update_sql_join + "Source." + i + "_mergekey" + " = Target." + i + " AND "
                update_sql_join = update_sql_join[:-4]
				# All joined rows will be deleted and not joined will be inserted 
                merge_stmt = f"""
                            MERGE INTO {target_schema}.{target_table} AS Target USING df_source AS Source 
                            ON {update_sql_join}  and  Source.ctl_effective_start_utc_dts =  Target.ctl_effective_start_utc_dts
                            WHEN MATCHED 
                            THEN DELETE
                            WHEN NOT MATCHED THEN
                            INSERT({insert_cols})
                            VALUES({insert_vals})
                            """                
                logger.info(merge_stmt)
                merge_data(logger, spark, merge_stmt)

				#Should be considered that the updates are handled as delete + insert , so the rows bellow migth be a bit misleading in terms of what is modified and what is new data.
                rows_info = \
                    spark.sql(f"DESCRIBE HISTORY {target_schema}.{target_table}").filter(
                        col('operation').isin(['WRITE', 'MERGE'])).orderBy(col("version").desc()).limit(
                            1).select(
                                element_at(col('operationMetrics'), 'numTargetRowsUpdated').alias("rows_updated"),
                                element_at(col('operationMetrics'), 'numTargetRowsDeleted').alias("rows_deleted"),
                                element_at(col('operationMetrics'), 'numTargetRowsInserted').alias("rows_inserted")
                    ).collect()[0]

                rows_updated = str(rows_info["rows_updated"])
                logger.info("rows_updated: " + str(rows_updated))
                rows_deleted = str(rows_info["rows_deleted"])
                logger.info("rows_deleted: " + str(rows_deleted))
                rows_inserted = str(rows_info["rows_inserted"])
                logger.info("rows_inserted: " + str(rows_inserted))

                logger.info("Calling update_glue_catalog")
                logger.info(str(target_partition_col))
                update_glue_catalog(logger, spark, target_s3_location, target_schema, target_table, target_schema_defn,
                                    target_partition_col[0], new_cols_list)

                logger.info("updating last load key to config table")
                
                kwargs_table_config = {'last_load_key': ref_batch_list[-1]}
                insert_or_update_table(logger, table_table_config, 'table_id', table_id, **kwargs_table_config)
                
                if checkpoint_setted_up:
                    s3 = boto3.resource('s3')
                    bucket = s3.Bucket(checkpoint_bucket)
                    bucket.objects.filter(Prefix=checkpoint_path).delete()
                    logger.info("Checkpoint directory is cleared")
                logger.info("*********** INCREMENTAL SCD2 LOAD COMPLETED ********** ")
        else:
            logger.info("No records to be merged from the source")

    except Exception as ex:
        logger.error(str(ex))
        logger.error(str(sys.exc_info()))
        ex_type, ex_value, ex_traceback = sys.exc_info()
        kwargs_table = {'ctl_table_run_status': 'FAILED', 'ctl_err_code': str(ex_type.__name__),
                        'ctl_err_desc': str(ex_value),
                        'ctl_table_run_end_time': str(datetime.now().strftime("%Y-%m-%d %H:%M:%S"))}
        insert_or_update_table(logger, table_table_run_logs, 'ctl_run_id', run_id, **kwargs_table)
        raise
    else:
        kwargs_table = {'rows_inserted': rows_inserted, 'rows_updated': rows_updated,
                        'ctl_table_run_status': 'SUCCESS',
                        'ctl_table_run_end_time': str(datetime.now().strftime("%Y-%m-%d %H:%M:%S"))}
        insert_or_update_table(logger, table_table_run_logs, 'ctl_run_id', run_id, **kwargs_table)
        return {'rows_inserted': int(rows_inserted), 'rows_updated': int(rows_updated),
                'rows_deleted': int(rows_deleted)}
