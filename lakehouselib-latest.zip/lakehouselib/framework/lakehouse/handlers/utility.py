from lakehouselib.services.aws.s3.utility import *
from lakehouselib.framework.lakehouse.dynamodb.utility import *
from lakehouselib.framework.lakehouse.data.utility import *

def constructInputBatches(inputArgs):
    """This method constructs a dictionary based on the Job Arguments passed to it from the spark-submit operation.
    Its purpose is to generate a dictionary of dependencies, and associated details which make it easier to use in
    subsequent processing

    Args:
        inputArgs (Json): Contains a number of attributes as received by the Spark Submit jobArgs parameter.
        Example shown below:
        {
          'region_name': 'ap-southeast-2' ,
          'pipeline_name': 'silver_customer_static',
          'dependencies': 'bronze_activity_feeds_pii.customers_topic_customer_01,bronze_activity_feeds.customers_topic_customer_flag_01',
          'bronze_activity_feeds_pii.customers_topic_customer_01.batchId': '1634554051',
          'bronze_activity_feeds_pii.customers_topic_customer_01.delta_table_path': 's3://dl-bronze-activity-feeds-pii-stg-lsmjik7uyv8/bronze_activity_feeds_pii/customers_topic_customer/',
          'bronze_activity_feeds_pii.customers_topic_customer_01.ctl_headerdate': '2021-08-11,2021-08-16,2021-08-17,2021-08-18,2021-08-19',
          'bronze_activity_feeds.customers_topic_customer_flag_01.batchId' : '1634554051,1634554052,1634554054',
          'bronze_activity_feeds.customers_topic_customer_flag_01.delta_table_path': 's3://dl-bronze-activity-feeds-stg-lsmjik7uyv8/bronze_activity_feeds/customers_topic_customer_flag/',
          'bronze_activity_feeds.customers_topic_customer_flag_01.p_date': '2021-08-11,2021-08-16,2021-08-17,2021-08-18,2021-08-19',
          'bronze_activity_feeds.customers_topic_customer_group_01.batchId' : '1634554051,1634554052,1634554054',
          'bronze_activity_feeds.customers_topic_customer_group_01.delta_table_path': 's3://dl-bronze-activity-feeds-stg-lsmjik7uyv8/bronze_activity_feeds/customers_topic_customer_group/',
          'bronze_activity_feeds.customers_topic_customer_group_01.p_date': '2021-08-11,2021-08-16,2021-08-17,2021-08-18,2021-08-19'
        }

    Returns:
        Dict: Dictionary keyed on dependency name (dep_name in ed_dep_config).
        Each payload of a dictionary entry will contain a list of batches
        {
          "bronze_activity_feeds_pii.customers_topic_customer_01": {
            "batchId": ["1634554051"],
            "delta_table_path": "s3://dl-bronze-activity-feeds-pii-stg-lsmjik7uyv8/bronze_activity_feeds_pii/customers_topic_customer/",
            "ctl_headerdate": ["2021-08-11","2021-08-16","2021-08-17","2021-08-18","2021-08-19"]
          },
          "bronze_activity_feeds.customers_topic_customer_flag_01": {
            "batchId": ["1634554051","1634554052","1634554054"],
            "delta_table_path": "s3://dl-bronze-activity-feeds-stg-lsmjik7uyv8/bronze_activity_feeds/customers_topic_customer_flag/",
            "p_date": ["2021-08-11","2021-08-16","2021-08-17","2021-08-18","2021-08-19"]
          },
          "bronze_activity_feeds.customers_topic_customer_group_01": {
            "batchId": ["1634554051","1634554052","1634554054"],
            "delta_table_path": "s3://dl-bronze-activity-feeds-stg-lsmjik7uyv8/bronze_activity_feeds/customers_topic_customer_group/",
            "p_date": ["2021-08-11","2021-08-16","2021-08-17","2021-08-18","2021-08-19"]
          }
        }
    """
    pipelineDeltaDependency = dict()
    dependencies = [argsVal.split(',') for argsKey, argsVal in inputArgs.items() if argsKey == 'dependencies']

    for dependency in dependencies[0]:
        pipelineDeltaDependency[dependency] = {
            argsKey.replace(dependency + '.', ''): (argsVal.split(',') if 'delta_table_path' not in argsKey else argsVal)
            for argsKey, argsVal in inputArgs.items() if dependency in argsKey}

    return pipelineDeltaDependency


def convert_list_to_str(list_val):
  """This function checks if the parameter is a list or a string. 
  This converts the input to a tuple-kind of string to be used as part of the where clause

  Args:
      list_val ([string or list]): 

  Returns:
    

  Sample:
      source_partion_list = convert_list_to_str(["2021-08-24", "2021-08-25"])
      source_batch_id = convert_list_to_str('1635122742516)

  Output:
      source_partion_list ('2021-08-24', '2021-08-25')
      source_batch_id ('1635122742516')
  """

  if type(list_val) is list:
      return str(list_val).replace('[', '(').replace(']', ')') 
  elif type(list_val) is str:
      return str([list_val]).replace('[', '(').replace(']', ')')


def get_pipeline_dependency_attribute(logger, pipeline_log_run_rec, dep_name, attribute):
  """[summary]

  Args:
      pipeline_log_run_rec ([type]): [description]
      dep_name ([type]): [description]
      attribute ([type]): [description]

  Returns:
      [type]: [description]
  """

  try:
    pipeline_dependencies = pipeline_log_run_rec.get("pipeline_dependencies")
    for dependency in pipeline_dependencies:
        batch_id_list = []
        partition_column_val_dict = {}
        for key,val in dependency.items():
            if key == 'name' and val == dep_name:
                eot_batch = dependency["eot_batch"]
                for batch in eot_batch:
                    if attribute == 'batch_id':
                        batch_id_list.append(batch[attribute])
                    elif attribute == 'partition_ids':
                        for partition_key, partition_val in batch[attribute].items():
                            if partition_key in partition_column_val_dict:
                                # just add to the existing key
                                current_partition_val = partition_column_val_dict.get(partition_key)
                                current_partition_val.extend(partition_val)
                                # ensure we update with the unique values
                                partition_column_val_dict[partition_key] = list(set(current_partition_val))
                            else:
                                partition_column_val_dict[partition_key] = partition_val
                        
    if attribute == 'batch_id':
        # ensure we return unique list
        return list(set(batch_id_list))
    else:
        return partition_column_val_dict
  
  except Exception as exc:
        logger.error(exc)
        raise exc



def get_pipeline_dependency_batches_partitions(logger, job_args):
  """The function returns dictionaries of data delivery names, batches, partition values, and delta table paths

  Args:
      job_args (dictionary): This is passed from EMR as input param

  Returns:
      dependency_data_delivery_names
      dependency_batches
      dependency_delta_table_paths
      dependency_partitions

  Sample job_args:

    job_args = {'record_s3_path':'s3://datalake-l2-ed-edl2bucket-mwaa-stg-v202-twycaj6ki1az/silver_customer_static/silver_customer_static-2022-03-15T06:21:44.268.json', 
            'target_table_name':'sat_customer_static_01', 
            'pipeline_run_id':'silver_customer_static-2022-03-15T06:21:44.268', 
            'target_schema_name':'silver', 
            'region_name':'ap-southeast-2', 
            'pipeline_name':'silver_customer_static'}       

    job_args = {
          'pipeline_log_run_id': '',
          'region_name': 'ap-southeast-2' ,
          'pipeline_name': 'gold_financial_projection_detail',
          'table_id' : 'gold.financial_projection_detail',
          'dependencies': 'bronze_cdw.dbo_budgetforecastweighting_01',
          'bronze_cdw.dbo_budgetforecastweighting_01.batchId': '2106475224',
          'bronze_cdw.dbo_budgetforecastweighting_01.delta_table_path':'s3://dl-bronze-cdw-prd-lsmjik7uyv8/bronze_cdw/dbo_budgetforecastweighting', 
          'bronze_cdw.dbo_budgetforecastweighting_01.ctl_headerdate':''
        }

  """
  pipeline_name = job_args.get('pipeline_name')
  pipeline_log_run_id = job_args.get('pipeline_log_run_id')
  record_s3_path = job_args.get('record_s3_path')

  # let's initialise it first
  pipeline_log_run_rec = None

  try:
    # get pipeline log record
    if bool(pipeline_name) and bool(pipeline_log_run_id):
        response_table_pipeline_log_runs = table_pipeline_log_runs.query(
            KeyConditionExpression=Key('pipeline_name').eq(pipeline_name) & Key('pipeline_run_id').eq(pipeline_log_run_id)
            )
        # if there was a pipeline_run_id passed, for sure there'll be data
        pipeline_log_run_rec = response_table_pipeline_log_runs['Items'][0]

    dependency_batches = dict()
    dependency_delta_table_paths = dict()
    dependency_partitions = dict()
    dependency_data_delivery_names = dict()
    
    # read from job_args & pipeline log run
    if not bool(record_s3_path):
        # get dependencies from job_args
        dependencies = [args_val.split(',') for args_key, args_val in job_args.items() if args_key == 'dependencies'][0]
        
        # get batches and partitions for each dependency
        for dependency in dependencies:
            # query from ed_dep_config to get the data_delivery name
            response_dep_config = table_ed_dep_config.query(KeyConditionExpression=Key('dep_name').eq(dependency))
            data_delivery_name = response_dep_config["Items"][0]["data_delivery_name"]
            dependency_data_delivery_names[dependency] = data_delivery_name
            # construct the dicts
            for args_key, args_val in job_args.items():
                if dependency in args_key:
                    if 'batchId' in args_key:
                        if bool(args_val):
                            dependency_batches[data_delivery_name] = list(args_val.split(','))
                        else:
                            # get batches from pipeline log run table
                            if bool(pipeline_log_run_rec):
                                batch_list = get_pipeline_dependency_attribute(logger, pipeline_log_run_rec, dependency, 'batch_id')
                                dependency_batches[data_delivery_name] = batch_list#.sort()
                    elif 'delta_table_path' in args_key:
                        if bool(args_val):
                            dependency_delta_table_paths[data_delivery_name] = args_val
                    else:
                        if bool(args_val):
                            dependency_partitions[data_delivery_name] = {args_key.replace(dependency+'.', ''): list(args_val.split(','))} 
                        else:
                            # get partitions from pipeline_log_run table
                            if bool(pipeline_log_run_rec):
                                partition_dict = get_pipeline_dependency_attribute(logger, pipeline_log_run_rec, dependency, 'partition_ids')
                                dependency_partitions[data_delivery_name] = partition_dict

    # read from S3
    else:
        s3 = boto3.client('s3')
        bucket = (record_s3_path[5:] if record_s3_path.startswith('s3://') else record_s3_path).split('/')[0]
        file_key = (record_s3_path[5:] if record_s3_path.startswith('s3://') else record_s3_path)[len(bucket)+1:]
        data = s3.get_object(Bucket=bucket, Key=file_key)
        contents = json.loads(data['Body'].read().decode('utf-8'))
        
        # list of dependencies
        list_pipeline_dependencies = contents.get('pipeline_dependencies')

        for dependency in list_pipeline_dependencies:
            dep_name = dependency.get('name')
        
            # query from ed_dep_config to get the data_delivery name
            response_dep_config = table_ed_dep_config.query(KeyConditionExpression=Key('dep_name').eq(dep_name))
            data_delivery_name = response_dep_config["Items"][0]["data_delivery_name"]
            dependency_data_delivery_names[dep_name] = data_delivery_name
            dependency_batches[data_delivery_name] = []
            dependency_delta_table_paths[data_delivery_name] = []
        
            list_delta_path= []
            list_eot_batch = dependency.get('eot_batch')
            partition_column_val_dict = {}
            for eot_batch in list_eot_batch:
                list_delta_path.append(eot_batch['delta_table_path'])
                dependency_batches[data_delivery_name].append(eot_batch['batch_id'])

                # get the partition ids
                list_partition_ids = eot_batch['partition_ids']
                for partition_key, partition_val in list_partition_ids.items():
                    if partition_key in partition_column_val_dict:
                        # just add to the existing key
                        current_partition_val = partition_column_val_dict.get(partition_key)
                        current_partition_val.extend(partition_val)
                        # ensure we update with the unique values
                        partition_column_val_dict[partition_key] = list(set(current_partition_val))
                    else:
                        partition_column_val_dict[partition_key] = partition_val

            dependency_partitions[data_delivery_name] = partition_column_val_dict
            dependency_delta_table_paths[data_delivery_name] = list(set(list_delta_path))

    return dependency_data_delivery_names, dependency_batches, dependency_delta_table_paths, dependency_partitions
  
  except Exception as exc:
        logger.error(exc)
        raise exc


def setup_lakehouse_run(logger, process_run_id, process_run_timestamp, process_batch_name=None,process_target_table_name=None, process_target_schema_name=None, process_table_id=None, pipeline_run_id=None):
    """
    The function queries the lakehouse_table_config based on batch_id, table_name, target_schema_name. This also inserts a record on lakehouse_batch_run_logs.

    Args:
        logger ([type]): [description]
        process_run_id ([type]): [description]
        process_run_timestamp ([type]): [description]
        process_batch_name ([type], optional): [description]. Defaults to None.
        process_target_table_name ([type], optional): [description]. Defaults to None.
        process_target_schema_name ([type], optional): [description]. Defaults to None.
        process_table_id ([type], optional): [description]. Defaults to None.
        pipeline_run_id ([type], optional): [description]. Defaults to None.

    Returns:
        [type]: [description]
    """
    
    # Query table config
    tables_to_process = query_table_config(logger, table_table_config, batch_name=process_batch_name, 
                                           target_table_name=process_target_table_name, target_schema_name=process_target_schema_name,
                                          table_id = process_table_id)
    if len(tables_to_process) >= 1 and not bool(process_batch_name):
        process_batch_name = tables_to_process[0]["batch_name"]

    # Log start in batch run logs table
    kwargs_batch = {'ctl_batch_id': process_run_id, 'ctl_batch_run_status': 'STARTED',
                    'batch_name': process_batch_name, 'ctl_batch_run_start_time': process_run_timestamp.strftime('%Y-%m-%d %H:%M:%S'), 'pipeline_run_id': pipeline_run_id}
    insert_or_update_table(logger, table_batch_run_logs,'ctl_batch_id', process_run_id, **kwargs_batch)

    return tables_to_process


def ey_exist(dict, key):
    '''
    :param dict: kv dict
    :param key: key to look for
    :return:
    '''
    try:
        value = dict[key]
        return True
    except KeyError:
        return False
