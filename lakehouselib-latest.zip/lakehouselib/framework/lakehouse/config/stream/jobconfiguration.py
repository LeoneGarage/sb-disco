import os
import traceback

from botocore.config import Config
from lakehouselib.system.exception.handler import LakehouseError
from lakehouselib.services.aws.sessionmanager.utility import create_aws_session
from lakehouselib.framework.lakehouse.dynamodb.getters import get_ddb_table_config_items, \
    get_ddb_metadata_config_items, get_ddb_exc_config_items
from lakehouselib.services.aws.ssm.utility import get_ssm_config_value, get_secret
from lakehouselib.services.jobarguements.arguments import Arguments


class JobVariables:
    """A class for the setup of Kafka Related variables needed for streaming jobs"""

    def __init__(self, logger, job_name, **job_args):
        """Initialisation method for Kafka Related variables needed

        Parameters
        -----------
        logger : util.system.logging class Log4j
            The referenced log4j object obtained from `main.py`

        job_name : str
            The name of the job, obtained from the --job argument

        job_args : dict
            Arguments passes through as obtained from the --job-args argument

        Returns
        -------
        None : None
            None
        """
        self.logger = logger
        self.job_name = job_name
        self.job_args = job_args
        self.boto_session = None

        self.kafka_topic = None
        self.region_name = None
        self.profile_name = None

        # Args specific for RTI 
        self.glue_role = None
        self.schema_arn = None

        self.stream_source = None

        self.run_mode = job_args.get('run_mode', 'cluster')

        self.ssm_key_base = None

        self.kafka_broker_endpoint = None
        self.truststore_password = None
        self.keystore_password = None

        self.kafka_ssl_truststore_location = None
        self.kafka_ssl_keystore_location = None

        self.topic = None

        self.outputpathlanding = None
        self.outputpathbronze = None
        self.checkpointpath = None
        self.kafka_broker_endpoint = None
        self.processingtime = None
        self.maxoffsetpertrigger = 10000
        self.failondataloss = None
        self.startingOffsets = None

        self.job_timestamp = None

        self.ddb_table_config = None
        self.ddb_metadata_config = None
        self.ddb_exc_dicts = dict()

        self.schemaregistryconf = None


    def get_values_from_args(self):
        """A method to setup the variables based on submit arguments

        Returns
        -------
        None
        """
        self.kafka_topic = Arguments.get_job_args_value("kafka_topic", self.logger, **self.job_args)
        self.region_name = Arguments.get_job_args_value("region_name", self.logger, **self.job_args)
        if self.run_mode == 'local':
            self.profile_name = Arguments.get_job_args_value("profile_name", self.logger, **self.job_args)

    def get_values_from_aws_secretsmanager(self):
        """A method to setup values from AWS Secrets Manager Service

        Returns
        -------
        None : None
            None
        """
        try:
            aws_client_ssm = self.boto_session.client(service_name='ssm')
            self.secret_id = get_ssm_config_value(logger=self.logger, client=aws_client_ssm, param="{}/{}/secret_id".format(self.ssm_key_base, self.kafka_topic))
            aws_client_secretsmanager = self.boto_session.client(service_name='secretsmanager')
            secret = get_secret(logger=self.logger, client=aws_client_secretsmanager, secret_id="{}".format(self.secret_id))
            self.truststore_password = secret
            self.keystore_password = secret
        except Exception as exc:
            err_msg = "Error accessing secretsmanager with profile `{}` on `{}`".format(self.profile_name, self.region_name)
            raise LakehouseError(trace_err=traceback.format_exc(), err_nbr='2.4', err_msg=err_msg, job_vars=self) from exc

    def get_values_from_aws_ssm_parameter_store(self):
        """A method to setup values from AWS Secrets Manager Service Parameter Store

        Returns
        -------
        None : None
            None
        """
        try:
            aws_client_ssm = self.boto_session.client(service_name='ssm')
            self.kafka_broker_endpoint = get_ssm_config_value(logger=self.logger, client=aws_client_ssm, param="{}/{}/kafka_brokers".format(self.ssm_key_base, self.kafka_topic))
            self.topic = get_ssm_config_value(logger=self.logger, client=aws_client_ssm, param="{}/{}/topic".format(self.ssm_key_base, self.kafka_topic))
            ## Read from glue schema Specific params 
            if self.stream_source in ('rti-feeds','nser-audit-event','cardinal_chargeback_feed', 'customer-kyc','martech'):
                self.glue_role = get_ssm_config_value(logger=self.logger, client=aws_client_ssm, param="{}/{}/glue_role".format(self.ssm_key_base, self.kafka_topic))
                self.schema_arn = get_ssm_config_value(logger=self.logger, client=aws_client_ssm, param="{}/{}/schema_arn".format(self.ssm_key_base, self.kafka_topic))
            #####

            ## DE Confluent Schema Reg specific params 
            if self.stream_source in('distribution-engine', 'bwm'):
                self.schemaregistryconf = get_ssm_config_value(logger=self.logger, client=aws_client_ssm, param="{}/{}/schemaregistryconf".format(self.ssm_key_base, self.kafka_topic))
            #####

            self.kafka_ssl_truststore_location = get_ssm_config_value(logger=self.logger, client=aws_client_ssm,param="{}/{}/kafka_ssl_truststore_location".format(self.ssm_key_base, self.kafka_topic))
            self.kafka_ssl_keystore_location = get_ssm_config_value(logger=self.logger, client=aws_client_ssm, param="{}/{}/kafka_ssl_keystore_location".format(self.ssm_key_base, self.kafka_topic))
            if self.topic == self.kafka_topic:
                self.startingOffsets = get_ssm_config_value(logger=self.logger, client=aws_client_ssm, param="{}/{}/offset".format(self.ssm_key_base, self.kafka_topic))
                self.outputpathlanding = get_ssm_config_value(logger=self.logger, client=aws_client_ssm, param="{}/{}/outputpathlanding".format(self.ssm_key_base, self.kafka_topic))
                self.outputpathbronze = get_ssm_config_value(logger=self.logger, client=aws_client_ssm,param="{}/{}/outputpathbronze".format(self.ssm_key_base,self.kafka_topic))
                self.checkpointpath = get_ssm_config_value(logger=self.logger, client=aws_client_ssm, param="{}/{}/checkpointpath".format(self.ssm_key_base, self.kafka_topic))
                self.processingtime = get_ssm_config_value(logger=self.logger, client=aws_client_ssm, param="{}/{}/processingtime".format(self.ssm_key_base, self.kafka_topic))
                self.maxoffsetpertrigger = get_ssm_config_value(logger=self.logger, client=aws_client_ssm,
                                                                    param="{}/{}/offsetpertrigger".format(
                                                                        self.ssm_key_base, self.kafka_topic))
                self.failondataloss = get_ssm_config_value(logger=self.logger, client=aws_client_ssm,
                                                                param="{}/{}/failondataloss".format(self.ssm_key_base,
                                                                                                    self.kafka_topic))
            else:
                error_msg = "Kafka Topic configuration in ssm inconsistent for topic `{}`".format(self.kafka_topic)
                self.logger.error(error_msg)
                raise Exception(error_msg)
        except Exception as exc:
            err_msg = "Error accessing ssm with profile `{}` on `{}`".format(self.profile_name, self.region_name)
            raise LakehouseError(trace_err=traceback.format_exc(), err_nbr='2.5', err_msg=err_msg, job_vars=self) from exc

    def get_values_from_aws_ddb(self):
        """A method that setup two key meta configurations from ddb, table_config and metadata_config

        Returns
        -------
        None : None
            None
        """
        try:
            ddb_config = Config(retries={'max_attempts': 10})
            kwargs = {
                'region_name': self.region_name,
                'config': ddb_config,
            }
            if self.run_mode == 'local':
                kwargs['endpoint_url'] = 'http://localhost:8000'
            ddb_client = self.boto_session.resource('dynamodb', **kwargs)
            self.ddb_table_config = get_ddb_table_config_items(self, ddb_client, 'lakehouse_table_config')
            self.ddb_metadata_config = get_ddb_metadata_config_items(self, ddb_client, 'lakehouse_metadata_config')
            self.ddb_exc_dicts = get_ddb_exc_config_items(self, ddb_client, 'lakehouse_exception_config')
        except Exception as exc:
            err_msg = "Error accessing ssm with profile `{}` on `{}`".format(self.profile_name, self.region_name)
            raise LakehouseError(trace_err=traceback.format_exc(), err_nbr='2.6', err_msg=err_msg, job_vars=self) from exc

    def local_properties_overrides(self):
        """A method that reads `local.properties` file to override configured values

        Returns
        -------
        None : None
            None
        """
        try:
            if self.run_mode == 'local':
                if os.path.isfile('../local.properties'):
                    properties_file = '../local.properties'
                else:
                    properties_file = './local.properties'

                # pylint:disable=C0415
                import configparser
                config = configparser.RawConfigParser()
                config.read(properties_file)

                self.topic = self.kafka_topic

                self.kafka_broker_endpoint = config.get('localsteaming', 'af.kafka.bootstrap.servers')
                self.truststore_password = config.get('localsteaming', 'af.kafka.ssl.truststore.password')
                self.keystore_password = config.get('localsteaming', 'af.kafka.ssl.keystore.password')
                self.maxoffsetpertrigger = config.get('localsteaming', 'af.maxoffsetpertrigger')
                self.processingtime = config.get('localsteaming', 'af.processingtime')
                self.failondataloss = config.get('localsteaming', 'af.failondataloss')

                self.kafka_ssl_truststore_location = config.get('localsteaming', 'af.kafka.ssl.truststore.location')
                self.kafka_ssl_keystore_location = config.get('localsteaming', 'af.kafka.ssl.keystore.location')

                self.startingOffsets = config.get('localsteaming', 'af.startingoffsets')
                self.checkpointpath = config.get('localsteaming', 'af.checkpointlocation')
                self.checkpointpath = self.checkpointpath.format(self.job_name)
                self.outputpathlanding = config.get('localsteaming', 'af.outputpathlanding')
                self.outputpathlanding = self.outputpathlanding.format(self.job_name)
                self.outputpathbronze = config.get('localsteaming', 'af.outputpathbronze')
                self.outputpathbronze = self.outputpathbronze.format(self.job_name)
        except Exception as exc:
            err_msg = "Error accessing and parsing `local.properties` file."
            raise LakehouseError(trace_err=traceback.format_exc(), err_nbr='2.7', err_msg=err_msg, job_vars=self) from exc

    def setup(self, stream_source):
        """The main method that configures all the required job variables

        Returns
        -------
        None : None
            None
        """
        # TODO: refactor boto session and enable it to be self-refreshing
        #  - https://pritul95.github.io/blogs/boto3/2020/08/01/refreshable-boto3-session/
        try:
            self.stream_source = stream_source
            self.ssm_key_base = f'/adp/source/stream/{stream_source}'
            self.get_values_from_args()
            if self.run_mode == 'local':
                self.boto_session = create_aws_session(profile_name=self.profile_name, region_name=self.region_name)
                self.get_values_from_aws_ddb()
                self.local_properties_overrides()
            else:
                self.boto_session = create_aws_session(region_name=self.region_name)
                self.get_values_from_aws_ddb()
                self.get_values_from_aws_secretsmanager()
                self.get_values_from_aws_ssm_parameter_store()
        except Exception as exc:
            err_msg = "Error running `setup` for job `{}`".format(self.job_name)
            raise LakehouseError(trace_err=traceback.format_exc(), err_nbr='3.13', err_msg=err_msg, job_vars=self) from exc
