from datetime import datetime, timedelta
from pyspark.sql.functions import when
from pyspark.sql.types import *
from lakehouselib.data.transform.dataframeutils.utility import *
from delta.tables import *


def create_hive_metastore(logger, spark, sqlContext, target_schema, target_s3_location, target_table, dict_target_schema_defn, target_partition_column=None, separator='|', file_retention=None, log_retention=None, generate_symlink=False):
    """
    Function to define the delta tables in the hive metastore

    params:
        target_schema
        target_s3_location
        target_table
        dict_target_schema_defn - in dictionary format
        target_partition_column
    
    return:
        new_cols_list list - list of new columns added to the table
    """
    
    try:
        target_layers = ['bronze', 'silver', 'gold']
        for layer in target_layers:
            if str(target_schema).startswith(layer):
                target_layer = layer
                break

        file_retention_days = {'bronze': 50, 'silver': 50, 'gold': 20}
        log_retention_days = {'bronze': 50, 'silver': 50, 'gold': 20}

        if not bool(file_retention):
            file_retention = file_retention_days[target_layer]
        if not bool(log_retention):
            log_retention = log_retention_days[target_layer]

        # Create Database -----------------------------------------------------------------
        # create_db_stmt = f"""CREATE DATABASE IF NOT EXISTS {target_schema} LOCATION '{target_s3_location}/'"""
        # logger.info(create_db_stmt)
        # spark.sql(create_db_stmt)

        # Check if table already exists
        table_names_in_db = sqlContext.tableNames(target_schema)
        table_exists = target_table in table_names_in_db

        new_cols_list = []
        if table_exists:
            # check if the target table schema is the same as the current table schema
            # target is the actual table in S3
            df_target = spark.sql(f'select * from {target_schema}.{target_table} limit 1')
            dtypes_target = dict(df_target.dtypes)
            # source is the new dataframe to be entered into S3
            dtypes_source = dict_target_schema_defn
            
            # Do this only if the current table schema is NOT the same as your desired table schema
            if dtypes_source != dtypes_target:
                for k, v in dtypes_source.items():
                    if dtypes_target.get(k) is None:
                        alter_stmt = f'ALTER TABLE {target_schema}.{target_table} ADD COLUMN {k} {v} '
                        logger.info (alter_stmt)
                        spark.sql(alter_stmt)
                        new_cols_list.append(f'{k} {v}') 
            
        else:

            if generate_symlink:
                # Generate symlink ---------------------------------------------
                delta_table = DeltaTable.forPath(spark, f"{target_s3_location}/{target_schema}/{target_table}")
                delta_table.generate("symlink_format_manifest")

            # Create Hive table ---------------------------------------------------------------
            partition_clause = f'PARTITIONED BY ({target_partition_column})' if bool(target_partition_column) else ''
            target_schema_defn = convert_kv_to_string(dict_target_schema_defn, separator).replace(separator, ',')
            create_hive_table_stmt = f"""
                CREATE TABLE IF NOT EXISTS {target_schema}.{target_table}
                ({target_schema_defn})
                USING DELTA
                {partition_clause}
                LOCATION '{target_s3_location}/{target_schema}/{target_table}/'
                """
            logger.info(create_hive_table_stmt)
            spark.sql(create_hive_table_stmt)

            alter_table_stmt = f"""ALTER TABLE {target_schema}.{target_table}
                SET TBLPROPERTIES ('delta.deletedFileRetentionDuration'='interval {file_retention} days', 'delta.logRetentionDuration'='interval {log_retention} days', 'delta.compatibility.symlinkFormatManifest.enabled'='true')
                """
            logger.info(alter_table_stmt)
            spark.sql(alter_table_stmt)

        return new_cols_list
        
    except Exception as exc:
        logger.error(exc)
        raise exc

def update_glue_catalog(logger,spark, target_s3_location, target_schema, target_table,target_schema_defn, target_partition_column=None, new_cols_list=None, run_msck_repair=False):
    """
    Function to update the Glue Catalog for the table queryable from Athena. 
    
    params:
        target_s3_location
        target_schema
        target_table
        target_schema_defn
        target_partition_column => comma-separated string of columns or blank (if no partition is required on the destination table)
        new_cols_list
    
    """
    
    try:
        partitioned_by_list = []

        # Create database ---------------------------------------------
        # create_db_query = f"CREATE DATABASE IF NOT EXISTS s_{target_schema} COMMENT 'Lakehouse {target_schema} Database' LOCATION '{target_s3_location}/'"
        # logger.info(create_db_query)
        # spark.sql(create_db_query)
        
        # Check if table already exists
        # table_names_in_db = sqlContext.tableNames('s_' + target_schema)
        # table_exists = target_table in table_names_in_db

        # if table_exists:
        # Alter the table if there's a new col
        for col in new_cols_list:
            alter_stmt = f'ALTER TABLE s_{target_schema}.{target_table} ADD COLUMNS ({col})'
            logger.info(alter_stmt)
            spark.sql(alter_stmt)

        # Create external table ---------------------------------------
        # NOTE: In Athena, int is used for DDL (and not integer)
        if not bool(new_cols_list):
            target_schema_defn_list = target_schema_defn.split('|')
            target_schema_defn_athena_list = [] 
            # target_partition_column is comma-separated and may have spaces in between (depending on how the user entered it in DynamoDB). Remove space first and split
            target_partition_column_list = target_partition_column.replace(' ','').split(',') if bool(target_partition_column) else []
            
            for col in target_schema_defn_list:
                if col.strip().split(' ')[0] not in target_partition_column_list:
                    target_schema_defn_athena_list.append(f"`{col.strip().split(' ')[0]}` {col.strip().split(' ')[1].replace('long', 'bigint').replace('integer', 'int')}")
                elif col.strip().split(' ')[0] in target_partition_column_list:
                    partitioned_by_list.append(f"`{col.strip().split(' ')[0]}` {col.strip().split(' ')[1].replace('long', 'bigint').replace('integer', 'int')}")
                    
            partition_stmt = f"PARTITIONED BY ({','.join(partitioned_by_list)})" if bool(partitioned_by_list) else ""
            create_table_query = f"""CREATE EXTERNAL TABLE IF NOT EXISTS s_{target_schema}.{target_table} ({",".join(target_schema_defn_athena_list)}) 
                {partition_stmt} 
                ROW FORMAT SERDE 'org.apache.hadoop.hive.ql.io.parquet.serde.ParquetHiveSerDe'
                STORED AS INPUTFORMAT 'org.apache.hadoop.hive.ql.io.SymlinkTextInputFormat'
                OUTPUTFORMAT 'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat'
                LOCATION '{target_s3_location}/{target_schema}/{target_table}/_symlink_format_manifest/'
                """
            logger.info(create_table_query)
            spark.sql(create_table_query)

        if bool(partitioned_by_list):
            update_partitions_query = f'MSCK REPAIR TABLE s_{target_schema}.{target_table}'
            logger.info(update_partitions_query)
            spark.sql(update_partitions_query)

        # partition_set = set()
        # if not run_msck_repair:
        #     try:
        #         if target_partition_column:
        #             spark.sql(f'show partitions {target_schema}.{target_table}').createOrReplaceTempView("hive")
        #             spark.sql(f'show partitions s_{target_schema}.{target_table}').createOrReplaceTempView("sym")
        #             df_missed_partitions = spark.sql(f"""
        #             select concat('{target_partition_column}=',cast({target_partition_column} as varchar(100))) as partition 
        #             from hive
        #             minus
        #             select partition from sym
        #             """)

        #             partition_set = set([row.partition.split('=')[-1] for row in df_missed_partitions.collect()])

        #             logger.info(f"""Partitions that were in Delta but not in Athena/Glue catalog were: {','.join(partition_set)}""")
        #     except Exception as exc:
        #         logger.info(
        #             f'MSCK will run instead of alter table to add the partition as the table s_{target_schema}.{target_table} might not be partitioned by date')
        #         logger.info(exc)
        #         if target_partition_column:
        #             update_partitions_query = f'MSCK REPAIR TABLE s_{target_schema}.{target_table}'
        #             logger.info(update_partitions_query)
        #             spark.sql(update_partitions_query)
        #         pass
        # else:
        #     # Update partitions for Non-date partitions
        #     # NOTE: MSCK REPAIR TABLE only works on partitioned tables
        #     if target_partition_column:
        #         update_partitions_query = f'MSCK REPAIR TABLE s_{target_schema}.{target_table}'
        #         logger.info(update_partitions_query)
        #         spark.sql(update_partitions_query)
            
        # for partition_to_check in partition_set:
        #     partitions_already_exists = spark.sql(
        #         f'show partitions s_{target_schema}.{target_table} PARTITION ({target_partition_column}=\'{partition_to_check}\')').collect()

        #     if target_partition_column and not partitions_already_exists:
        #         logger.info(
        #             f'Table s_{target_schema}.{target_table} will be altered to add partition {partition_to_check}')
        #         add_partition = f"""
        #             ALTER TABLE s_{target_schema}.{target_table} ADD PARTITION ({target_partition_column}=\'{partition_to_check}\')
        #             """
        #         logger.info(add_partition)
        #         spark.sql(add_partition)
        #     else:
        #         logger.info(
        #             f'Either table s_{target_schema}.{target_table} is not partitioned or partition {partition_to_check} already exists in it')

    except Exception as exc:
        logger.error(exc)
        raise exc
