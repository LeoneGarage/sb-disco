
from botocore.exceptions import ClientError
import boto3
from urllib.parse import urlparse
from datetime import datetime

from boto3.session import Session

import logging
logging.basicConfig()
logger = logging.getLogger(__name__) 

from lakehouselib.services.aws.s3.utility import *

def write_spark_dataframe_to_csv_in_s3_custom_filename(spark_df, s3_path, file_name, delimiter, mode="overwrite", header=True, compression="none"):
    """
    """

    try:
        spark_df.coalesce(1).write.mode(mode).option("header", header).option("delimiter", delimiter).option("compression", compression).csv(s3_path)

        bucket, key = get_bucket_key_from_s3_path(s3_path)
        prefix = f"{key}/part"
        s3_key_list = list_s3_keys_from_s3_bucket_prefix(bucket, prefix)
        s3_key = s3_key_list[0]
        s3_key_new = f"{key}/{file_name}"

        logger.info(f"bucket -> {bucket}")
        logger.info(f"key -> {key}")
        logger.info(f"prefix -> {prefix}")
        logger.info(f"s3_key -> {s3_key}")
        logger.info(f"s3_key_new -> {s3_key_new}")

        file_size=check_existing_s3_file_size(bucket, s3_key_new)

        if file_size:
            delete_s3_file(bucket, s3_key_new)

        rename_s3_file(bucket, s3_key, bucket, s3_key_new)

        return 0

    except Exception as exp:
        logger.error (exp)
        raise exp              
        
def write_spark_dataframe_to_csv_in_s3_custom_filename_copy(spark_df, s3_path, file_name, delimiter, mode="overwrite", header=True, compression=None):
    """
    """

    try:
        spark_df.coalesce(1).write.mode(mode).option("header", header).option("delimiter", delimiter).option("compression", compression).csv(s3_path)

        bucket, key = get_bucket_key_from_s3_path(s3_path)
        prefix = f"{key}/part"
        s3_key_list = list_s3_keys_from_s3_bucket_prefix(bucket, prefix)
        s3_key = s3_key_list[0]
        s3_key_new = f"{key}/{file_name}"

        logger.info(f"bucket -> {bucket}")
        logger.info(f"key -> {key}")
        logger.info(f"prefix -> {prefix}")
        logger.info(f"s3_key -> {s3_key}")
        logger.info(f"s3_key_new -> {s3_key_new}")

        file_size=check_existing_s3_file_size(bucket, s3_key_new)

        if file_size:
            delete_s3_file(bucket, s3_key_new)

        rename_s3_file_copy(bucket, s3_key, bucket, s3_key_new)

        return 0

    except Exception as exp:
        logger.error (exp)
        raise exp              
