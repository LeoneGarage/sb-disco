import json
from pyspark.sql.functions import from_json, col, collect_set, coalesce, when, lit
from pyspark.sql.types import *
from pyspark.sql import Row
def generate_schema(row,input_parsed_col_name):
    """
        This function converts the schema received from Kafka connect to the format required by Apache Spark
        This function acts as a python kafka convertor , mapping the kafka connect schema to pyspark schema

        Input Parameters:
            row - Dataframe row
            input_parsed_col_name - The dataframe column that contains the kafka connect message in string format 
                                    Example: {
                                                "schema": {
                                                    "type": "struct",
                                                    "fields": [
                                                    ...
                                                    {"type":"array","items":[]}
                                                },
                                                "payload": {
                                                    ...
                                                }
                                            }

    """
   
    row_dict = row.asDict()
    if len(row_dict.keys()) > 0:
        schema = json.loads(row_dict[input_parsed_col_name])
   
        final_schema = {"type" : "struct", "fields" : []}
        for x in schema["schema"]["fields"]:
            field = {}
            field["name"] = x["field"]
            field["metadata"] = {}

            if "int" in x["type"]:
                field["type"] = "integer"
            elif "array" in x["type"]:
                
                field["type"] = {"type":"array", "elementType" :{}}
                field["type"]["elementType"] = {"fields":[],"type":"struct"}
                field["type"]["type"] = x["type"]
                field["name"] = x["field"]
                field["metadata"] = {}
                nested_field_array = []
                if x["items"]["optional"] == "true":
                    field["type"]["containsNull"] = True
                else:
                    field["type"]["containsNull"] = False
                for y in x["items"]["fields"]:
                    nested_field = {}
                    nested_field["name"] = y["field"]
                    nested_field["metadata"] = {}
                    if "int" in y["type"]:
                        nested_field["type"] = "integer"
                    
                    elif "array" in y["type"]:
                        nested_field["type"] = {"type":"array", "elementType":""}
                        if "int" in y["items"]["type"]:
                            nested_field["type"]["elementType"] = "integer"
                        else:
                            nested_field["type"]["elementType"] = y["items"]["type"]
                        if y["items"]["optional"] == "true":
                            nested_field["type"]["containsNull"] = True
                        else:
                            nested_field["type"]["containsNull"] = False

                    else:
                        nested_field["type"] = y["type"]

                    if y["optional"] == "true":
                        nested_field["nullable"] = True
                    else:
                        nested_field["nullable"] = False
                    nested_field_array.append(nested_field)
                field["type"]["elementType"]["fields"] = nested_field_array

            else:
                field["type"] = x["type"]

            if x["optional"] == "true":
                field["nullable"] = True
            else:
                field["nullable"] = False
            final_schema["fields"].append(field)

        row_dict["schema"] = json.dumps(final_schema)
        row_dict["payload"] = json.dumps(json.loads(row_dict[input_parsed_col_name])["payload"])
        newrow = Row(**row_dict)
        return newrow

def deserialise_kafka_connect(df_parsed, input_parsed_col_name, output_parsed_col_name):
    """
        This function deserialises data received from kafka connect.
        It seperates the schema and payload and provides a deserialised struct payload as output.

        Input Parameters:
            df_parsed - Dataframe that needs to be deserialised

            input_parsed_col_name - The dataframe column that contains the kafka connect message in string format 
                                    Example: {
                                                "schema": {
                                                    "type": "struct",
                                                    "fields": [
                                                    ...
                                                },
                                                "payload": {
                                                    ...
                                                }
                                            }
            output_parsed_col_name - Required name of the output column. This column will contain the deseriliased struct payload data.

    """
    rdd_parsed=df_parsed.rdd.map(lambda x: generate_schema(x,input_parsed_col_name))
    df_parsed = rdd_parsed.toDF()
    schemas = df_parsed.select('schema').agg(collect_set("schema")).alias("schemas").collect()[0][0]
    df_output = df_parsed.withColumn(output_parsed_col_name,
              coalesce(*[when(col('schema') == lit(ex), from_json(col("payload"),  StructType.fromJson(json.loads(ex))))  for ex in schemas])
             )
    return (df_output)