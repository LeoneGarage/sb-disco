import logging

import pyspark.sql
import collections
import json
import calendar
import traceback

from delta.tables import DeltaTable
from datetime import datetime
from botocore.config import Config

from lakehouselib.framework.lakehouse.dynamodb.getters import get_data_columns, get_business_key_columns, \
    get_incremental_key_col, get_target_partition_col, get_timestamp_col, get_target_all_columns
from pyspark.sql import Window
from pyspark.sql.functions import col, from_unixtime, lag, lead, date_sub, current_date, \
    row_number, to_timestamp, xxhash64, lit, current_timestamp, format_string, date_format, substring, when, to_date, \
    unix_timestamp
from pyspark.sql.types import BooleanType, LongType, TimestampType, StringType, IntegerType
from pyspark.sql.avro.functions import from_avro
from lakehouselib.data.format.delta.utility import delta_merge_retry
from lakehouselib.framework.lakehouse.dynamodb.getters import map_source_to_target, get_target_schema_name, \
    get_target_table_name, get_target_partition_col, get_target_schema_definition_as_str, \
    get_target_schema_definition_as_dict
from lakehouselib.system.multithreading.propagatingprocesses import PropagatingProcesses
from lakehouselib.data.schema.handlers.glue.utility import create_hive_metastore, update_glue_catalog
from lakehouselib.statehandlers.eotfile.generator.utility import generate_delta_batch_eot
from lakehouselib.statehandlers.eotfile.generator.utility import generate_delta_batch_eot_multi
from lakehouselib.framework.lakehouse.dynamodb.utility import insert_or_update_table
from lakehouselib.services.aws.sessionmanager.utility import create_aws_session
from lakehouselib.data.transform.dataframeutils.utility import flatten_structs, flatten_array_struct_df
from lakehouselib.system.exception.handler import LakehouseError

from lakehouselib.statehandlers.eotfile.generator.utility import get_delta_table_version
from lakehouselib.framework.lakehouse.dynamodb.utility import insert_or_update_table, get_dynamo_record_from_partition_key
from lakehouselib.services.aws.sessionmanager.utility import create_aws_session

# ######################################################################################################
# SCD2
#   - https://docs.databricks.com/delta/delta-update.html#language-python
# note: This function is similar to the above, but because each development team went on different paths to create code,
#       we now have two versions of performing SCD2. The above is extremely monolithic and is in essence a convoluted
#       top-down application almost in it's own right, and needs a collaboration from the development teams to unify
#       the intent, and not break the caller applications
# note: The `perform_delta_merge` function attempts to adhere to cohesive & coupling coding approaches as appropriate
#       as it can

DATE_HIGH_END = '9999-12-31 00:00:00.0000'
DATE_LOW_START = '1900-01-01 00:00:00.0000'

config = Config(
    retries=dict(
        max_attempts=10
    )
)


@delta_merge_retry(retry_limit=10, wait_in_secs=120, retry_type='exponential_backoff')
def perform_delta_merge(spark: pyspark.sql.SparkSession, job_vars, df_input: pyspark.sql.DataFrame, output_path, sorted_meta_rows, config_item, batch_id: str = '0', DAY_LOOKUP: int = None, job_args: dict = dict()):
    """A function to perform a SCD-Type2 style merge using the delta.io API

    Parameters
    ----------
    spark : org.apache.spark
        The SparkSession object constructed created from `main.py`

    job_vars: util.config.stream.jobconfiguration class JobVariables
        All the required job variables to be used through out the job (JobVariables() -> job_vars)

    df_input : org.apache.spark.sql.DataFrame
        The incoming data from kafka (read_from_kafka)

    output_path : str
        The filesystem path of where the data will be written

    sorted_meta_rows : list
        A sorted list of mapped column names as defined in DynamoDB

    config_item : DynamoDB row
        information about the target table, such as partitions, etc

    batch_id : int
        value identifying the batch

    DAY_LOOKUP :
        value identifying the looking back period that based on date partition to perform delta merge. None mean merge to full table

    Returns
    -------
    None : None
        None

    """

    try:
        # get columns of target based on "business key types"
        cols_data_dict = get_data_columns(job_vars, sorted_meta_rows, with_col_order=True)
        cols_bus_key_dict = get_business_key_columns(job_vars, sorted_meta_rows, with_col_order=True)
        cols_bus_key = list(get_business_key_columns(job_vars, sorted_meta_rows))
        cols_non_ctl = collections.OrderedDict(sorted({**cols_bus_key_dict, **cols_data_dict}.items()))
        cols_incr_key = get_incremental_key_col(job_vars, config_item)
        col_ts = get_timestamp_col(job_vars, config_item)

        cols_target_partition = get_target_partition_col(job_vars, config_item)

        # record sequence number within the micro-batch, will increment if multiple updates to
        # record occurred in the source system within a short period of time
        col_seq_for_bkey = 'ctl_seq_for_bkey'

        col_created = 'ctl_created_utc_dts'
        col_date_end = 'ctl_effective_end_utc_dts'
        col_date_start = 'ctl_effective_start_utc_dts'
        col_hash = 'ctl_hash'
        col_hash_prev = 'ctl_hash_prev'
        col_modified = 'ctl_modified_utc_dts'
        col_created_batch_id = 'ctl_created_batch_id'
        col_updated_batch_id = 'ctl_updated_batch_id'
        col_updated_run_id = 'ctl_updated_run_id'
        col_offset = 'ctl_offset'
        col_date_start_calc = 'ctl_effective_start_utc_dts_calc'
        col_start_ts_prev = 'ctl_effective_start_utc_dts_prev'

        cols_target = get_target_all_columns(job_vars, sorted_meta_rows)
        ctl_hash = xxhash64(*cols_non_ctl.values())

        # remove records if one of the business keys is null
        for col_bus_key in cols_bus_key:
            df_input = df_input \
                .where(col(col_bus_key).isNotNull())

        # we get the mapped dataframe and add some columns that are computed at runtime
        df_input = df_input \
            .withColumn(col_created, current_timestamp()) \
            .withColumn(col_modified, lit(None).cast(TimestampType())) \
            .withColumn(col_hash, lit(ctl_hash).cast(LongType()))

        # create an empty DeltaTable if it doesn't already exist (for 1st runs)
        if not DeltaTable.isDeltaTable(spark, output_path):
            target_schema = df_input.schema

            if col_date_start not in target_schema.fieldNames():
                target_schema.add(col_date_start, pyspark.sql.types.TimestampType(), True)

            if col_date_end not in target_schema.fieldNames():
                target_schema.add(col_date_end, pyspark.sql.types.TimestampType(), True)

            df_existing: pyspark.sql.DataFrame = spark.createDataFrame(spark.sparkContext.emptyRDD(), target_schema)
            df_existing \
                .select(*cols_target) \
                .write \
                .format('delta') \
                .mode('overwrite') \
                .partitionBy(*cols_target_partition) \
                .save(output_path)
        else:
            df_existing: pyspark.sql.DataFrame = DeltaTable.forPath(spark, output_path).toDF()
    except Exception as exp:
        job_vars.logger.error(exp)
        error_msg = "Error creating or getting DeltaTable in `perform_delta_merge` for `{}`".format(job_vars.kafka_topic)
        job_vars.logger.error(error_msg)
        raise Exception(error_msg) from exp

    # 1. Cache the target data for incoming keys from the source
    try:

        df_existing_active = df_existing.filter(col(col_date_end) == lit(DATE_HIGH_END))
        df_existing_active = df_existing_active \
            .join(df_input, cols_bus_key, 'left_semi') \
            .select('*')

    except Exception as exp:
        job_vars.logger.error(exp)
        error_msg = "Error caching target data in `perform_delta_merge` for `{}`".format(job_vars.kafka_topic)
        job_vars.logger.error(error_msg)
        raise Exception(error_msg) from exp

    try:

        # 2. Remove older/already processed data from the source
        calc_start_ts = to_timestamp(
            format_string("%s.%s", date_format(from_unixtime(
                col(col_ts)/1000), "yyyy-MM-dd HH:mm:ss"), substring(col(col_ts), -3, 3))
        )

        df_input = df_input.withColumn(col_date_start, calc_start_ts)

        df_input = df_input \
            .join(df_existing_active, cols_bus_key, 'left') \
            .filter((df_input[col_offset] > df_existing_active[col_offset]) | (df_existing_active[col_offset].isNull())) \
            .withColumn(col_date_start_calc,
                        when(df_existing_active[col_date_start] > df_input[col_date_start], df_existing_active[col_date_start]).otherwise(df_input[col_date_start])) \
        .select(df_input['*'], col_date_start_calc)

        df_input = df_input.withColumn(col_date_start, col(col_date_start_calc)).drop(col_date_start_calc)

        # 3. Union target record with incoming source batch

        df_input_existing = df_input.unionByName(df_existing_active, allowMissingColumns=True)

        # 4. Remove unchanged records from the union of source and target
        calc_hash_prev = lag(col=col(col_hash), default=None, offset=1) \
            .over(
                Window
                .partitionBy(*cols_bus_key)
                .orderBy(*cols_incr_key)
        )

        df_input_existing = df_input_existing \
            .withColumn(col_hash_prev, calc_hash_prev) \
            .where(
                col(col_hash_prev).isNull()
                |
                (col(col_hash) != col(col_hash_prev))
            ).drop(col(col_hash_prev))

        # 5. End date records on the source-target union
        # s-t union can have records where start>end within the batch
        # start date will never change for high-end record from target, but can change for a few records from source
        calc_start_prev_ts = lag(col=col(col_date_start), default=DATE_LOW_START, offset=1) \
            .over(
            Window
                .partitionBy(*cols_bus_key)
                .orderBy(*cols_incr_key)
        )

        calc_start_ts = when(col(col_start_ts_prev) > col(col_date_start), col(col_start_ts_prev)) \
            .otherwise(col(col_date_start))

        calc_end_ts = lead(col=col(col_date_start), default=DATE_HIGH_END, offset=1) \
            .over(
                Window
                .partitionBy(*cols_bus_key)
                .orderBy(*cols_incr_key)
            )

        df_input_existing = df_input_existing \
            .withColumn(col_start_ts_prev, calc_start_prev_ts) \
            .withColumn(col_date_start, calc_start_ts) \
            .withColumn(col_date_end, calc_end_ts) \
            .drop(col_start_ts_prev)

        # 6. Merge source-target union with target
        # construct the "business key" comparison qualifiers to pass to spark sql
        partition_column = config_item['target_partition_column']
        if DAY_LOOKUP:
            join_condition = f' AND output_target.{partition_column} >= current_date() - INTERVAL {DAY_LOOKUP} DAYS AND '.join(
                ['(input_source.{v} = output_target.{v})'.format(v=col_match_key)
                 for col_match_key in cols_bus_key + cols_incr_key + [col_date_start] + [col_hash]]
            )
        else:
            join_condition = ' AND '.join(
                ['(input_source.{v} = output_target.{v})'.format(v=col_match_key)
                 for col_match_key in cols_bus_key + cols_incr_key + [col_date_start] + [col_hash]]
            )

        # restrict the columns to include in the insert statement
        values_to_insert = {
            k: f'input_source.{k}' for k in cols_target
        }

        values_to_insert[col_modified] = current_timestamp()
        values_to_insert[col_updated_batch_id] = f'input_source.{col_created_batch_id}'
        values_to_insert[col_updated_run_id] = f'input_source.{col_created_batch_id}'

        output_target: DeltaTable = DeltaTable.forPath(spark, output_path)

        if job_args:
            spark.conf.set("spark.databricks.delta.commitInfo.userMetadata", json.dumps(job_args))

        # end date existing records, and insert newly arriving records
        output_target.alias("output_target") \
            .merge(
                source=df_input_existing.alias("input_source"),
                condition=join_condition
            ).whenMatchedUpdate(
                condition=f"output_target.{col_date_end} <> input_source.{col_date_end}",
                set={
                    col_date_end: f'input_source.{col_date_end}',
                    col_modified: current_timestamp(),
                    col_updated_batch_id: lit(batch_id),
                    col_updated_run_id: lit(batch_id)
                }
            ).whenNotMatchedInsert(
                values=values_to_insert
            ).execute()

    except Exception as exp:
        job_vars.logger.error(exp)
        error_msg = "Error performing Delta.io merge operation in `perform_delta_merge` for `{}`".format(job_vars.kafka_topic)
        job_vars.logger.error(error_msg)
        raise Exception(error_msg) from exp


@delta_merge_retry(retry_limit=3, wait_in_secs=10, retry_type='exponential_backoff')
def update_metastore(spark, sqlContext, job_vars, target_schema_name, target_table_name, cfg_tbl, cfg_cols):
    """The micro-batch function executed as part of kafka streaming `foreachBatch` declaration

    Parameters
    ----------
    spark : org.apache.spark
        The SparkSession object constructed created from `main.py`

    job_vars: util.config.stream.jobconfiguration class JobVariables
        All the required job variables to be used through out the job (JobVariables() -> job_vars)

    target_schema_name:
        Target schema in which the target table exists

    target_table_name:
        Target table that will be altered in case if there is change in the input event schema

    cfg_tbl:
        The configuration items we are interested in for the table (get_ddb_config_meta)

    cfg_cols:
        The column items we are interested in for the target table (get_ddb_table_meta)

    Returns
    -------
    None : None
        None
    """
    target_partition_col = ','.join(
        get_target_partition_col(job_vars, cfg_tbl)
    )

    target_schema_defn_dict = get_target_schema_definition_as_dict(job_vars, cfg_cols)
    new_col_list = create_hive_metastore(
        job_vars.logger,
        spark,
        sqlContext,
        target_schema_name,
        cfg_tbl['target_s3_location'],
        target_table_name,
        target_schema_defn_dict,
        target_partition_col
    )

    target_schema_defn_str = get_target_schema_definition_as_str(job_vars, cfg_cols)
    update_glue_catalog(
        job_vars.logger,
        spark,
        cfg_tbl['target_s3_location'],
        target_schema_name,
        target_table_name,
        target_schema_defn_str,
        target_partition_col,
        new_col_list
    )


@PropagatingProcesses.thread_propagation()
def merge_data_thread(spark, sqlContext, job_vars, df_exploded, batch_id, epoch_id, **kwargs):
    """This function gets executed in each thread that gets spawned for each of the key,value pair
    present in the dict_to_iter

    Parameters
    ----------
    spark : org.apache.spark
        The SparkSession object constructed created from `main.py`

    job_vars: util.config.stream.jobconfiguration class JobVariables
        All the required job variables to be used through out the job (JobVariables() -> job_vars)

    df_exploded:
        Exploded dataframe coming from the pyspark apps

    batch_id:
        Batch id to be used in the delta merge and subsequently in the eot args

    kwargs:
        This has all the keyword args passed from merge_data_thread except dict_to_iter.
        The dict_to_iter is used as a parent dictionary from which each key value pair is used
        as iterKey and iterVal to be passed into kwargs and hence can be accessed like 
        kwargs['iterKey'] and kwargs['iterVal']

    Returns
    -------
    None : None
        None
    """
    # Build up the table mappings - this goes through each table matched to the topic from ddb
    # do mappings
    table_id = kwargs['iterKey']
    cfg_tbl = kwargs['iterVal']

    unprocessed_batch_ids = kwargs.get('unprocessed_batch_ids')
    unprocessed_batch_id = unprocessed_batch_ids.get(table_id)
    batch_id = unprocessed_batch_id if unprocessed_batch_id else batch_id

    job_args = kwargs.get('job_args')
    job_args['batch_id'] = batch_id

    cfg_cols = job_vars.ddb_metadata_config.get(table_id)
    df_mapped = map_source_to_target(df_exploded, job_vars, cfg_cols)
    # specify output path
    target_schema_name = get_target_schema_name(job_vars, cfg_tbl)
    target_table_name = get_target_table_name(job_vars, cfg_tbl)
    output_path = "{}/{}/{}".format(cfg_tbl['target_s3_location'], target_schema_name, target_table_name)

    df_mapped = df_mapped.withColumn('ctl_created_batch_id', lit(batch_id).cast(StringType())) \
        .withColumn('ctl_updated_batch_id', lit(batch_id).cast(StringType())) \
        .withColumn('ctl_inserted_run_id', lit(batch_id).cast(StringType())) \
        .withColumn('ctl_updated_run_id', lit(None).cast(StringType()))

    try:
        # perform delta merge (SCD2-Type2)
        perform_delta_merge(spark, job_vars, df_mapped, output_path, cfg_cols,
                            cfg_tbl, batch_id, job_args=kwargs.get('job_args'))
    except Exception as exp:
        job_vars.logger.error(exp)
        error_msg = "Error creating or getting DeltaTable in `perform_delta_merge` for `{}`".format(
            job_vars.kafka_topic)
        job_vars.logger.error(error_msg)
        raise Exception(error_msg) from exp

    if job_vars.job_args.get('run_mode') != 'local':
        eot_args = {
            'batch_id': batch_id,
            'dataDeliveryName': f'{target_schema_name}.{target_table_name}',
            'data_producer': kwargs['data_producer'],
            'producer_type': kwargs['producer_type'],
            'custodian': kwargs['custodian'],
            'custodian_contact': kwargs['custodian_contact'],
            'jobRunId': table_id,
            'partition_column': cfg_tbl['target_partition_column'],
            'batchIdColumnName': kwargs['batchIdColumnName']
        }

        client_session = create_aws_session()
        dynamodb = client_session.resource('dynamodb', region_name='ap-southeast-2', config=config)
        table_table_run_logs = dynamodb.Table('lakehouse_table_run_logs')

        rows_inserted, rows_updated, output_rows, rows_deleted, table_version = generate_delta_batch_eot_multi(
            job_vars.logger, output_path, client_session, DeltaTable, spark, eot_args, no_of_delta_log_files=1)

        update_metastore(spark, sqlContext, job_vars, target_schema_name, 
                         target_table_name, cfg_tbl, cfg_cols)

        kwargs_table = {'ctl_table_run_status': 'SUCCESS', 'ctl_table_run_end_time': (datetime.now()).strftime(
            '%Y-%m-%d %H:%M:%S'), 'rows_inserted': rows_inserted, 'rows_updated': rows_updated, 'rows_deleted': rows_deleted, 'output_rows': output_rows, 'table_version_after': table_version}
        insert_or_update_table(job_vars.logger, table_table_run_logs, 'ctl_run_id', table_id, **kwargs_table)



@PropagatingProcesses.thread_propagation()
def merge_avro_schema_data_thread(spark, sqlContext, job_vars, df, batch_id, epoch_id, schema_registry_client, source, **kwargs):
    """This function gets executed in each thread that gets spawned for each of the key,value pair
    present in the dict_to_iter

    Parameters
    ----------
    spark : org.apache.spark
        The SparkSession object constructed created from `main.py`

    job_vars: util.config.stream.jobconfiguration class JobVariables
        All the required job variables to be used through out the job (JobVariables() -> job_vars)

    df:
        Exploded dataframe coming from the pyspark apps

    batch_id:
        Batch id to be used in the delta merge and subsequently in the eot args

    schema_registry_client:
        This is used to get the latest schema id and subject details

    epoch_id: str
        Kafka generated micro-batch id (not used, but can be used to perform transaction coordinator like
        functions in the future

    source: str
        Type of input source. Ex: Kafka, Kinesis etc

    kwargs:
        This has all the keyword args passed from merge_data_thread except dict_to_iter.
        The dict_to_iter is used as a parent dictionary from which each key value pair is used
        as iterKey and iterVal to be passed into kwargs and hence can be accessed like
        kwargs['iterKey'] and kwargs['iterVal']

    Returns
    -------
    None : None
        None
    """
    # Build up the table mappings - this goes through each table matched to the topic from ddb
    # do mappings
    table_id = kwargs['iterKey']
    cfg_tbl = kwargs['iterVal']
    subject = get_subject_name(job_vars, cfg_tbl)

    unprocessed_batch_ids = kwargs.get('unprocessed_batch_ids')
    unprocessed_batch_id = unprocessed_batch_ids.get(table_id)
    batch_id = unprocessed_batch_id if unprocessed_batch_id else batch_id


    job_args = kwargs.get('job_args')
    job_args['batch_id'] = batch_id

    latest_schema_id = int(schema_registry_client.get_latest_version(subject).schema_id)
    job_vars.logger.info("Latest Schema Id  {a} and subject -- {b}".format(a=latest_schema_id, b=subject))
    currentValueSchema = schema_registry_client.get_schema(latest_schema_id).schema_str

    # Filter with valueSchemaId
    df_filtered = df[df['valueSchemaId'] == latest_schema_id]
    fromAvroOptions = {"mode": "PERMISSIVE"}

    # Currently we have one source (Kafka) and have its corresponding attributes "topic", "partition", "offset", "timestamp", "timestampType", "key"
    # Consider it as elseif ladder and add the conditions based on the new source & their attributes
    if source == "kafka":
        df1 = df_filtered.select(
            from_avro("fixedValue", currentValueSchema, fromAvroOptions).alias("parsedValue"), "topic", "partition",
            "offset", "timestamp", "timestampType", "key")

        df1 = df1.select("parsedValue.*", "topic", "partition", "offset", "timestamp", "timestampType", "key")

    df1 = flatten_structs(df1)
    df1 = flatten_array_struct_df(df1)

    df_exploded = df1.withColumn("ctl_headerdate", to_date((col("timestamp")))) \
        .withColumn("timestamp", unix_timestamp(col("timestamp"))) \
        .withColumn("ctl_dataloadts", lit(calendar.timegm(datetime.utcnow().timetuple())).cast(TimestampType())) \
        .withColumn("ctl_created_batch_id", lit(batch_id).cast(StringType())) \
        .withColumn("ctl_updated_batch_id", lit(batch_id).cast(StringType())) \
        .withColumn("ctl_src_id", lit(1).cast(IntegerType())) \
        .withColumn("ctl_part_id", lit(0).cast(IntegerType())) \
        .withColumn("ctl_inserted_run_id", lit(batch_id).cast(StringType())) \
        .withColumn("ctl_updated_run_id", lit(None).cast(StringType()))
    df_exploded = df_exploded.withColumn("timestamp", col("timestamp") * 1000)
    cfg_cols = job_vars.ddb_metadata_config.get(table_id)

    # do mappings
    df_mapped = map_source_to_target(df_exploded, job_vars, cfg_cols)

    # specify output path
    target_schema_name = get_target_schema_name(job_vars, cfg_tbl)
    target_table_name = get_target_table_name(job_vars, cfg_tbl)
    output_path = "{}/{}/{}".format(cfg_tbl['target_s3_location'], target_schema_name, target_table_name)

    # perform delta merge (SCD2-Type2)
    perform_delta_merge(spark, job_vars, df_mapped, output_path, cfg_cols, cfg_tbl, batch_id)
    job_vars.logger.info("Perform Delta Merge is done for {}".format(target_table_name) )

    if job_vars.job_args.get('run_mode') != 'local':
        eot_args = {
            'batch_id': batch_id,
            'dataDeliveryName': f'{target_schema_name}.{target_table_name}',
            'data_producer': kwargs['data_producer'],
            'producer_type': kwargs['producer_type'],
            'custodian': kwargs['custodian'],
            'custodian_contact': kwargs['custodian_contact'],
            'jobRunId': table_id,
            'partition_column': cfg_tbl['target_partition_column']
        }

        client_session = create_aws_session()
        dynamodb = client_session.resource('dynamodb', region_name='ap-southeast-2', config=config)
        table_table_run_logs = dynamodb.Table('lakehouse_table_run_logs')

        rows_inserted, rows_updated, output_rows, rows_deleted, table_version = generate_delta_batch_eot_multi(
            job_vars.logger, output_path, client_session, DeltaTable, spark, eot_args, no_of_delta_log_files=1)

        update_metastore_with_symlink(spark, sqlContext, job_vars, target_schema_name, target_table_name, cfg_tbl, cfg_cols)

        kwargs_table = {'ctl_table_run_status': 'SUCCESS', 'ctl_table_run_end_time': (datetime.now()).strftime(
            '%Y-%m-%d %H:%M:%S'), 'rows_inserted': rows_inserted, 'rows_updated': rows_updated,
                        'rows_deleted': rows_deleted, 'output_rows': output_rows, 'table_version_after': table_version}
        insert_or_update_table(job_vars.logger, table_table_run_logs, 'ctl_run_id', table_id, **kwargs_table)


def get_subject_name(job_vars, config_item):
    """Get the subject name of source

    Parameters
    ----------
    job_vars : util.config.stream.jobconfiguration class JobVariables
        All the required job variables to be used through out the job (JobVariables() -> job_vars)

    config_item : single row from dynamodb scanfilter
        The configuration items we are interested in for the table (get_ddb_config_meta)

    Returns
    -------
    return : str
        the subject of the corresponding table
    """
    try:
        columns = str(config_item['source_schema_name'])
        return columns
    except Exception as exc:
        err_msg = "Error obtaining `get_subject_name` for job `{}`".format(job_vars.job_name)
        raise LakehouseError(trace_err=traceback.format_exc(), err_nbr='5.25', err_msg=err_msg, job_vars=job_vars)


def update_table_run_logs(spark, job_vars, batch_id):
    # Get the delta table history and get the table version
    client_session = create_aws_session()
    dynamodb = client_session.resource(
        'dynamodb', region_name='ap-southeast-2')

    unprocessed_batch_id: str = None
    unprocessed_batch_ids: dict = dict()

    for table_id, cfg_tbl in job_vars.ddb_table_config.items():
        target_schema = get_target_schema_name(job_vars, cfg_tbl)
        target_table = get_target_table_name(job_vars, cfg_tbl)
        target_s3_location = cfg_tbl['target_s3_location']
        table_table_run_logs = dynamodb.Table('lakehouse_table_run_logs')

        job_vars.logger.info("Latest target_schema  {a} and target_table -- {b} and target_s3_location -- {c} ".format(a=target_schema, b=target_table, c=target_s3_location ))
        job_vars.logger.info("table_id in update_run_logs: {}".format(table_id))
        table_run_logs_record = get_dynamo_record_from_partition_key(
            job_vars.logger, table_table_run_logs, table_id)

        job_vars.logger.info("Table_run_logs_record: {}".format(table_run_logs_record))
        if table_run_logs_record:
            if table_run_logs_record['ctl_table_run_status'] == 'SUCCESS':
                current_table_version = get_delta_table_version(
                    target_s3_location + '/' + target_schema + '/' + target_table, DeltaTable, spark)
            else:
                current_table_version = table_run_logs_record['table_version_before']
                unprocessed_batch_id = table_run_logs_record['ctl_batch_id']
        else:
            current_table_version = -1

        unprocessed_batch_ids[table_id] = unprocessed_batch_id

        kwargs_table = {'ctl_run_id': table_id, 'ctl_table_run_status': 'STARTED', 'table_id': table_id, 'ctl_batch_id': unprocessed_batch_id if unprocessed_batch_id else batch_id,
                        'ctl_table_run_start_time': (datetime.now()).strftime('%Y-%m-%d %H:%M:%S'), 'table_version_before': current_table_version}
        insert_or_update_table(job_vars.logger, table_table_run_logs, 'ctl_run_id',
                                   table_id, exclude_cols_from_overwrites=dict(), **kwargs_table)

    return unprocessed_batch_ids


@delta_merge_retry(retry_limit=3, wait_in_secs=10, retry_type='exponential_backoff')
def update_metastore_with_symlink(spark, sqlContext, job_vars, target_schema_name, target_table_name, cfg_tbl, cfg_cols):
    """The micro-batch function executed as part of kafka streaming `foreachBatch` declaration

    Parameters
    ----------
    spark : org.apache.spark
        The SparkSession object constructed created from `main.py`

    job_vars: util.config.stream.jobconfiguration class JobVariables
        All the required job variables to be used through out the job (JobVariables() -> job_vars)

    target_schema_name:
        Target schema in which the target table exists

    target_table_name:
        Target table that will be altered in case if there is change in the input event schema

    cfg_tbl:
        The configuration items we are interested in for the table (get_ddb_config_meta)

    cfg_cols:
        The column items we are interested in for the target table (get_ddb_table_meta)

    Returns
    -------
    None : None
        None
    """
    target_partition_col = ','.join(
        get_target_partition_col(job_vars, cfg_tbl)
    )

    target_schema_defn_dict = get_target_schema_definition_as_dict(job_vars, cfg_cols)
    new_col_list = create_hive_metastore(
        job_vars.logger,
        spark,
        sqlContext,
        target_schema_name,
        cfg_tbl['target_s3_location'],
        target_table_name,
        target_schema_defn_dict,
        target_partition_col,
        generate_symlink = True
    )

    target_schema_defn_str = get_target_schema_definition_as_str(job_vars, cfg_cols)
    update_glue_catalog(
        job_vars.logger,
        spark,
        cfg_tbl['target_s3_location'],
        target_schema_name,
        target_table_name,
        target_schema_defn_str,
        target_partition_col,
        new_col_list
    )
