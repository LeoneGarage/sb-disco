from datetime import datetime
import os
from operator import itemgetter
from botocore.config import Config
from pyspark.sql import Window
from pyspark.context import SparkContext
from pyspark.sql import functions as f
from pyspark.sql.functions import *
from pyspark.sql.types import *
import sys
import time
import random

from lakehouselib.services.aws.sessionmanager.utility import *
from lakehouselib.services.aws.athena.utility import *
from lakehouselib.data.transform.dataframeutils.utility import *
from lakehouselib.framework.lakehouse.dynamodb.utility import *


client_session = create_aws_session()


def build_scd2(spark, DeltaTable, df_input, target_schema, target_table, batch_id, resp_tbl, resp_meta, resolvedArgs, client_session):
    """
    Function used in Glue

    :param spark: Spark instance object
    :param DeltaTable: DetaTable instance object
    :param df_input: input dataframe
    :param target_schema: schema/database of the target table
    :param target_table: table name
    :param batch_id: batch id of the run
    :param resp_tbl: lakehouse table config dict
    :param resp_meta: lakehouse meta config dict
    :param resolvedArgs: glue parameters config dict
    :param client_session: boto3 session client
    :return:
    """
    """
        This function generates SCD2 version of the data from L1 staging and writes back to L2 (bronze)
    """
    print("Entered build_scd2")
    lakehouse_log_table = resolvedArgs['lakehouse_log_table']
    lakehouse_config_table = resolvedArgs['lakehouse_config_table']
    lakehouse_batch_log_table = resolvedArgs['lakehouse_batch_log_table']
    lakehouse_meta_table = resolvedArgs['lakehouse_meta_table']
    target_partition_col = resolvedArgs['partition_att_name']
    delta_file_retention = resolvedArgs['delta_log_retention_days']
    delta_log_retention = resolvedArgs['delta_data_retention_days']


    dynamodb = client_session.resource('dynamodb', region_name='ap-southeast-2')

    config_table = dynamodb.Table(lakehouse_config_table)
    batch_log_table = dynamodb.Table(lakehouse_batch_log_table)
    log_table = dynamodb.Table(lakehouse_log_table)
    meta_table = dynamodb.Table(lakehouse_meta_table)

    err_code = ''
    err_desc = ''
    rows_inserted = 0
    rows_updated = 0

    print('######## Printing List of Columns in Source ############') # As per DPT-8073
    source_column_list = df_input.columns
    print(source_column_list)
    #matched_columns = [c for c in source_column_list if c in frmwk_gen_columns]
    if (len([c for c in source_column_list if c in ['start_ts']]) > 0):
        df_input = df_input.withColumnRenamed("start_ts","adp_start_ts")
    if (len([c for c in source_column_list if c in ['end_ts']]) > 0):
        df_input = df_input.withColumnRenamed("end_ts","adp_end_ts")
    
    # Generate run id
    run_id = str(int(datetime.utcnow().timestamp() * 1000))

    print("Generated run id for this run: " + run_id)
    table_id = resp_tbl[0]['table_id']
    # target_s3_bucket = resp_tbl['Items'][0]['target_s3_location']
    target_s3_bucket = resolvedArgs['l1_bucket']
    load_type = resp_tbl[0]['load_type']
    if (load_type.lower() == "full"):
        print("Running FULL load")
        pass
    else:
        if len(str(resp_tbl[0]['last_load_key']).split("|")) > 1:
            last_load_key = str(resp_tbl[0]['last_load_key']).split("|")[0]
            max_partition = str(resp_tbl[0]['last_load_key']).split("|")[1]
        else:
            last_load_key = str(resp_tbl[0]['last_load_key']).split("|")[0]
        incremental_key_col = resp_tbl[0]['source_incr_column']
        timestamp_col = resp_tbl[0]['source_ts_column']
        src_partition_col = str(resp_tbl[0]['source_partition_column']).split("|")
        print("my src_partition_col is :" + str(src_partition_col))
        target_partition_col = str(resp_tbl[0]['target_partition_column']).split("|")

    # Inserting start entry to run log table
    start_log_item = {
        'ctl_run_id': run_id,
        'batch_id': batch_id,
        'table_id': table_id,
        'table_run_start_time': str(datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
        'table_run_end_time': '',
        'err_code': '',
        'err_desc': '',
        'rows_inserted': 0,
        'rows_updated': 0,
        'max_val': '',
        'table_run_status': 'STARTED'
    }
    log_table.put_item(Item=start_log_item)

    try:
        sorted_meta_rows = sorted(resp_meta, key=itemgetter('target_column_order'))
        aud_col = [item['target_column_name'] for item in sorted_meta_rows if item['is_audit_column'] == True]
        data_col = [item['target_column_name'] for item in sorted_meta_rows if
                    item['is_audit_column'] == False and item['is_target_table_key'] == False]
        business_key_col = [item['target_column_name'] for item in sorted_meta_rows if
                            item['is_target_table_key'] == True]

        if (load_type.lower() == "full"):
            print("Running FULL load")
            pass
        else:
            print(business_key_col)
            print("target_schema: " + str(target_schema))
            print("target_table: " + str(target_table))
            print("table_id: " + str(table_id))
            print("target_s3_bucket: " + str(target_s3_bucket))
            print("load_type: " + str(load_type))
            print("last_load_key: " + str(last_load_key))
            print("aud_col: " + str(aud_col))
            print("business_key_col: " + str(business_key_col))
            print("incremental_key_col: " + str(incremental_key_col))
            print("timestamp_col: " + str(timestamp_col))
            print("src_partition_col: " + str(src_partition_col))
            print("target_partition_col: " + str(target_partition_col))
            print("data_col: " + str(data_col))
        if (load_type.lower() == "hist"):

            print("*********** HISTORICAL SCD2 LOAD IN PROGRESS ********** ")

            if len(data_col) > 0:

                # Dynamically create select - filter, alias, typecast all the required columns
                select_expr = []
                select_distinct_col = set()
                for item in sorted_meta_rows:
                    select_expr.append("cast(" + item["target_column_name"] + " as " + (
                        item["target_column_datatype"] + "(" + str(item["target_column_precision"]) + "," + str(
                            item["target_column_scale"]) + ")" if item[
                                                                      "target_column_datatype"].lower() == "decimal" else
                        item["target_column_datatype"]) + ") " + item["target_column_alias"])
                    select_distinct_col.add(item["source_column_name"])
                print("Reading source data")
                df_input = df_input.select(*list(select_distinct_col))
                print("Applying falttening")
                df_src = flatten_array_struct_df(df_input)
                print("Enforcing meta schema")
                df_delta = df_src.selectExpr(select_expr)

            else:
                df_delta = df_input
            # assign hash on the data columns
            print("applying hash")
            print("Hash Hist use col")
            print([item for item in df_delta.columns if item not in aud_col])
            df_delta = df_delta.withColumn("hash_val",
                                           xxhash64(*[item for item in df_delta.columns if item not in aud_col]))
            print("applying prev_rec_hash_val")
            df_delta = df_delta.withColumn("prev_rec_hash_val", lag(col=col("hash_val"), default=-1, offset=1).over(
                Window.partitionBy(*(business_key_col)).orderBy(col(incremental_key_col))))

            print("filtering dups/unchanged")
            df_delta = df_delta.filter(col("prev_rec_hash_val") != col("hash_val"))

            # end date records in case multiple updates coming in delta df
            print("adding scd columns")
            df_delta = df_delta.withColumn("p_headerts", to_timestamp(
                from_unixtime(col(timestamp_col) / 1000, "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"))) \
                .withColumn("start_ts", col("p_headerts")) \
                .withColumn("end_ts", lead(col=col("start_ts"), default='9999-12-31', offset=1).over(
                Window.partitionBy(*(business_key_col)).orderBy(col(incremental_key_col))))

            print("write to target")
            df_delta = df_delta.drop("prev_rec_hash_val")
            df_delta = df_delta.drop(target_partition_col[0])
            df_delta = df_delta.withColumn("ctl_inserted_run_id", lit(run_id)) \
                .withColumn("ctl_updated_run_id", lit(run_id)) \
                .withColumn("op_type", lit("I")) \
                .withColumn("ctl_created_utc_dts", current_timestamp()) \
                .withColumn("ctl_modified_utc_dts", current_timestamp()) \
                .withColumn("ctl_part_id", lit(0)) \
                .withColumn("ctl_is_deleted", lit(0)) \
                .withColumn("ctl_src_id", lit(1))

            df_delta = df_delta.withColumn(str(target_partition_col[0]),
                                           to_date(str(src_partition_col[0])).cast(StringType()))
            s3_path = 's3://{}/{}/{}'.format(target_s3_bucket, target_schema, target_table)

            print('### Write Initial S3 files to ' + s3_path)
            df_delta.write.partitionBy(str(target_partition_col[0])).format("delta").mode("overwrite").option(
                "overwriteSchema", "true").option("mergeSchema", "true").save(s3_path)
            print("#### Generate Athena DDL")
            print('s_' + target_table, target_partition_col, target_s3_bucket)
            df_sample = df_delta.limit(1)
            print(df_sample.show())
            athena_tbl = generate_athena_ddl(df_delta, target_schema, target_table, target_partition_col,
                                             target_s3_bucket, delta_file_retention, delta_log_retention, client_session)
            print(athena_tbl)
            print("dropping if exists target table")
            # Table creation on the target
            spark.sql("DROP TABLE IF EXISTS {}.{}".format('s_' + target_schema, target_table))

            print("generate symlink")
            deltaTable = DeltaTable.forPath(spark, s3_path)
            deltaTable.generate("symlink_format_manifest")
            print("Sym Link created")
            spark.sql(athena_tbl)

            print("\nRun MSCK REPAIR")
            spark.sql('MSCK REPAIR TABLE {}.{}'.format('s_' + target_schema, target_table))
            print("Done MSCK REPAIR")

            print("Getting Last Load Key from source")
            if (len(src_partition_col) > 0):
                print("Adding partition information to last load key")
                p_query = ""
                for p_col_source in src_partition_col:
                    for item in sorted_meta_rows:
                        if item["source_column_name"] == p_col_source:
                            p_col_target = item["target_column_alias"]
                    p_query = p_query + '\"{}>=\",\"\\\"\",max({}),\"\\\"\", \" AND \",'.format(p_col_source,
                                                                                                p_col_target)
                p_query = p_query[:-10]
                p_query = "concat(" + p_query + ") as max_parition_col"
                last_load_info = df_delta.selectExpr(
                    [f"max({incremental_key_col}) as last_load_key", f"{p_query}"]).collect()
                print("last_load_info: " + str(last_load_info))
                last_load_key = str(last_load_info[0].asDict()["last_load_key"]) + "|" + str(last_load_info[0].asDict()[
                                                                                                 "max_parition_col"])
                print("last_load_key: " + str(last_load_key))

                rows_inserted = df_delta.count()
                print("rows_inserted: " + str(rows_inserted))
                rows_updated = 0
                print("rows_updated: " + str(rows_updated))

            else:
                last_load_info = df_delta.selectExpr([f"max({incremental_key_col}) as last_load_key"]).collect()
                print("last_load_info: " + str(last_load_info))
                last_load_key = str(last_load_info[0].asDict()["last_load_key"]) + "|"
                print("last_load_key: " + str(last_load_key))

                rows_inserted = \
                spark.sql("select count(*) as rows_inserted from {}.{} ".format(target_schema, target_table)).collect()[
                    0].asDict()["rows_inserted"]
                print("rows_inserted: " + str(rows_inserted))
                rows_updated = 0
                print("rows_updated: " + str(rows_updated))

            print("rows_inserted: " + str(rows_inserted))
            # save the incremental key value in Dynamo for subsequent delta loads
            print("last_load_key: " + str(last_load_key))
            config_table.update_item(
                Key={
                    'table_id': table_id
                },
                UpdateExpression="SET last_load_key = :last_load_key, load_type = :load_type ",
                ExpressionAttributeValues={":last_load_key": last_load_key, ":load_type": "INC"},
            )

            print("*********** HISTORICAL SCD2 LOAD COMPLETED ********** ")
        elif (load_type.lower() == "inc"):

            print("*********** INCREMENTAL SCD2 LOAD IN PROGRESS ********** ")
            print(df_input.count())
            if len(data_col) > 0:
                # Dynamically create select - filter, alias, typecast all the required columns
                select_expr = []
                select_distinct_col = set()
                for item in sorted_meta_rows:
                    select_expr.append("cast(" + item["target_column_name"] + " as " + (
                        item["target_column_datatype"] + "(" + str(item["target_column_precision"]) + "," + str(
                            item["target_column_scale"]) + ")" if item[
                                                                      "target_column_datatype"].lower() == "decimal" else
                        item["target_column_datatype"]) + ") " + item["target_column_alias"])
                    select_distinct_col.add(item["source_column_name"])
                print("Reading source data")
                df_input = df_input.select(*list(select_distinct_col))
                print("Applying falttening")
                df_src = flatten_array_struct_df(df_input)
                print("Enforcing meta schema")
                df_delta = df_src.selectExpr(select_expr)
            else:
                df_delta = df_input
            # Read target data
            print("Reading target data")
            df_current = spark.read.format("delta").load(
                's3a://' + target_s3_bucket + "/" + target_schema + "/" + target_table)
            # Assign hash on the data columns
            df_delta = df_delta.withColumn("hash_val",
                                           xxhash64(*[item for item in df_delta.columns if item not in aud_col]))

            # Remove duplicates from df_delta
            print("Joining with target to get active rows for delta")
            print(type(business_key_col))
            print(business_key_col)
            df_join = df_current.join(broadcast(df_delta.select(*(business_key_col)).distinct()), business_key_col,
                                      "inner").select(df_current["*"]).drop("p_headerts")
            print("Unioning delta with active records from target")
            df_union = df_join.unionByName(df_delta, allowMissingColumns=True)
            df_scd2 = df_union.cache()
            print("applying prev_rec_hash_val")
            df_scd2 = df_scd2.withColumn("prev_rec_hash_val", lag(col=col("hash_val"), default=-1, offset=1).over(
                Window.partitionBy(*(business_key_col)).orderBy(col(incremental_key_col))))
            print("filtering dups/unchanged")
            df_scd2 = df_scd2.filter(col("prev_rec_hash_val") != col("hash_val"))
            print("Adding end dating columns to delta")

            df_scd2 = df_scd2.withColumn("p_headerts", to_timestamp(
                from_unixtime(col(timestamp_col) / 1000, "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"))) \
                .withColumn("start_ts", col("p_headerts")) \
                .withColumn("end_ts", lead(col=col("start_ts"), default='9999-12-31', offset=1).over(
                Window.partitionBy(*(business_key_col)).orderBy(col(incremental_key_col))))
            
            print("prepare df_inserts/updates")
            df_scd2 = df_scd2.select(df_current.columns)
            df_scd2 = df_scd2.drop("prev_rec_hash_val") \
                .withColumn("ctl_inserted_run_id", lit(run_id)) \
                .withColumn("ctl_updated_run_id", lit(run_id)) \
                .withColumn("op_type", lit("I")) \
                .withColumn("ctl_created_utc_dts", current_timestamp()) \
                .withColumn("ctl_modified_utc_dts", current_timestamp()) \
                .withColumn("ctl_part_id", lit(0)) \
                .withColumn("ctl_is_deleted", lit(0)) \
                .withColumn("ctl_src_id", lit(1))

            df_scd2 = df_scd2.withColumn(str(target_partition_col[0]),
                                         to_date(str(src_partition_col[0])).cast(StringType()))
            df_scd2.createOrReplaceTempView("updates")
            # End date the records which have a new version  # add runid and op_type = I/U then use this to get counts
            print(f"Merging updates \n")
            target = DeltaTable.forPath(spark, 's3a://' + target_s3_bucket + "/" + target_schema + "/" + target_table)
            print("Run Merge")
            try:
                target.alias("target_tbl").merge(df_scd2.alias("updates_tbl"),
                                                condition="updates_tbl.{}=target_tbl.{}".format(incremental_key_col,
                                                                                                incremental_key_col)) \
                    .whenMatchedUpdate(
                    condition="target_tbl.end_ts = '9999-12-31 00:00:00.000' AND updates_tbl.end_ts <> '9999-12-31 00:00:00.000'",
                    set={"op_type": lit("U"),
                        "end_ts": "updates_tbl.end_ts",
                        "ctl_updated_run_id": "updates_tbl.ctl_updated_run_id"
                        },
                ).whenNotMatchedInsertAll().execute()
            except Exception as exc:
                err_msg = "Error running merge operation inside build_scd2 \n"
                print('########### Capture Error START #############')
                print(err_msg + str(exc))
                print('########### Capture Error END #############')
                sys.exit()

            print("Getting Row Info")
            target.generate("symlink_format_manifest")
            print("\nRun MSCK REPAIR")
            spark.sql('MSCK REPAIR TABLE {}.{}'.format('s_' + target_schema, target_table))
            print("Done MSCK REPAIR")
            lastOperationDF = target.history(1)
            rows_info = lastOperationDF.select('operation',
                                               element_at(col('operationMetrics'), 'numTargetRowsInserted').alias(
                                                   "rows_inserted"),
                                               element_at(col('operationMetrics'), 'numTargetRowsUpdated').alias(
                                                   "rows_updated"),
                                               element_at(col('operationMetrics'), 'numSourceRows').alias(
                                                   "rows_source")).collect()
            rows_updated = rows_info[0]["rows_updated"]
            rows_inserted = rows_info[0]["rows_inserted"]
            rows_source = rows_info[0]["rows_source"]
            print(rows_info)
            # save the incremental key value in Dynamo for subsequent delta loads
            # Read target to get metrics
            if (len(src_partition_col) > 0):
                p_query = "concat(p_date) as max_parition_col"
                print("p_query: " + p_query)
                print("\n get last_load_info")
                spark.read.format("delta").load(
                    's3://' + target_s3_bucket + "/" + target_schema + "/" + target_table).createOrReplaceTempView(
                    "target_tbl")
                last_load_info = spark.sql(
                    "select max({}) as last_load_key, max({}) as max_parition_col from target_tbl".format(
                        incremental_key_col, str(target_partition_col[0]))).collect()
                last_load_key = str(last_load_info[0].asDict()["last_load_key"]) + "|" + str(last_load_info[0].asDict()[
                                                                                                 "max_parition_col"])
                print(last_load_key)
            else:
                spark.read.format("delta").load(
                    's3://' + target_s3_bucket + "/" + target_schema + "/" + target_table).createOrReplaceTempView(
                    "target_tbl")
                last_load_info = spark.sql(
                    "select max({}) as last_load_key from target_tbl".format(incremental_key_col)).collect()
                last_load_key = last_load_info[0].asDict()["last_load_key"] + "|"

            config_table.update_item(
                Key={
                    'table_id': table_id
                },
                UpdateExpression="SET last_load_key = :last_load_key",
                ExpressionAttributeValues={":last_load_key": last_load_key},
            )
            print("*********** INCREMENTAL SCD2 LOAD COMPLETED ********** ")
        elif (load_type.lower() == "full"):

            print("***********  TRUNCATE/LOAD IN PROGRESS ********** ")

            if len(data_col) > 0:

                # Dynamically create select - filter, alias, typecast all the required columns
                select_expr = []
                select_distinct_col = set()
                for item in sorted_meta_rows:
                    select_expr.append("cast(" + item["target_column_name"] + " as " + (
                        item["target_column_datatype"] + "(" + str(item["target_column_precision"]) + "," + str(
                            item["target_column_scale"]) + ")" if item[
                                                                      "target_column_datatype"].lower() == "decimal" else
                        item["target_column_datatype"]) + ") " + item["target_column_alias"])
                    select_distinct_col.add(item["source_column_name"])
                print("Reading source data")
                df_input = df_input.select(*list(select_distinct_col))
                print("Applying falttening")
                df_src = flatten_array_struct_df(df_input)
                print("Enforcing meta schema")
                df_delta = df_src.selectExpr(select_expr)

            else:
                df_delta = df_input
            print("write to target")
            df_delta = df_delta.withColumn("ctl_inserted_run_id", lit(run_id)) \
                .withColumn("ctl_updated_run_id", lit(run_id)) \
                .withColumn("op_type", lit("I")) \
                .withColumn("ctl_created_utc_dts", current_timestamp()) \
                .withColumn("ctl_modified_utc_dts", current_timestamp()) \
                .withColumn("ctl_part_id", lit(0)) \
                .withColumn("ctl_is_deleted", lit(0)) \
                .withColumn("ctl_src_id", lit(1))

            s3_path = 's3://{}/{}/{}'.format(target_s3_bucket, target_schema, target_table)

            print("#### Generate Athena DDL")
            print(target_schema, target_table, target_s3_bucket)
            df_sample = df_delta.limit(1)
            print(df_sample.show())
            if wr.catalog.does_table_exist(database=target_schema, table=target_table) is True:
                print("Table {}.{} already exists.".format(target_schema, target_table))
                print("Truncating & Loading the data from {}.{}".format(target_schema, target_table))
                df_delta.write.mode("overwrite").format("delta").save(s3_path)
                deltaTable = DeltaTable.forPath(spark, s3_path)
                deltaTable.generate("symlink_format_manifest")
                print("Sym Link created")
            else:
                print("Table {}.{} does not exists.".format(target_schema, target_table))
                print('### Write Initial S3 files to ' + s3_path)
                df_delta.write.mode("overwrite").format("delta").save(s3_path)
                athena_tbl = generate_athena_ddl_unpartitioned(df_delta, target_schema, target_table,
                                                target_s3_bucket, delta_file_retention, delta_log_retention, client_session)
                print(athena_tbl)
                print("generate symlink")
                deltaTable = DeltaTable.forPath(spark, s3_path)
                deltaTable.generate("symlink_format_manifest")
                spark.sql(athena_tbl)


            print(df_delta.count())
            rows_inserted = df_delta.count()
            print(rows_inserted)
            print("rows_inserted: " + str(rows_inserted))

            print("*********** TRUNCATE/LOAD LOAD COMPLETED ********** ")

    except Exception as ex:
        log_table = dynamodb.Table('lakehouse_table_run_logs')
        # Write failure entry to log table
        print(str(sys.exc_info()))
        ex_type, ex_value, ex_traceback = sys.exc_info()

        log_table.update_item(
            Key={
                'ctl_run_id': run_id
            },
            UpdateExpression="SET err_code = :err_code, err_desc = :err_desc, \
                                      table_run_end_time = :table_run_end_time, table_run_status = :table_run_status",
            ExpressionAttributeValues={
                ":table_run_end_time": str(datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
                ":err_code": str(ex_type.__name__),
                ":err_desc": str(ex_value),
                ":table_run_status": 'FAILED'
            },
        )

    else:
        # No exceptions, write success entry to log table
        log_table.update_item(
            Key={
                'ctl_run_id': run_id
            },
            UpdateExpression="SET  table_run_end_time = :table_run_end_time, rows_inserted = :rows_inserted, table_run_status = :table_run_status",
            ExpressionAttributeValues={":table_run_end_time": str(datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
                                       ":rows_inserted": rows_inserted,
                                       ":table_run_status": 'SUCCESS'
                                       },
        )



def run_scd2(logger, spark, DeltaTable, df, resolvedArgs, client_session):
    """
    :param spark: Spark instance object
    :param DeltaTable: DetaTable instance object
    :param df: input dataframe
    :param resolvedArgs: glue parameters config dict
    :param client_session: boto3 session client
    :return: None
    """
    print('########################## Start SCD2 ###########################')
    batch_id = resolvedArgs['batch_id']
    print("Generated batch id for this run: " + batch_id)

    target_schema = resolvedArgs['target_database']
    target_table = resolvedArgs['table_name']
    batch_name = ''
    lakehouse_log_table = resolvedArgs['lakehouse_log_table']
    lakehouse_config_table = resolvedArgs['lakehouse_config_table']
    lakehouse_batch_log_table = resolvedArgs['lakehouse_batch_log_table']
    lakehouse_meta_table = resolvedArgs['lakehouse_meta_table']


    dynamodb = client_session.resource('dynamodb', region_name='ap-southeast-2')

    config_table = dynamodb.Table(lakehouse_config_table)
    batch_log_table = dynamodb.Table(lakehouse_batch_log_table)
    log_table = dynamodb.Table(lakehouse_log_table)
    meta_table = dynamodb.Table(lakehouse_meta_table)
    # Inserting start batch entry to run log table
    start_log_item = {
        'batch_id': batch_id,
        'batch_run_start_time': str(datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
        'err_code': '',
        'err_desc': '',
        'batch_run_end_time': '',
        'batch_run_status': 'STARTED'
    }
    batch_log_table.put_item(Item=start_log_item)

    try:
        if (len(batch_name) > 0 and len(target_table) == 0):
            print(" ***** Running batch mode ***** ")
            resp_batch = config_table.scan(
                ScanFilter={"batch_name": {"AttributeValueList": [batch_name], "ComparisonOperator": "EQ"},
                            "is_row_active": {"AttributeValueList": [True], "ComparisonOperator": "EQ"}},
                ConditionalOperator='AND')
            if (len(resp_batch['Items']) == 0):
                raise Exception("No valid table entries found for " + str(batch_name))
            for item in resp_batch['Items']:
                print("Running batch load for : " + str(item['target_schema_name']) + "." + str(
                    item['target_table_name']))
                resp_tbl = config_table.scan(ScanFilter={

                    "target_table_name": {

                        "AttributeValueList": [item['target_table_name']],
                        "ComparisonOperator": "EQ"

                    },

                    "target_schema_name": {

                        "AttributeValueList": [item['target_schema_name']],
                        "ComparisonOperator": "EQ"

                    },

                    "is_row_active": {

                        "AttributeValueList": [True],
                        "ComparisonOperator": "EQ"

                    }

                }, ConditionalOperator='AND')
                if len(resp_tbl['Items']) > 1:
                    raise Exception("Duplicate entries found in lakehouse_table_config table!!")
                table_id = resp_tbl['Items'][0]['table_id']
                resp_meta = meta_table.scan(ScanFilter={

                    "table_id": {

                        "AttributeValueList": [table_id],
                        "ComparisonOperator": "EQ"

                    },

                    "is_row_active": {

                        "AttributeValueList": [True],
                        "ComparisonOperator": "EQ"

                    }
                }, ConditionalOperator='AND')
                build_scd2(spark, DeltaTable, df, item['target_schema_name'], item['target_table_name'], batch_id, resp_tbl, resp_meta, resolvedArgs, client_session)
        elif (len(batch_name) == 0 and len(target_table) > 0):
            print(" ***** Running table mode ***** ")
            print("Running table load for : " + target_schema + "." + target_table)
            resp_tbl = query_table_config(logger, config_table, target_table_name=target_table, target_schema_name=target_schema)
            print("resp_tbl: "+str(resp_tbl))

            if len(resp_tbl) > 1:
                raise Exception("Duplicate entries found in lakehouse_table_config table!!")

            table_id = resp_tbl[0]['table_id']
            print(table_id)
            resp_meta = query_metadata_config(logger, meta_table, table_id)
            print("resp_meta: "+str(resp_meta))
            print('#################')
            build_scd2(spark, DeltaTable, df, target_schema, target_table, batch_id, resp_tbl, resp_meta, resolvedArgs, client_session)
        else:
            #     print("Please provide either group name or table name")
            raise Exception("Please provide either group name or table name")
    except Exception as ex:
        # Write failure entry to log table
        print(str(sys.exc_info()))
        ex_type, ex_value, ex_traceback = sys.exc_info()
        batch_log_table.update_item(
            Key={
                'batch_id': batch_id
            },
            UpdateExpression="SET err_code = :err_code, err_desc = :err_desc, \
                                  batch_run_end_time = :batch_run_end_time, batch_run_status = :batch_run_status",
            ExpressionAttributeValues={
                ":batch_run_end_time": str(datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
                ":err_code": str(ex_type.__name__),
                ":err_desc": str(ex_value),
                ":batch_run_status": 'FAILED'
            },
        )
    else:
        table_success = True
        tables_run_log = log_table.scan(
            ScanFilter={"batch_id": {"AttributeValueList": [batch_id], "ComparisonOperator": "EQ"}})

        for item in tables_run_log['Items']:
            if (item['table_run_status'] == 'FAILED'):
                table_success = False

        if table_success == True:
            batch_log_table.update_item(
                Key={
                    'batch_id': batch_id
                },
                UpdateExpression="SET batch_run_end_time = :batch_run_end_time, batch_run_status = :batch_run_status",
                ExpressionAttributeValues={
                    ":batch_run_end_time": str(datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
                    ":batch_run_status": 'SUCCESS'
                },
            )
        else:
            batch_log_table.update_item(
                Key={
                    'batch_id': batch_id
                },
                UpdateExpression="SET err_code = :err_code, err_desc = :err_desc, \
                                  batch_run_end_time = :batch_run_end_time, batch_run_status = :batch_run_status",
                ExpressionAttributeValues={
                    ":batch_run_end_time": str(datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
                    ":err_code": 'batch failed',
                    ":err_desc": 'One/more tables in this batch failed',
                    ":batch_run_status": 'FAILED'
                },
            )

def get_time():
    t = time.localtime()
    current_time = time.strftime("%H:%M:%S", t)
    return current_time

def delta_merge_retry(retry_limit=5, wait_in_secs=10, retry_type='uniform_retry'):
    """[summary]

    Args:
        retry_limit (int, optional): [description]. Defaults to 5.
        wait_in_secs (int, optional): [description]. Defaults to 10.
        retry_type (str, optional): [description]. Defaults to 'uniform_retry'.
    """
    def retry_call(f):
        def retry_wrapper(*args, **kwargs):
            """
            Wrapper to implement retry logic

            Args:
                args: This will have the args passed from merge_data i.e. merge_statement
                kwargs: This will have kwargs from testFunction
            Returns:
                Callable
            """
            retry_counter = 0
            while True:
                try:
                    print ('delta_merge_retry START')
                    return f(*args, **kwargs)
                except Exception as e:
                    print (e)
                    ex_type, ex_value, ex_traceback = sys.exc_info()
                    merge_ex_class = str(ex_type.__name__)
                    print("merge_ex_class: " + merge_ex_class)
                    if 'ConcurrentAppendException' in merge_ex_class or 'ConcurrentDeleteReadException' in merge_ex_class or 'ConcurrentWriteException' in merge_ex_class or 'ConcurrentTransactionException' in merge_ex_class:
                        if retry_counter > retry_limit:
                            print ('retry_counter - OVER LIMIT', retry_counter, 'retry_limit', retry_limit)
                            raise
                        else:
                            if retry_type == 'exponential_backoff':
                                sleep = (wait_in_secs * 2 ** retry_counter + random.uniform(0, 1))
                                print ('sleep - exponential_backoff', sleep, 'TIME now', get_time())
                                time.sleep(sleep)
                                print ('TIME now after sleep', get_time())
                            elif retry_type == 'uniform_retry':
                                sleep = wait_in_secs
                                print ('SLEEP - uniform_retry', sleep, 'TIME now', get_time())
                                time.sleep(sleep)
                                print ('TIME now after sleep', get_time())
                            retry_counter += 1
                            print ('retry_counter', retry_counter)
                    else:
                        raise
        return retry_wrapper
    return retry_call

@delta_merge_retry(retry_limit=10, wait_in_secs=10, retry_type='exponential_backoff')
def merge_data(logger, spark, merge_stmt):
    """
    Merge function that submits the merge statement

    Args:
        merge_stmt: merge statement
    """
    print ('merge_data', merge_stmt)
    logger.info (merge_stmt)
    spark.sql(merge_stmt)
