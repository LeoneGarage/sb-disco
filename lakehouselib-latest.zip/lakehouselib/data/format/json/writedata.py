import traceback

from lakehouselib.system.exception.handler import LakehouseError


def save_json(df, job_vars, *partition_columns):
    """A function that saves a dataframe as JSON data

    Parameters
    ----------
    df : org.apache.spark.sql.DataFrame
        The incoming data from kafka (read_from_kafka)

    job_vars : util.config.stream.jobconfiguration class JobVariables
        All the required job variables to be used through out the job (JobVariables() -> job_vars)

    partition_columns : dict (variadic)
        the partitions to save the json data

    Returns
    -------
    None : None
        None
    """
    try:
        df.write.format("json").mode("append").partitionBy(*partition_columns).save(job_vars.outputpathlanding)
    except Exception as exc:
        err_msg = "Error saving data as JSON for job `{}`".format(job_vars.job_name)
        raise LakehouseError(trace_err=traceback.format_exc(), err_nbr='1.1', err_msg=err_msg, job_vars=job_vars)
