import json
import logging
from google.protobuf.json_format import MessageToDict
# note: the imports from within the generated protobuf py files need to be resolvable. when changing the schema, ensure
# that the new files are resolvable
from lakehouselib.data.format.protobuf.pycompiled.comppricing import events_pb2

logging.basicConfig()
logger = logging.getLogger(__name__)


def decode_protobuf(val: bytes):
    """A function to decode incoming pb data

    Parameters
    ----------
    val : bytes
        The value object of the Kafka message

    Returns
    -------
    payload : str
        A JSON formatted string representation of the applied ppy on the incoming data
    """
    runnerprice = '{"header":{"timeStamp": "0"}}'
    try:
        read_rfpcpup = events_pb2.RfpCompetitorPriceUpdated()
        read_rfpcpup.ParseFromString(val)
        
        cp_dict = MessageToDict(read_rfpcpup)

        # Remove Characters - . [ ] to remove key that look like `[bet.state]` to betstate
        new_keys = {}
        for k in cp_dict.keys():
            new_key = k.replace('[', '').replace(']', '').replace('.', '').replace('_', '')
            if k != new_key:
                new_keys[k] = new_key

        for k in new_keys.keys():
            cp_dict[new_keys[k]] = cp_dict.pop(k)

        runnerprice = json.dumps(cp_dict, separators=(',', ':'))
    except Exception as exp:
        logger.error("Error in `decode_protobuf` method")
        logger.error(exp)
        runnerprice = '{"header":{"timeStamp": "0"}}'

    return runnerprice
