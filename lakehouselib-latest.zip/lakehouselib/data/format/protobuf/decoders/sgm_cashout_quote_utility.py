import json
import logging
from google.protobuf.json_format import MessageToDict
# note: the imports from within the generated protobuf py files need to be resolvable. when changing the schema, ensure
# that the new files are resolvable
from lakehouselib.data.format.protobuf.pycompiled.corebetting import sgmCashout_pb2
logging.basicConfig()
logger = logging.getLogger(__name__)


def decode_protobuf(val: bytes):
    """A function to decode incoming pb data

    Parameters
    ----------
    val : bytes
        The value object of the Kafka message

    Returns
    -------
    payload : str
        A JSON formatted string representation of the applied ppy on the incoming data
    """
    if val is None:
        return '{"header":{"timeStamp": "0"}}'

    try:
        read_quote_event = sgmCashout_pb2.QuoteEvent()
        read_quote_event.ParseFromString(val)

        sgm_dict = MessageToDict(read_quote_event)

        # Remove Characters - . [ ] to remove key that look like `[bet.state]`
        new_keys = {}
        for k in sgm_dict.keys():
            new_key = k.replace('[', '').replace(']', '').replace('.', '').replace('_', '')
            if k != new_key:
                new_keys[k] = new_key

        for k in new_keys.keys():
            sgm_dict[new_keys[k]] = sgm_dict.pop(k)

        payload = json.dumps(sgm_dict, separators=(',', ':'))
    except Exception as exp:
        logger.error("Error in `decode_protobuf` method")
        logger.error(exp)
        exceptions = str(exp)
        payload = '{"header":"timeStamp", "excepton": "'+exceptions+'"}'

    return payload
