import json
import logging
from typing import Union
from google.protobuf.json_format import MessageToDict
# note: the imports from within the generated protobuf py files need to be resolvable. when changing the schema, ensure
# that the new files are resolvable
from lakehouselib.data.format.protobuf.pycompiled.racingfeed.sportsbet.rmf.forms.aap import runner_pb2, form_pb2, common_pb2, forms_events_pb2, \
    jockey_pb2, meeting_pb2, race_pb2, track_pb2

logging.basicConfig()
logger = logging.getLogger(__name__)


def decode_protobuf_rf(val: bytes):
    """A function to decode incoming pb data

    Parameters
    ----------
    val : bytes
        The value object of the Kafka message

    Returns
    -------
    payload : str
        A JSON formatted string representation of the applied ppy on the incoming data
    """
    if not val:
        return '{"header":{"timeStamp": "0"}}'

    try:
        try:
            try:
                try:
                    try:
                        try:
                            read_form = forms_events_pb2.RunnersUpdated()
                            read_form.ParseFromString(val)
                            rf_dict = MessageToDict(read_form)
                        except:
                            read_form = forms_events_pb2.FormsUpdated()
                            read_form.ParseFromString(val)
                            rf_dict = MessageToDict(read_form)
                    except:
                        read_form = forms_events_pb2.MeetingUpdated()
                        read_form.ParseFromString(val)
                        rf_dict = MessageToDict(read_form)
                except:
                    read_form = forms_events_pb2.RacesUpdated()
                    read_form.ParseFromString(val)
                    rf_dict = MessageToDict(read_form)
            except:
                read_form = forms_events_pb2.RunnersUpdated()
                read_form.ParseFromString(val)
                rf_dict = MessageToDict(read_form)
        except:
            read_form = forms_events_pb2.TrackUpdated()
            read_form.ParseFromString(val)
            rf_dict = MessageToDict(read_form)      


        # Remove Magic bytes
        #val = val[5:]

        #read_form.ParseFromString(val)

        #rf_dict = MessageToDict(read_form)

        new_keys = {}
        for k in rf_dict.keys():
            new_key = k.replace('[', '').replace(']', '').replace('.', '').replace('_', '')
            if k != new_key:
                new_keys[k] = new_key

        for k in new_keys.keys():
            rf_dict[new_keys[k]] = rf_dict.pop(k)

        payload = json.dumps(rf_dict, separators=(',', ':'))
    except Exception as exp:
        logger.error("Error in `decode_protobuf` method")
        logger.error(exp)
        exceptions = str(exp)
        payload = '{"header":"timeStamp", "excepton": "'+exceptions+'"}'

    return payload
