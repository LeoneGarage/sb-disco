import json
import logging
from google.protobuf.json_format import MessageToDict
# note: the imports from within the generated protobuf py files need to be resolvable. when changing the schema, ensure
# that the new files are resolvable
from lakehouselib.data.format.protobuf.pycompiled.activityfeed import customer_pb2, bet_pb2, sports_pb2, \
    translation_pb2, payment_pb2, core_pb2, account_pb2
from lakehouselib.data.format.protobuf.pycompiled.activityfeed.sportsbet import transaction_pb2
from lakehouselib.data.format.protobuf.pycompiled.activityfeed.sportsbet.bet import model_pb2 as sbbet
from lakehouselib.data.format.protobuf.pycompiled.activityfeed.sportsbet.customer import model_pb2 as sbcustomer

logging.basicConfig()
logger = logging.getLogger(__name__)


def decode_protobuf(val: bytes):
    """A function to decode incoming pb data

    Parameters
    ----------
    val : bytes
        The value object of the Kafka message

    Returns
    -------
    payload : str
        A JSON formatted string representation of the applied ppy on the incoming data
    """
    if val is None:
        return '{"header":{"timeStamp": "0"}}'

    try:
        read_activity = core_pb2.Activity()
        read_activity.RegisterExtension(bet_pb2.state)
        read_activity.RegisterExtension(bet_pb2.supportingState)
        read_activity.RegisterExtension(account_pb2.state)
        read_activity.RegisterExtension(customer_pb2.state)
        read_activity.RegisterExtension(payment_pb2.state)
        read_activity.RegisterExtension(sports_pb2.state)
        read_activity.RegisterExtension(sports_pb2.deltaState)
        read_activity.RegisterExtension(sbbet.state)
        read_activity.RegisterExtension(sbcustomer.state)
        read_activity.RegisterExtension(translation_pb2.state)
        read_activity.RegisterExtension(transaction_pb2.state)
        read_activity.ParseFromString(val)

        af_dict = MessageToDict(read_activity)

        # Remove Characters - . [ ] to remove key that look like `[bet.state]`
        new_keys = {}
        for k in af_dict.keys():
            new_key = k.replace('[', '').replace(']', '').replace('.', '').replace('_', '')
            if k != new_key:
                new_keys[k] = new_key

        for k in new_keys.keys():
            af_dict[new_keys[k]] = af_dict.pop(k)

        payload = json.dumps(af_dict, separators=(',', ':'))
    except Exception as exp:
        logger.error("Error in `decode_protobuf` method")
        logger.error(exp)
        payload = '{"header":{"timeStamp": "0"}}'

    return payload
