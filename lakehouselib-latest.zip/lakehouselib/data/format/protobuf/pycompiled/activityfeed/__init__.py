"""Top-level package for lakehouse repo."""

__author__ = """LakeHouse Repo Library"""
__email__ = 'TeamVulcan@sportsbet.com.au'
__version__ = '0.0.1'
