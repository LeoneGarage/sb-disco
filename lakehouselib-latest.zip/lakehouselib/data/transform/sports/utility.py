import pyspark
import traceback

from pyspark.sql.functions import explode_outer
from lakehouselib.framework.lakehouse.dynamodb.getters import __df_has_column
from lakehouselib.system.exception.handler import LakehouseError


def explode_sports(df, job_vars):
    """Explode sports activity feed data

    Parameters
    ----------
    df : org.apache.spark.sql.DataFrame
        The incoming data from kafka (read_from_kafka)

    job_vars: util.config.stream.jobconfiguration class JobVariables
        All the required job variables to be used through out the job (JobVariables() -> job_vars)

    Returns
    -------
    exploded_data : org.apache.spark.sql.DataFrame
        A Representation of the incoming sports data exploded to a flattened form
    """
    try:
        # root
        #    |- event <struct>
        #    |    |- externalUID <arraystruct>
        #    |- market <struct>
        #    |    |- eachWayTermsDetails <struct>
        #    |    |    |- eachWayTerms <arraystruct>
        #    |    |- externalUID <arraystruct>
        #    |    |- results <arraystruct>
        #    |- outcome <struct>
        #    |    |- externalUID <arraystruct>
        #    |    |- results <arraystruct>
        #    |- outcomestatus <struct>
        #         |- price <arraystruct>
        df = __df_explode_column(df, 'e_event_externalUID', 'af.sportsstate.event.externalUID')
        df = __df_explode_column(df, 'e_market_eachWayTerms', 'af.sportsstate.market.eachWayTermsDetails.eachWayTerms')
        df = __df_explode_column(df, 'e_market_externalUID', 'af.sportsstate.market.externalUID')
        df = __df_explode_column(df, 'e_market_results', 'af.sportsstate.market.results')
        df = __df_explode_column(df, 'e_outcome_externalUID', 'af.sportsstate.outcome.externalUID')
        df = __df_explode_column(df, 'e_outcome_results', 'af.sportsstate.outcome.results')
        df = __df_explode_column(df, 'e_outcomestatus_price', 'af.sportsstate.outcomeStatus.price')
        return df
    except Exception as exc:
        err_msg = "Error in `explode_bets` for kafka topic `{}` for job `{}`".format(job_vars.kafka_topic, job_vars.job_name)
        raise LakehouseError(trace_err=traceback.format_exc(), err_nbr='4.14', err_msg=err_msg, job_vars=job_vars)


def __df_explode_column(df: pyspark.sql.DataFrame, col_to_add: str, col_to_explode: str):
    """Explode data if the column exists

    Parameters
    ----------
    df : org.apache.spark.sql.DataFrame
        The data to be exploded

    col_to_add: str
        Name of the column to add

    col_to_explode: str
        Name of the column to explode

    Returns
    -------
    df : org.apache.spark.sql.DataFrame
        Original data with an additional column containing the exploded column
    """
    if __df_has_column(df, col_to_explode):
        df = df.withColumn(col_to_add, explode_outer(col_to_explode))
    return df
