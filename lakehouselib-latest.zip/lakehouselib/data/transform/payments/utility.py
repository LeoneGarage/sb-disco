import traceback

from lakehouselib.system.exception.handler import LakehouseError
from pyspark.sql.functions import explode_outer
from pyspark.sql.utils import AnalysisException

from pyspark.sql.types import StructType,StructField
import re

def has_column(df, col):
    try:
        df[col]
        return True
    except AnalysisException:
        return False
    
def explode_payments(df, job_vars):
    """Explode payments activity feed data

    Parameters
    ----------
    df : org.apache.spark.sql.DataFrame
        The incoming data from kafka (read_from_kafka)

    job_vars: util.config.stream.jobconfiguration class JobVariables
        All the required job variables to be used through out the job (JobVariables() -> job_vars)

    Returns
    -------
    exploded_data : org.apache.spark.sql.DataFrame
        A Representation of the incoming payments data exploded to a flattened form 
    """
    try:
        if has_column(df,"af.paymentstate.payment.extUIDRef") :
            exploded_data = df.withColumn("extuidref", explode_outer("af.paymentstate.payment.extUIDRef"))
        else :
            exploded_data = df
        return exploded_data
    except Exception as exc:
        err_msg = "Error in `explode_payments` for kafka topic `{}` for job `{}`".format(job_vars.kafka_topic, job_vars.job_name)
        raise LakehouseError(trace_err=traceback.format_exc(), err_nbr='4.14', err_msg=err_msg, job_vars=job_vars)


