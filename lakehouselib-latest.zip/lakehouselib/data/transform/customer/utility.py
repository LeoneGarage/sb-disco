import pyspark
import traceback

from pyspark.sql.functions import explode_outer
from lakehouselib.framework.lakehouse.dynamodb.getters import __df_has_column
from lakehouselib.system.exception.handler import LakehouseError


def explode_customers(df, job_vars):
    """Explode customers activity feed data

    Parameters
    ----------
    df : org.apache.spark.sql.DataFrame
        The incoming data from kafka (read_from_kafka)

    job_vars: util.config.stream.jobconfiguration class JobVariables
        All the required job variables to be used through out the job (JobVariables() -> job_vars)

    Returns
    -------
    exploded_data : org.apache.spark.sql.DataFrame
        A Representation of the incoming sports data exploded to a flattened form
    """
    try:
        # root
        #    |- customerState <struct>
        #    |    |- customer <struct>
        #    |    |    |- account <arraystruct>
        #    |    |    |- contactDetails <struct>
        #    |    |    |    |- email <arraystruct>
        #    |    |    |    |- phone <arraystruct>
        #    |    |    |- customerFlag <arraystruct>
        #    |    |    |- customerGroup <arraystruct>
        #    |    |    |- depositLimits <arraystruct>
        #    |    |    |- statusFlagDetails <arraystruct>
        #    |    |- customerAddress <arraystruct>
        df = __df_explode_column(df, 'e_customer_account', 'af.customerstate.customer.account')
        df = __df_explode_column(df, 'e_customer_contactDetails_email', 'af.customerstate.customer.contactDetails.email')
        df = __df_explode_column(df, 'e_customer_contactDetails_phone', 'af.customerstate.customer.contactDetails.phone')
        df = __df_explode_column(df, 'e_customer_customerFlag', 'af.customerstate.customer.customerFlag')
        df = __df_explode_column(df, 'e_customer_customerGroup', 'af.customerstate.customer.customerGroup')
        df = __df_explode_column(df, 'e_customer_depositLimits', 'af.customerstate.customer.depositLimits')
        df = __df_explode_column(df, 'e_customer_statusFlagDetails', 'af.customerstate.customer.statusFlagDetails')
        df = __df_explode_column(df, 'e_customerAddress', 'af.customerstate.customerAddress')
        df = __df_explode_column(df, 'e_customer_registration_affiliateRef', 'af.customerstate.customer.registration.affiliateRef')
        df = __df_explode_column(df, 'e_sportsbetCustomer_sportsbetAccount', 'af.sbtcustomerstate.sportsbetCustomer.sportsbetAccount')
        return df

    except Exception as exc:
        err_msg = "Error in `explode_customers` for kafka topic `{}` for job `{}`".format(job_vars.kafka_topic, job_vars.job_name)
        raise LakehouseError(trace_err=traceback.format_exc(), err_nbr='4.14', err_msg=err_msg, job_vars=job_vars)


def __df_explode_column(df: pyspark.sql.DataFrame, col_to_add: str, col_to_explode: str):
    """Explode data if the column exists

    Parameters
    ----------
    df : org.apache.spark.sql.DataFrame
        The data to be exploded

    col_to_add: str
        Name of the column to add

    col_to_explode: str
        Name of the column to explode

    Returns
    -------
    df : org.apache.spark.sql.DataFrame
        Original data with an additional column containing the exploded column
    """
    if __df_has_column(df, col_to_explode):
        df = df.withColumn(col_to_add, explode_outer(col_to_explode))
    return df
