import traceback

from pyspark.sql import functions as f
from lakehouselib.data.transform.account.utility import explode_accounts
from lakehouselib.data.transform.sgm_quotes.utility import explode_quotes
from lakehouselib.data.transform.sgm_transaction.utility import explode_transaction
from lakehouselib.data.transform.bet.utility import explode_bets, explode_poolbets
from lakehouselib.data.transform.sports.utility import explode_sports
from lakehouselib.data.transform.customer.utility import explode_customers
from lakehouselib.data.transform.transactions.utility import explode_transactions
from lakehouselib.data.transform.payments.utility import explode_payments
from lakehouselib.system.exception.handler import LakehouseError


def flatten_structs(nested_df):
    """
    :param nested_df: nested dataframe as input
    :return: un-nested dataframe using "_" as sepperator
    """
    stack = [((), nested_df)]
    columns = []
    while len(stack) > 0:
        parents, df = stack.pop()
        array_cols = [
            c[0]
            for c in df.dtypes
            if c[1][:5] == "array"
        ]
        flat_cols = [
            f.col(".".join(parents + (c[0],))).alias("_".join(parents + (c[0],)))
            for c in df.dtypes
            if c[1][:6] != "struct"
        ]
        nested_cols = [
            c[0]
            for c in df.dtypes
            if c[1][:6] == "struct"
        ]
        columns.extend(flat_cols)
        for nested_col in nested_cols:
            projected_df = df.select(nested_col + ".*")
            stack.append((parents + (nested_col,), projected_df))
    return nested_df.select(columns)


def flatten_array_struct_df(df):
    """
    :param df: dataframe to be flatten
    :return: flatten dataframe
    """
    array_cols = [
        c[0]
        for c in df.dtypes
        if c[1][:5] == "array"
    ]
    while len(array_cols) > 0:
        for array_col in array_cols:
            cols_to_select = [x for x in df.columns if x != array_col]
            df = df.withColumn(array_col, f.explode_outer(f.col(array_col)))
        df = flatten_structs(df)
        array_cols = [
            c[0]
            for c in df.dtypes
            if c[1][:5] == "array"
        ]
    return df


def explode_activity_feed_data(df, job_vars):
    """Based on the `kafka_topic` the appropriate optimised explode function is called

    Parameters
    ----------
    df : org.apache.spark.sql.DataFrame
        The incoming data from kafka (read_from_kafka)

    job_vars: util.config.stream.jobconfiguration class JobVariables
        All the required job variables to be used through out the job (JobVariables() -> job_vars)

    Returns
    -------
    exploded_data : org.apache.spark.sql.DataFrame
        A Representation of the incoming data exploded to a flattened form
    """
    try:
        if job_vars.kafka_topic == 'accounts':
            return_df = explode_accounts(df, job_vars)
        elif job_vars.kafka_topic == "bets":
            return_df = explode_bets(df, job_vars)
        elif job_vars.kafka_topic == 'poolbets':
            return_df = explode_poolbets(df, job_vars)
        elif job_vars.kafka_topic == 'sports':
            return_df = explode_sports(df, job_vars)
        elif job_vars.kafka_topic == 'customers':
            return_df = explode_customers(df, job_vars)
        elif job_vars.kafka_topic == 'transactions':
            return_df = explode_transactions(df, job_vars)
        elif job_vars.kafka_topic == 'payments':
            return_df = explode_payments(df, job_vars)
        return return_df
    except Exception as exc:
        err_msg = "Error in `explode_activity_feed_data` for kafka topic `{}` for job `{}`".format(job_vars.kafka_topic, job_vars.job_name)
        raise LakehouseError(trace_err=traceback.format_exc(), err_nbr='4.14', err_msg=err_msg, job_vars=job_vars)

def explode_sgm_cashout_data(df, job_vars):
    """Based on the `kafka_topic` the appropriate optimised explode function is called

    Parameters
    ----------
    df : org.apache.spark.sql.DataFrame
        The incoming data from kafka (read_from_kafka)

    job_vars: util.config.stream.jobconfiguration class JobVariables
        All the required job variables to be used through out the job (JobVariables() -> job_vars)

    Returns
    -------
    exploded_data : org.apache.spark.sql.DataFrame
        A Representation of the incoming data exploded to a flattened form
    """
    try:
        if job_vars.kafka_topic == 'quotes':
            return_df = explode_quotes(df, job_vars)
        elif job_vars.kafka_topic == "cashout-transaction-events":
            return_df = explode_transaction(df, job_vars)
        return return_df
    except Exception as exc:
        err_msg = "Error in `explode_sgm_cashout_data` for kafka topic `{}` for job `{}`".format(job_vars.kafka_topic, job_vars.job_name)
        raise LakehouseError(trace_err=traceback.format_exc(), err_nbr='4.14', err_msg=err_msg, job_vars=job_vars)


def convert_kv_to_string(dict_kv, separator='|'):
    """
    Function to convert dict to comma-delimited key-value string
    
    Sample:
    dict_kv = {'hub_account_id': 'bigint', 'account_id': 'bigint', 'ctl_src_id': 'int', 'ctl_modified_utc_dts': 'timestamp', 'ctl_headerdate': 'string', 'ctl_created_utc_dts': 'string', 'ctl_created_utc': 'date', 'ctl_inserted_run_id': 'string', 'ctl_inserted_batch_id': 'string', 'ctl_is_deleted': 'int'}
    convert_kv_to_string(dict_kv)
    
    Output:
    hub_account_id bigint|account_id bigint|ctl_src_id int|ctl_modified_utc_dts timestamp|ctl_headerdate string|ctl_created_utc_dts string|ctl_created_utc date|ctl_inserted_run_id string|ctl_inserted_batch_id string|ctl_is_deleted int
    """
    try:
        kv_list = []
        for k, v in dict_kv.items():
            kv_list.append(f'{k} {v}')
            
        return separator.join(kv_list)
    except Exception as exc:
        raise exc

def convert_string_to_dict(str_to_convert, separator='|'):
    """
    Function to convert a string to dict
    Sample:
        target_schema_defn = 'hub_account_id bigint|account_id bigint|ctl_src_id int|ctl_modified_utc_dts timestamp|ctl_headerdate string|ctl_created_utc_dts string|ctl_created_utc date|ctl_inserted_run_id string|ctl_inserted_batch_id string|ctl_is_deleted int'
        convert_string_to_dict(target_schema_defn)
    Output:
        {'hub_account_id': 'bigint', 'account_id': 'bigint', 'ctl_src_id': 'int', 'ctl_modified_utc_dts': 'timestamp', 'ctl_headerdate': 'string', 'ctl_created_utc_dts': 'string', 'ctl_created_utc': 'date', 'ctl_inserted_run_id': 'string', 'ctl_inserted_batch_id': 'string', 'ctl_is_deleted': 'int'}
    """
    try:
        dict_converted = {}
        for col_type in str_to_convert.split(separator):
            list_col_type = col_type.strip().split(' ')
            dict_converted[list_col_type[0]] = list_col_type[1]

        return (dict_converted)

    except Exception as exc:
        raise exc

def dedupe_dataframe_on_key(logger, dataframe=None, key_cols=None,debug=False):
    """
    Function that dedupes an input dataframe based on key_cols supplied
    params: 
    key_cols: List of key columns on which to check for duplicates
    dataframe: The dataframe which is to be checked for duplicates
    return:
    cleansed dataframe without duplicates
    """
    try:
        if debug:
            logger.info("Dataframe count prior to deduping: {}".format(dataframe.count()))
        return dataframe.dropDuplicates(key_cols)
    except Exception as exc:
        raise exc

def set_df_columns_nullable(spark, df, column_list, nullable=True):
    """Updates the nullable property of a column

    Args:
        spark ([type]): Spark
        df ([type]): Dataframe
        column_list ([type]): List of columns to set the nullable property on
        nullable (bool, optional): The value of the nullable property. Defaults to True.

    Returns:
        dataframe: Modified dataframe
    """
    try:
        for struct_field in df.schema:
            if struct_field.name in column_list:
                struct_field.nullable = nullable
        df_mod = spark.createDataFrame(df.rdd, df.schema)
        return df_mod
    except Exception as exc:
        raise exc

def update_source_schema_defn(spark, sqlContext, target_schema, target_table, df_source):
    """There are instances wherein the source and target schemas are not the same. 
    This updates the nullable property of the source schema to be the same as the target
    to avoid errors on the merging of data.

    Args:
        spark ([type]): [description]
        sqlContext ([type]): [description]
        target_schema (string): Target schema
        target_table (string): Target table
        df_source (RDD/dataframe): The dataframe to update the nullable property on

    Returns:
        RDD/dataframe: Modified dataframe
    """
    try:
        # Check if table already exists
        table_names_in_db = sqlContext.tableNames(target_schema)
        table_exists = target_table in table_names_in_db

        if table_exists:
            df_target = spark.sql(f'select * from {target_schema}.{target_table} limit 1')
            
            target_columns_nullable_false = []
            target_columns_nullable_true = []
            fields = df_target.schema.fields
            for _, fieldname in enumerate(fields, 1):
                if fieldname.nullable:
                    target_columns_nullable_true.append(fieldname.name)
                else:
                    target_columns_nullable_false.append(fieldname.name)

            if target_columns_nullable_true:
                df_source = set_df_columns_nullable(spark, df_source, target_columns_nullable_true, True)

            if target_columns_nullable_false:
                df_source = set_df_columns_nullable(spark, df_source, target_columns_nullable_false, False)
        
        return df_source

    except Exception as exc:
        raise exc


def add_ctl_columns_on_source_dataframe(logger, df_source, process_run_id, table_run_id, process_run_timestamp, table_type=None):
    """Adds control columns to the source dataframe to avoid inconsistency on the field names and data type.
    
    Args:
        logger
        df_source: source dataframe
        process_run_id (string)
        table_run_id (string): 
        process_run_timestamp (string): Timestamp 
        table_type (string): Any of the following: sat, dim, fact

    Returns:
        RDD/dataframe: Modified dataframe
    """
    try:
        table_types = ['sat', 'dim', 'fact']
        logger.info('Adding control columns')
        df_source = df_source.withColumn("ctl_inserted_run_id", f.lit(table_run_id)) \
            .withColumn("ctl_inserted_batch_id", f.lit(process_run_id)) \
            .withColumn("ctl_created_utc_dts", f.lit(process_run_timestamp)) \
            .withColumn("ctl_is_deleted", f.lit(0)) 
        
        if table_type in table_types:
            df_source = df_source.withColumn("ctl_updated_run_id", f.lit(table_run_id)) \
                .withColumn("ctl_updated_batch_id", f.lit(process_run_id)) \
                .withColumn("ctl_modified_utc_dts", f.lit(process_run_timestamp)) \
                .withColumn("ctl_part_id", f.lit(0)) 
            
        return df_source

    except Exception as exc:
        raise exc
