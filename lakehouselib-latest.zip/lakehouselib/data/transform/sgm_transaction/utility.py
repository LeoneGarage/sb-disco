import traceback

from lakehouselib.system.exception.handler import LakehouseError


def explode_transaction(df, job_vars):
    """Explode transaction feed data

    Parameters
    ----------
    df : org.apache.spark.sql.DataFrame
        The incoming data from kafka (read_from_kafka)

    job_vars: util.config.stream.jobconfiguration class JobVariables
        All the required job variables to be used through out the job (JobVariables() -> job_vars)

    Returns
    -------
    exploded_data : org.apache.spark.sql.DataFrame
        A Representation of the incoming accounts data exploded to a flattened form
    """
    try:
        return df
    except Exception as exc:
        err_msg = "Error in `explode_quotes` for kafka topic `{}` for job `{}`".format(job_vars.kafka_topic, job_vars.job_name)
        raise LakehouseError(trace_err=traceback.format_exc(), err_nbr='4.14', err_msg=err_msg, job_vars=job_vars)
