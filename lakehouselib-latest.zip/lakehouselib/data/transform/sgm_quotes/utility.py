import pyspark
import traceback

from pyspark.sql.functions import col, explode_outer, lit, when
from pyspark.sql.types import BooleanType, TimestampType
from lakehouselib.framework.lakehouse.dynamodb.getters import __df_has_column
from lakehouselib.system.exception.handler import LakehouseError


def explode_quotes(df, job_vars):
    """explode explode_quotes data

    Parameters
    ----------
    df : org.apache.spark.sql.DataFrame
        The incoming data from kafka (read_from_kafka)

    job_vars: util.config.stream.jobconfiguration class JobVariables
        All the required job variables to be used through out the job (JobVariables() -> job_vars)

    Returns
    -------
    exploded_data : org.apache.spark.sql.DataFrame
        A Representation of the incoming bets data exploded to a flattened form
    """
    try:
        # root
        #   |- legs <arraystruct>

        exploded_data = df.withColumn("quote_quotedLegs", explode_outer("cashout_quote.quotedLegs"))
        # exploded_data = __fix_fields_for_settlement(exploded_data)
        return exploded_data
    except Exception as exc:
        err_msg = "Error in `explode_quotes` for kafka topic `{}` for job `{}`".format(job_vars.kafka_topic, job_vars.job_name)
        raise LakehouseError(trace_err=traceback.format_exc(), err_nbr='4.14', err_msg=err_msg, job_vars=job_vars)
