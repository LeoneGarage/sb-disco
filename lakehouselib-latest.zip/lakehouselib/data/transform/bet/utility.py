import pyspark
import traceback

from pyspark.sql.functions import col, explode_outer, lit, when
from pyspark.sql.types import BooleanType, TimestampType, StringType, IntegerType, DecimalType
from lakehouselib.framework.lakehouse.dynamodb.getters import __df_has_column
from lakehouselib.system.exception.handler import LakehouseError

def __df_explode_column(df: pyspark.sql.DataFrame, col_to_add: str, col_to_explode: str):
    """Explode data if the column exists

    Parameters
    ----------
    df : org.apache.spark.sql.DataFrame
        The data to be exploded

    col_to_add: str
        Name of the column to add

    col_to_explode: str
        Name of the column to explode

    Returns
    -------
    df : org.apache.spark.sql.DataFrame
        Original data with an additional column containing the exploded column
    """
    if __df_has_column(df, col_to_explode):
        df = df.withColumn(col_to_add, explode_outer(col_to_explode))
    return df

def explode_bets(df, job_vars):
    """Explode bets activity feed data

    Parameters
    ----------
    df : org.apache.spark.sql.DataFrame
        The incoming data from kafka (read_from_kafka)

    job_vars: util.config.stream.jobconfiguration class JobVariables
        All the required job variables to be used through out the job (JobVariables() -> job_vars)

    Returns
    -------
    exploded_data : org.apache.spark.sql.DataFrame
        A Representation of the incoming bets data exploded to a flattened form
    """
    try:
        # root
        #   |- bets <arraystruct>
        #        |- legs <arraystruct>
        #             |- legParts <arraystruct>
        exploded_data = df.withColumn("e_bets", explode_outer("af.betstate.bets")) \
            .withColumn("e_legs", explode_outer("e_bets.leg")) \
            .withColumn("e_legParts", explode_outer("e_legs.legParts")) \
            .withColumn("e_sbtbetstate", explode_outer("af.sbtbetstate.bets"))
        if 'betTermChange' in exploded_data.select("e_bets.*").columns:
            exploded_data = exploded_data.withColumn("e_bettermchange", explode_outer("e_bets.betTermChange"))
        
        exploded_data = __df_explode_column(exploded_data, 'e_birCashout', 'e_sbtbetstate.cashout.birCashout')
        exploded_data = __fix_fields_for_settlement(exploded_data)
 
        return exploded_data
    except Exception as exc:
        err_msg = "Error in `explode_bets` for kafka topic `{}` for job `{}`".format(job_vars.kafka_topic, job_vars.job_name)
        raise LakehouseError(trace_err=traceback.format_exc(), err_nbr='4.14', err_msg=err_msg, job_vars=job_vars)


def explode_poolbets(df, job_vars):
    """Explode poolbets activity feed data

    Parameters
    ----------
    df : org.apache.spark.sql.DataFrame
        The incoming data from kafka (read_from_kafka)

    job_vars: util.config.stream.jobconfiguration class JobVariables
        All the required job variables to be used through out the job (JobVariables() -> job_vars)

    Returns
    -------
    exploded_data : org.apache.spark.sql.DataFrame
        A Representation of the incoming poolbets data exploded to a flattened form
    """
    try:
        # root
        #   |- bets <arraystruct>
        #   |    |- legs <arraystruct>
        #   |         |- legParts <arraystruct>
        #   +- betsupportingState.pool <arraystruct>
        exploded_data = df \
            .withColumn("e_bets", explode_outer("af.betstate.bets")) \
            .withColumn("e_legs", explode_outer("e_bets.leg")) \
            .withColumn("e_legParts", explode_outer("e_legs.legParts")) \
            .withColumn("e_pools", explode_outer("af.betsupportingState.pool")) \
            .withColumn("e_sbtbetstate", explode_outer("af.sbtbetstate.bets"))
        exploded_data = __fix_fields_for_settlement(exploded_data)
        return exploded_data
    except Exception as exc:
        err_msg = "Error in `explode_bets` for kafka topic `{}` for job `{}`".format(job_vars.kafka_topic, job_vars.job_name)
        raise LakehouseError(trace_err=traceback.format_exc(), err_nbr='4.14', err_msg=err_msg, job_vars=job_vars)


def __fix_fields_for_settlement(df: pyspark.sql.DataFrame):
    """Data arriving from source system contains an issue with settlement fields, which are addressed here

    Parameters
    ----------
    df : org.apache.spark.sql.DataFrame
        The exploded data frame, after deserializing the protobuf

    Returns
    -------
    df : pyspark.sql.DataFrame
        DataFrame containing fixed fields for settlement
    """
    col_context_ref = 'af.header.contextRef'
    col_isSettled = 'e_bets.isSettled'
    col_settledAt = 'e_bets.settledAt'
    col_linesVoided = 'e_bets.lines.voided'
    col_linesVoided_fixed = 'linesVoided'
    col_payoutRefunds = 'e_bets.payout.refunds'
    col_payoutRefunds_fixed = 'payoutRefunds'
    col_settledHow = 'e_bets.settledHow'
    col_isSettled_fixed = 'isSettled'
    col_settledAt_fixed = 'settledAt'
    col_settledHow_fixed = 'settledHow'
    col_linesWin = 'e_bets.lines.win'
    col_linesWin_fixed = 'linesWin'
    col_linesLose = 'e_bets.lines.lose'
    col_linesLose_fixed = 'linesLose'
    col_payoutWinnings = 'e_bets.payout.winnings'
    col_payoutWinnings_fixed = 'payoutWinnings'
    col_status = 'e_bets.status'
    col_status_fixed = 'status'


    context_ref_values_to_fix = ['BET.UNSETTLEMENT', 'BET.BET-PLACEMENT']

    if __df_has_column(df, col_context_ref):
        calc_isSettled = when(col(col_context_ref).isin(context_ref_values_to_fix), lit(False).cast(BooleanType())) \
            .otherwise(col(col_isSettled).cast(BooleanType()))
        calc_settledAt = when(col(col_context_ref).isin(context_ref_values_to_fix), lit(None).cast(TimestampType())) \
            .otherwise(col(col_settledAt).cast(TimestampType()))
        calc_settledHow = when(col(col_context_ref) == 'BET.BET-PLACEMENT', lit(None).cast(StringType())) \
            .otherwise(col(col_settledHow).cast(StringType()))
        calc_linesVoided = when(col(col_context_ref).isin(context_ref_values_to_fix), lit(0).cast(IntegerType())) \
            .otherwise(col(col_linesVoided).cast(IntegerType()))
        calc_payoutRefunds = when(col(col_context_ref).isin(context_ref_values_to_fix), lit(0).cast(DecimalType(19, 4))) \
            .otherwise(col(col_payoutRefunds).cast(DecimalType(19, 4)))
        calc_linesWin = when(col(col_context_ref).isin(context_ref_values_to_fix), lit(0).cast(IntegerType())) \
            .otherwise(col(col_linesWin).cast(IntegerType()))
        calc_linesLose = when(col(col_context_ref).isin(context_ref_values_to_fix), lit(0).cast(IntegerType())) \
            .otherwise(col(col_linesLose).cast(IntegerType()))
        calc_payoutWinnings = when(col(col_context_ref).isin(context_ref_values_to_fix), lit(0).cast(DecimalType(19, 4))) \
            .otherwise(col(col_payoutWinnings).cast(DecimalType(19, 4)))
        calc_status = when((col(col_context_ref).isin(context_ref_values_to_fix)) & (col(col_status) == 'CANCELED'), lit('ACTIVE').cast(StringType())) \
            .otherwise(col(col_status).cast(StringType()))

        if __df_has_column(df, col_isSettled):
            df = df.withColumn(col_isSettled_fixed, calc_isSettled)
        else:
            df = df.withColumn(col_isSettled_fixed, lit(None).Cast(BooleanType()))

        if __df_has_column(df, col_settledAt):
            df = df.withColumn(col_settledAt_fixed, calc_settledAt)
        else:
            df = df.withColumn(col_settledAt_fixed, lit(None).cast(TimestampType()))

        if __df_has_column(df, col_settledHow):
            df = df.withColumn(col_settledHow_fixed, calc_settledHow)
        else:
            df = df.withColumn(col_settledHow_fixed, lit(None).cast(StringType()))

        if __df_has_column(df, col_linesVoided):
            df = df.withColumn(col_linesVoided_fixed, calc_linesVoided)
        else:
            df = df.withColumn(col_linesVoided_fixed, lit(None).cast(IntegerType()))

        if __df_has_column(df, col_payoutRefunds):
            df = df.withColumn(col_payoutRefunds_fixed, calc_payoutRefunds)
        else:
            df = df.withColumn(col_payoutRefunds_fixed, lit(None).cast(DecimalType(19, 4)))

        if __df_has_column(df, col_linesWin):
            df = df.withColumn(col_linesWin_fixed, calc_linesWin)
        else:
            df = df.withColumn(col_linesWin_fixed, lit(None).cast(IntegerType()))

        if __df_has_column(df, col_linesLose):
            df = df.withColumn(col_linesLose_fixed, calc_linesLose)
        else:
            df = df.withColumn(col_linesLose_fixed, lit(None).cast(IntegerType()))

        if __df_has_column(df, col_payoutWinnings):
            df = df.withColumn(col_payoutWinnings_fixed, calc_payoutWinnings)
        else:
            df = df.withColumn(col_payoutWinnings_fixed, lit(None).cast(DecimalType(19, 4)))

        if __df_has_column(df, col_status):
            df = df.withColumn(col_status_fixed, calc_status)
        else:
            df = df.withColumn(col_status_fixed, lit(None).cast(StringType()))

    else:
        if __df_has_column(df, col_isSettled):
            df = df.withColumn(col_isSettled_fixed, col(col_isSettled))
        else:
            df = df.withColumn(col_isSettled_fixed, lit(None).Cast(BooleanType()))

        if __df_has_column(df, col_settledAt):
            df = df.withColumn(col_settledAt_fixed, col(col_settledAt))
        else:
            df = df.withColumn(col_settledAt_fixed, lit(None).cast(TimestampType()))

        if __df_has_column(df, col_settledHow):
            df = df.withColumn(col_settledHow_fixed, col(col_settledHow))
        else:
            df = df.withColumn(col_settledHow_fixed, lit(None).cast(StringType()))

        if __df_has_column(df, col_linesVoided):
            df = df.withColumn(col_linesVoided_fixed, col(col_linesVoided))
        else:
            df = df.withColumn(col_linesVoided_fixed, lit(None).cast(IntegerType()))

        if __df_has_column(df, col_payoutRefunds):
            df = df.withColumn(col_payoutRefunds_fixed, col(col_payoutRefunds))
        else:
            df = df.withColumn(col_payoutRefunds_fixed, lit(None).cast(DecimalType(19, 4)))

        if __df_has_column(df, col_linesWin):
            df = df.withColumn(col_linesWin_fixed, col(col_linesWin))
        else:
            df = df.withColumn(col_linesWin_fixed, lit(None).cast(IntegerType()))

        if __df_has_column(df, col_linesLose):
            df = df.withColumn(col_linesLose_fixed, col(col_linesLose))
        else:
            df = df.withColumn(col_linesLose_fixed, lit(None).cast(IntegerType()))

        if __df_has_column(df, col_payoutWinnings):
            df = df.withColumn(col_payoutWinnings_fixed, col(col_payoutWinnings))
        else:
            df = df.withColumn(col_payoutWinnings_fixed, lit(None).cast(DecimalType(19, 4)))

        if __df_has_column(df, col_status):
            df = df.withColumn(col_status_fixed, col(col_status))
        else:
            df = df.withColumn(col_status_fixed, lit(None).cast(StringType()))

    return df
