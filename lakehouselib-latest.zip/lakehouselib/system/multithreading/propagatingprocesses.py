import threading


class PropagatingProcesses(threading.Thread):
    def run(self):
        """
        Extended function of Threading that works as an entrypoint of a thread

        Args:
        """
        self.exc = None
        try:
            self.childProcessObj = self._target(*self._args, **self._kwargs)
        except BaseException as e:
            self.exc = e

    def join(self, timeout):
        """
        Asyc call wait for all the threads

        Args:
            timeout: In secs, a way to close the thread itself else it will close at
            the end of the scope.
        """
        super(PropagatingProcesses, self).join(timeout)

        if self.exc:
            raise RuntimeError('Exception in thread') from self.exc
        return self.childProcessObj

    def thread_pool(*args, **kwargs):
        """
        Attach Thread to a Spark pool. This is modelled after the FIFO scheduling and
        hence things like weight and mishare are not implemented and analyzed/tested yet.

        Args:
            args: positional arguments coming from the main script
            kwargs: keyword arguments coming from the main script
        """
        spark = args[0]

        if kwargs.get('scheduler_mode'):
            spark.sql(f"SET spark.scheduler.mode = {kwargs['scheduler_mode']}")

        spark.sql(f"SET spark.scheduler.pool = {kwargs['poolId']}")

        func = kwargs['func_to_thread']
        kwargs.pop('func_to_thread')

        _ = func(*args, **kwargs)

        spark.sql("SET spark.scheduler.pool = None")

    def thread_propagation():
        """
        Function to dispath thread into multiple processes

        Args:
        """
        def process(func):
            def dispatch(*args, **kwargs):
                poolId = 0
                processes = list()

                for (iterKey, iterVal) in kwargs['dict_to_iter'].items():
                    kwargs['iterKey'] = iterKey
                    kwargs['iterVal'] = iterVal
                    kwargs['poolId'] = poolId
                    kwargs['func_to_thread'] = func

                    childProcess = PropagatingProcesses(target=PropagatingProcesses.thread_pool, args=args, kwargs=kwargs)
                    processes.append(childProcess)
                    poolId += 1
                    childProcess.start()

                for childProcess in processes:
                    childProcess.join(kwargs.get('timeout'))

            return dispatch
        return process
