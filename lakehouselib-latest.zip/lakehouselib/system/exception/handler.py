import os
from os.path import abspath
from pathlib import Path

import traceback


class LakehouseError(Exception):
    """Exception raised for errors in the input."""

    def __search_exception(self):
        if self.err_nbr in self.exc_dicts.keys():
            return self.exc_dicts[self.err_nbr]
        return None

    def __print_error_message(self):
        err_msg = "\n%%%%%%%%%% EXCEPTION %%%%%%%%%%"
        err_msg = err_msg + "\n    EXCEPTION CODE: {}".format(self.err_nbr)
        err_msg = err_msg + "\nEXCEPTION CATEGORY: {} - {}".format(self.exc_cat_nbr, self.exc_cat)
        err_msg = err_msg + "\n EXCEPTION MESSAGE: {} - {}".format(self.exc_nbr, self.exc_bem)
        err_msg = err_msg + "\n     ERROR MESSAGE: {}".format(self.err_msg)
        err_msg = err_msg + "\n{}".format(self.trace_err)
        err_msg = err_msg + "\n%%%%%%%%%% EXCEPTION END %%%%%%%%%%"
        self.logger.error(err_msg)

    def __init__(self, trace_err, err_nbr, err_msg, job_vars):
        try:
            super().__init__(err_msg)
            self.logger = job_vars.logger
            self.err_nbr = err_nbr
            self.exc_dicts = job_vars.ddb_exc_dicts
            exc_dict = self.__search_exception()
            if exc_dict is not None:
                self.exc_cat_nbr = err_nbr.split(".")[0]
                self.exc_nbr = err_nbr.split(".")[1]
                self.exc_cat = exc_dict['exc_cat']
                self.exc_bem = exc_dict['exc_bem']
                self.trace_err = trace_err
                self.err_msg = err_msg
                self.__print_error_message()
            else:
                err_msg = "%%%%%% INVALID EXCEPTION NUMBER SPECIFIED / UNKNOWN EXCEPTION OCCURRED%%%%%%"
                self.logger.error(err_msg)
        except:
            self.err_nbr = '0.0'
            self.exc_cat_nbr = 0
            self.exc_nbr = 0
            self.exc_cat = "System Initialisation"
            self.exc_bem = "System Exception Handler Initialisation Error"
            self.err_msg = "Failed establishing System Exception Handler"
            self.trace_err = traceback.format_exc()
            # self.print_error_message()
            raise Exception(self.__print_error_message())
