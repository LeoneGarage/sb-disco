"""Top-level package for lakehouselib."""

__author__ = """Team Vulcan"""
__email__ = 'TeamVulcan@sportsbet.com.au'
__version__ = '9.0.7'
